import numpy as np
import pytest
import xarray as xr

from upscaling_tools.clustering import (
    choose_clustering,
    gap_statistic,
    k_max_for,
    residual_features,
)
from upscaling_tools.utils import make_skeletons

SHAPE = (64, 64)
XNAME, YNAME = "easting", "northing"


def _blob(centre, width=12.0):
    rows, cols = np.mgrid[0 : SHAPE[0], 0 : SHAPE[1]]
    return np.exp(-(((rows - centre[0]) ** 2 + (cols - centre[1]) ** 2) / (2 * width**2)))


def _dataset(fields):
    labels = [f"sample_{i}" for i in range(len(fields))]
    rows, cols = np.shape(fields[0])
    ds = xr.Dataset(
        {label: ((YNAME, XNAME), field) for label, field in zip(labels, fields)},
        coords={
            YNAME: np.arange(rows, dtype=float),
            XNAME: np.arange(cols, dtype=float),
        },
    )
    return ds, labels


def _features(fields, cell_mask=None):
    ds, labels = _dataset(fields)
    return residual_features(ds, labels, XNAME, YNAME, cell_mask=cell_mask)


def _skeleton_features(fields):
    """Cluster on Canny skeletons, the way the block's 'skeletons' mode does."""
    ds, labels = _dataset(fields)
    ds = make_skeletons(ds, XNAME, YNAME, labels)
    names = [label + "_skeleton" for label in labels]
    return residual_features(ds, names, XNAME, YNAME, valid_from=labels)


def _groups(model):
    """Partition the realisation indices by cluster, as a comparable set."""
    return {frozenset(np.flatnonzero(model.labels_ == k)) for k in np.unique(model.labels_)}


def test_k_max_for_allows_a_split_at_three_realisations():
    # The old range(1, min(10, n - 1)) fitted only k=1 at n=3.
    assert k_max_for(3) == 2
    assert k_max_for(2) == 1
    assert k_max_for(1) == 1
    assert k_max_for(50) == 9


def test_magnitude_differences_separate_the_clusters():
    """The feature must see grade level, not only edge position."""
    rng = np.random.default_rng(6)
    shape = _blob((32, 32))
    quiet = [shape * 1.0 + 0.01 * rng.standard_normal(SHAPE) for _ in range(5)]
    loud = [shape * 10.0 + 0.01 * rng.standard_normal(SHAPE) for _ in range(5)]

    model, report = choose_clustering(_features(quiet + loud), k_max_for(10))

    assert report["k"] > 1
    # No cluster may hold a quiet and a loud realisation at once.
    for group in _groups(model):
        assert group <= frozenset(range(5)) or group <= frozenset(range(5, 10))


def test_canny_skeletons_cannot_see_magnitude():
    """Records why the clustering feature changed away from edge images.

    make_skeletons standardises each image and thresholds the gradient by
    quantile, so scaling a whole realisation leaves the edges where they were.
    """
    shape = _blob((32, 32))
    ds, labels = _dataset([shape * 1.0, shape * 10.0])
    skeletons = make_skeletons(ds, XNAME, YNAME, labels)

    quiet = skeletons[labels[0] + "_skeleton"].values
    loud = skeletons[labels[1] + "_skeleton"].values
    assert np.array_equal(quiet, loud)


def test_two_separated_families_are_found():
    rng = np.random.default_rng(0)
    north = [_blob((16, 32)) + 0.01 * rng.standard_normal(SHAPE) for _ in range(5)]
    south = [_blob((48, 32)) + 0.01 * rng.standard_normal(SHAPE) for _ in range(5)]

    model, report = choose_clustering(_features(north + south), k_max_for(10))

    assert report["k"] == 2
    assert _groups(model) == {frozenset(range(5)), frozenset(range(5, 10))}
    assert report["silhouette"] > 0.5


def test_one_continuous_cloud_stays_one_cluster():
    rng = np.random.default_rng(1)
    fields = [rng.standard_normal(SHAPE) for _ in range(20)]

    model, report = choose_clustering(_features(fields), k_max_for(20))

    assert report["k"] == 1
    assert report["silhouette"] is None
    assert set(np.unique(model.labels_)) == {0}


def test_identical_realisations_do_not_divide_by_zero():
    shape = _blob((32, 32))
    _, report = choose_clustering(_features([shape] * 5), k_max_for(5))
    assert report["k"] == 1


def test_cell_mask_restricts_the_clustering_cells():
    rng = np.random.default_rng(2)
    # All the between-realisation signal sits in the top half of the grid.
    fields = []
    for _ in range(6):
        field = np.zeros(SHAPE)
        field[: SHAPE[0] // 2] = rng.standard_normal((SHAPE[0] // 2, SHAPE[1]))
        fields.append(field)

    bottom_half = np.zeros(SHAPE, dtype=bool)
    bottom_half[SHAPE[0] // 2 :] = True

    assert np.abs(_features(fields, cell_mask=bottom_half)).max() == pytest.approx(0.0)
    assert np.abs(_features(fields)).max() > 0.1


def test_nan_cells_contribute_nothing_and_leave_no_nan():
    rng = np.random.default_rng(3)
    fields = [rng.standard_normal(SHAPE) for _ in range(4)]
    fields[0][:8, :8] = np.nan

    features = _features(fields)

    assert np.isfinite(features).all()
    # A cell that is NaN in any realisation is dropped from every realisation.
    holed = _features([field[:8, :8] for field in fields])
    assert np.abs(holed).max() == pytest.approx(0.0)


def test_same_random_state_gives_the_same_labels():
    rng = np.random.default_rng(4)
    fields = [_blob((16, 32)) for _ in range(4)] + [_blob((48, 32)) for _ in range(4)]
    fields = [field + 0.01 * rng.standard_normal(SHAPE) for field in fields]
    features = _features(fields)

    first, _ = choose_clustering(features, k_max_for(8), random_state=7)
    second, _ = choose_clustering(features, k_max_for(8), random_state=7)

    assert np.array_equal(first.labels_, second.labels_)


def test_gap_statistic_reports_one_value_per_k():
    rng = np.random.default_rng(5)
    features = _features([rng.standard_normal(SHAPE) for _ in range(8)])
    k, gaps = gap_statistic(features, k_max=4, n_refs=5)

    assert len(gaps) == 4
    assert 1 <= k <= 4


def test_skeleton_features_never_mix_two_spatial_families():
    """The 'skeletons' mode clusters on edge geometry and still needs no region.

    It splits more finely than the 'values' mode. make_skeletons thresholds the
    gradient by quantile, so a fixed share of pixels becomes an edge however
    flat the field is, and each realisation picks up its own speckle of
    background edges. Those speckles are near-orthogonal, so the realisations
    look like many tight clumps. The clusters stay coherent — no cluster mixes
    the two families — but there are more of them than the data calls for.
    """
    rng = np.random.default_rng(7)
    north = [_blob((16, 32)) + 0.01 * rng.standard_normal(SHAPE) for _ in range(5)]
    south = [_blob((48, 32)) + 0.01 * rng.standard_normal(SHAPE) for _ in range(5)]

    model, report = choose_clustering(_skeleton_features(north + south), k_max_for(10))

    assert report["k"] > 1
    for group in _groups(model):
        assert group <= frozenset(range(5)) or group <= frozenset(range(5, 10))


def test_skeleton_features_keep_one_continuous_family_together():
    """Over-splitting is not unconditional: a unimodal cloud still gives k=1."""
    rng = np.random.default_rng(9)
    fields = [
        _blob((32 + rng.normal(0, 6), 32 + rng.normal(0, 6))) for _ in range(12)
    ]

    _, report = choose_clustering(_skeleton_features(fields), k_max_for(12))

    assert report["k"] == 1


def test_valid_from_drops_cells_the_derived_image_cannot_see():
    """Skeletons are finite over a NaN border; the realisations decide validity."""
    rng = np.random.default_rng(8)
    fields = [_blob((32, 32)) + 0.05 * rng.standard_normal(SHAPE) for _ in range(4)]
    for field in fields:
        field[:8, :] = np.nan

    ds, labels = _dataset(fields)
    ds = make_skeletons(ds, XNAME, YNAME, labels)
    names = [label + "_skeleton" for label in labels]

    # The skeleton itself carries no NaN, so without valid_from nothing is dropped.
    assert np.isfinite(ds[names[0]].values).all()

    border = np.zeros(SHAPE, dtype=bool)
    border[:8, :] = True
    masked = residual_features(ds, names, XNAME, YNAME, cell_mask=border, valid_from=labels)
    assert np.abs(masked).max() == pytest.approx(0.0)
