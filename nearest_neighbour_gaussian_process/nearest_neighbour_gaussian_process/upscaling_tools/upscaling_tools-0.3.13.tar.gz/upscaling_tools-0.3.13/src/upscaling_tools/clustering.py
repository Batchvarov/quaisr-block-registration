"""Group field realisations by how they depart from the pointwise mean."""

import numpy as np
import PIL.Image
import sklearn.cluster
import sklearn.metrics

DEFAULT_MAX_SIDE = 256
MAX_CLUSTERS = 9

_TINY = float(np.finfo(np.float64).tiny)


def k_max_for(n_labels: int) -> int:
    """Largest cluster count worth fitting for this many realisations."""
    return max(1, min(MAX_CLUSTERS, n_labels - 1))


def _box_downsample(arr: np.ndarray, max_side: int) -> np.ndarray:
    """Area-average an array down to `max_side` on its longest side."""
    img = PIL.Image.fromarray(arr.astype(np.float32))
    width, height = img.size
    scale = min(1.0, max_side / max(width, height))
    if scale < 1.0:
        img = img.resize(
            (max(1, int(round(width * scale))), max(1, int(round(height * scale)))),
            PIL.Image.BOX,
        )
    return np.asarray(img, dtype=np.float32)


def _stack(dataset, names: list[str], xname: str, yname: str) -> np.ndarray:
    return np.stack(
        [dataset[name].transpose(yname, xname).values.astype(np.float32) for name in names]
    )


def residual_features(
    dataset,
    names: list[str],
    xname: str,
    yname: str,
    cell_mask: np.ndarray | None = None,
    valid_from: list[str] | None = None,
    max_side: int = DEFAULT_MAX_SIDE,
) -> np.ndarray:
    """Build one feature vector per realisation from its departure from the mean.

    The feature is the image in `names` minus the pointwise mean over all the
    images, downsampled and flattened. Cells where the images agree hold a
    near-zero residual in every row, so they add nothing to any pairwise
    distance and need no threshold to exclude them. Cells outside `cell_mask`,
    and cells that are NaN in any image, are set to the same neutral zero.

    Pass `valid_from` when `names` holds something derived from the grid rather
    than the grid itself: Canny skeletons are computed from NaN-filled data, so
    they are finite even where the realisation has no data, and the cells to
    drop must come from the realisations instead.

    Returns an array of shape (len(names), downsampled_cells).
    """
    values = _stack(dataset, names, xname, yname)

    validity_source = values if valid_from is None else _stack(dataset, valid_from, xname, yname)
    valid = np.isfinite(validity_source).all(axis=0)
    if cell_mask is not None:
        valid = valid & np.asarray(cell_mask, dtype=bool)

    filled = np.nan_to_num(values)
    residuals = np.where(valid, filled - filled.mean(axis=0), 0.0)
    return np.stack([_box_downsample(residual, max_side).ravel() for residual in residuals])


def _wcss(X: np.ndarray, k: int, random_state: int) -> float:
    """Within-cluster sum of squares for a k-means fit with k clusters."""
    if k == 1:
        return float(((X - X.mean(axis=0)) ** 2).sum())
    model = sklearn.cluster.KMeans(n_clusters=k, n_init=10, random_state=random_state)
    return float(model.fit(X).inertia_)


def gap_statistic(
    X: np.ndarray,
    k_max: int,
    n_refs: int = 20,
    random_state: int = 0,
) -> tuple[int, list[float]]:
    """Choose a cluster count with Tibshirani's gap statistic.

    Compares log(WCSS) of the data against uniform reference sets drawn over its
    bounding box, and returns the smallest k with gap[k] >= gap[k+1] - s[k+1].
    Unlike a silhouette score this can answer k=1, which is the right answer
    when the realisations form one continuous cloud.

    Pass `X` in principal-component coordinates: the reference box is then
    aligned to the principal axes, as the method requires.

    Returns the chosen k and the gap value for every k from 1 to k_max.
    """
    k_values = list(range(1, max(1, k_max) + 1))
    if _wcss(X, 1, random_state) <= 0:
        return 1, [0.0 for _ in k_values]

    rng = np.random.default_rng(random_state)
    low, high = X.min(axis=0), X.max(axis=0)

    gaps: list[float] = []
    spreads: list[float] = []
    for k in k_values:
        log_data = np.log(max(_wcss(X, k, random_state), _TINY))
        log_refs = np.array(
            [
                np.log(max(_wcss(rng.uniform(low, high, X.shape), k, random_state), _TINY))
                for _ in range(n_refs)
            ]
        )
        gaps.append(float(log_refs.mean() - log_data))
        spreads.append(float(log_refs.std() * np.sqrt(1.0 + 1.0 / n_refs)))

    for i in range(len(k_values) - 1):
        if gaps[i] >= gaps[i + 1] - spreads[i + 1]:
            return k_values[i], gaps
    return k_values[-1], gaps


def choose_clustering(
    X: np.ndarray,
    k_max: int,
    n_refs: int = 20,
    random_state: int = 0,
):
    """Fit k-means at the cluster count the gap statistic selects.

    Returns the fitted model and a report holding the chosen `k`, the `gaps` the
    selection came from, and the `silhouette` score when k > 1. The silhouette
    is reported for the caller to judge the split; it cannot express k=1, so it
    plays no part in the selection.
    """
    k, gaps = gap_statistic(X, k_max, n_refs=n_refs, random_state=random_state)
    model = sklearn.cluster.KMeans(n_clusters=k, n_init=10, random_state=random_state).fit(X)

    silhouette = None
    if k > 1:
        silhouette = float(sklearn.metrics.silhouette_score(X, model.labels_))

    return model, {"k": k, "gaps": gaps, "silhouette": silhouette}
