import pandas as pd

from sklearn.preprocessing import StandardScaler, MinMaxScaler

class InputScaler:
    def __init__(self, scaler, aggregate_dims=False) -> None:
        self.aggregate_dims = aggregate_dims
        self.scaler = scaler

    def fit_transform(self, X):
        Xs = pd.DataFrame(data = X)
        if self.aggregate_dims:
            shape = Xs.values.shape
            data = self.scaler.fit_transform(Xs.values.reshape(-1, 1))
            return data.reshape(shape)
        else:
            return self.scaler.fit_transform(Xs)

    def transform(self, X):
        Xs = pd.DataFrame(data = X)
        if self.aggregate_dims: 
            return self.scaler.transform(Xs.values.reshape(-1,1)).reshape(Xs.shape)
        else:
            return self.scaler.transform(Xs)

    def inverse_transform(self, X):
        Xs = pd.DataFrame(data = X)
        if self.aggregate_dims: 
            return self.scaler.inverse_transform(Xs.values.reshape(-1,1)).reshape(Xs.shape)
        else:
            return self.scaler.inverse_transform(Xs)


