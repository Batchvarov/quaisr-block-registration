import warnings
import torch
import pytest

from upscaling_tools.ordering import assign_level_sizes, hierarchical_vecchia_dag


# ── assign_level_sizes ────────────────────────────────────────────────────────

def test_level_sizes_sum_n3():
    sizes = assign_level_sizes(1000, 3, 10)
    assert sum(sizes) == 1000
    assert sizes[0] == 10
    assert all(s > 0 for s in sizes)
    assert len(sizes) == 3


def test_level_sizes_sum_n4():
    sizes = assign_level_sizes(2000, 4, 20)
    assert sum(sizes) == 2000
    assert sizes[0] == 20
    assert len(sizes) == 4


def test_level_sizes_geometric_order():
    sizes = assign_level_sizes(1000, 3, 10)
    # Coarser levels smaller than finer
    assert sizes[0] <= sizes[1] <= sizes[2]


def test_level_sizes_reduces_levels():
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        sizes = assign_level_sizes(30, 5, 10)
        assert len(w) == 1
    assert sum(sizes) == 30
    assert sizes[0] == 10


def test_level_sizes_raises_too_small():
    with pytest.raises(ValueError):
        assign_level_sizes(15, 3, 10)


# ── hierarchical_vecchia_dag ──────────────────────────────────────────────────

def test_dag_shapes():
    torch.manual_seed(42)
    Z = torch.rand(200, 2)
    k = 10
    order, nn_idx = hierarchical_vecchia_dag(Z, k=k, n_levels=3)
    assert order.shape == (200,)
    assert nn_idx.shape == (190, 10)


def test_order_is_valid_permutation():
    torch.manual_seed(42)
    Z = torch.rand(200, 2)
    order, _ = hierarchical_vecchia_dag(Z, k=10, n_levels=3)
    assert order.sort().values.tolist() == list(range(200))


def test_causal_invariant():
    torch.manual_seed(7)
    Z = torch.rand(500, 2)
    k = 10
    _, nn_idx = hierarchical_vecchia_dag(Z, k=k, n_levels=3)
    # All parent indices must be strictly less than absolute position p = i + k
    i_idx = torch.arange(nn_idx.shape[0]).unsqueeze(1)
    assert (nn_idx < i_idx + k).all(), "Causal invariant violated: parent index >= point index"


def test_causal_invariant_3d():
    torch.manual_seed(7)
    Z = torch.rand(300, 3)
    k = 8
    _, nn_idx = hierarchical_vecchia_dag(Z, k=k, n_levels=3)
    i_idx = torch.arange(nn_idx.shape[0]).unsqueeze(1)
    assert (nn_idx < i_idx + k).all()


def test_dag_2_levels():
    torch.manual_seed(1)
    Z = torch.rand(100, 2)
    k = 5
    order, nn_idx = hierarchical_vecchia_dag(Z, k=k, n_levels=2)
    assert order.shape == (100,)
    assert nn_idx.shape == (95, 5)
    i_idx = torch.arange(nn_idx.shape[0]).unsqueeze(1)
    assert (nn_idx < i_idx + k).all()


# ── NNGPCholeskyLinearOperator integration ────────────────────────────────────

def test_F_nonnegative():
    import gpytorch
    from upscaling_tools.nngp_lin_op import NNGPCholeskyLinearOperator

    torch.manual_seed(0)
    Z = torch.rand(100, 2)
    k = 5
    _, nn_idx = hierarchical_vecchia_dag(Z, k=k, n_levels=3)

    kernel = gpytorch.kernels.RBFKernel()
    kernel.lengthscale = 0.3
    chol = NNGPCholeskyLinearOperator.from_kernel(kernel, Z, nn_idx, k=k)
    assert chol.F.min().item() >= 0.0, "F has negative conditional variances"


def test_cholesky_solve_finite():
    import gpytorch
    from upscaling_tools.nngp_lin_op import NNGPCholeskyLinearOperator

    torch.manual_seed(1)
    Z = torch.rand(100, 2)
    k = 5
    _, nn_idx = hierarchical_vecchia_dag(Z, k=k, n_levels=3)

    kernel = gpytorch.kernels.RBFKernel()
    chol = NNGPCholeskyLinearOperator.from_kernel(kernel, Z, nn_idx, k=k)
    rhs = torch.randn(100, 3)
    result = chol.cholesky_solve(rhs)
    assert result.isfinite().all(), "cholesky_solve returned non-finite values"


def test_matmul_finite():
    import gpytorch
    from upscaling_tools.nngp_lin_op import NNGPCholeskyLinearOperator

    torch.manual_seed(2)
    Z = torch.rand(100, 2)
    k = 5
    _, nn_idx = hierarchical_vecchia_dag(Z, k=k, n_levels=3)

    kernel = gpytorch.kernels.RBFKernel()
    chol = NNGPCholeskyLinearOperator.from_kernel(kernel, Z, nn_idx, k=k)
    v = torch.randn(100, 4)
    result = chol @ v
    assert result.isfinite().all()


# ── construct_model integration ───────────────────────────────────────────────

def test_construct_model_attaches_nn_idx():
    import gpytorch
    from upscaling_tools.nngp import construct_model

    torch.manual_seed(3)
    M = 100
    X = torch.rand(M, 2)
    y = torch.rand(M)
    kernel = gpytorch.kernels.RBFKernel()
    likelihood = gpytorch.likelihoods.GaussianLikelihood()
    parameters = {'k': 5, 'training_batch_size': 10, 'learning_rate': 1e-2,
                  'training_epochs': 1, 'milestones': []}

    model, _, _, _ = construct_model(
        X, y, kernel, likelihood, parameters,
        use_hierarchical_vecchia=True, n_vecchia_levels=3,
    )
    assert hasattr(model, '_hierarchical_nn_idx')
    assert model._hierarchical_nn_idx.shape == (M - 5, 5)


def test_construct_model_strategy_uses_hierarchical_dag():
    """The DAG must reach the variational strategy, not just the model attribute.

    GPyTorch reads nn_xinduce_idx only in _stochastic_kl_helper, so it IS the
    NNGP prior. If the strategy rebuilds its own sequential k-NN index the
    hierarchy never enters the ELBO.
    """
    import gpytorch
    from upscaling_tools.nngp import construct_model

    torch.manual_seed(3)
    M, k = 100, 5
    X = torch.rand(M, 2)
    y = torch.rand(M)
    kernel = gpytorch.kernels.RBFKernel()
    likelihood = gpytorch.likelihoods.GaussianLikelihood()
    parameters = {'k': k, 'training_batch_size': 10, 'learning_rate': 1e-2,
                  'training_epochs': 1, 'milestones': []}

    model, _, _, _ = construct_model(
        X, y, kernel, likelihood, parameters,
        use_hierarchical_vecchia=True, n_vecchia_levels=3,
    )

    strategy_idx = model.variational_strategy.nn_xinduce_idx.squeeze()
    assert strategy_idx.shape == (M - k, k)
    assert torch.equal(strategy_idx, model._hierarchical_nn_idx.squeeze())


def test_construct_model_flat_no_nn_idx():
    import gpytorch
    from upscaling_tools.nngp import construct_model

    torch.manual_seed(4)
    M = 100
    X = torch.rand(M, 2)
    y = torch.rand(M)
    kernel = gpytorch.kernels.RBFKernel()
    likelihood = gpytorch.likelihoods.GaussianLikelihood()
    parameters = {'k': 5, 'training_batch_size': 10, 'learning_rate': 1e-2,
                  'training_epochs': 1, 'milestones': []}

    model, _, _, _ = construct_model(X, y, kernel, likelihood, parameters)
    assert not hasattr(model, '_hierarchical_nn_idx')
    # The strategy still builds its own local sequential index.
    assert model.variational_strategy.nn_xinduce_idx.squeeze().shape == (M - 5, 5)


# ── long-range covariance accuracy ────────────────────────────────────────────

def _implied_nngp_cov(kernel, Zp, nn_idx, k, jitter):
    """Dense Sigma = L L^T implied by a Vecchia DAG, for a small M.

    Builds the factor analytically from the sparse pieces (L = A^{-1} D^{1/2})
    rather than through NNGPCholeskyLinearOperator._matmul, whose torch.compile'd
    forward substitution costs far more to trace than the dense solve costs here.
    """
    from upscaling_tools.nngp_lin_op import NNGPCholeskyLinearOperator

    M = Zp.shape[0]
    chol = NNGPCholeskyLinearOperator.from_kernel(kernel, Zp, nn_idx, k=k, jitter=jitter)
    A = torch.eye(M, dtype=Zp.dtype)
    rows = torch.arange(k, M).unsqueeze(1).expand(M - k, k)
    A[rows.reshape(-1), nn_idx.reshape(-1)] = -chol.B.reshape(-1)
    D_half = torch.zeros(M, M, dtype=Zp.dtype)
    D_half[:k, :k] = chol.L_first
    D_half[torch.arange(k, M), torch.arange(k, M)] = chol.F.sqrt()
    L = torch.linalg.solve_triangular(A, D_half, upper=False)
    return L @ L.T


def _unpermute(S, order):
    inv = torch.argsort(order)
    return S[inv][:, inv]


def test_hierarchical_dag_beats_flat_at_long_lag():
    """The point of the hierarchy: a smaller Vecchia error at long separations.

    Flat conditioning sets hold the k nearest predecessors, all inside one small
    disc, so the implied prior treats distant regions as near-independent. The
    hierarchical DAG spends part of the same budget of k on the L_0 skeleton and
    on intermediate levels, which restores domain-scale covariance.

    Measured in the regime the hierarchy exists for -- a correlation range of
    several inducing spacings (spacing ~0.05 here against a lengthscale of 0.3).
    Below roughly one spacing there is no long-range structure to recover and
    the distant parents are wasted budget, so flat is the better approximation
    there; that trade-off is expected, not a defect.
    """
    import gpytorch
    from upscaling_tools.ordering import (
        _causal_knn_slab, hierarchical_vecchia_dag, hilbert_sort_indices,
    )

    M, k, lengthscale, jitter = 400, 16, 0.3, 1e-6

    for seed in (0, 1, 2):
        torch.manual_seed(seed)
        Z = torch.rand(M, 2, dtype=torch.float64)
        kernel = gpytorch.kernels.MaternKernel(nu=2.5).double()
        kernel.lengthscale = lengthscale

        with torch.no_grad():
            K = kernel(Z, Z).to_dense() + jitter * torch.eye(M, dtype=Z.dtype)

            # Flat DAG: Hilbert sort, then k nearest predecessors. window_mult=M
            # makes the causal search exact rather than windowed.
            order_flat = hilbert_sort_indices(Z)
            nn_flat = _causal_knn_slab(
                Z[order_flat], k, M, k, chunk_size=M, window_mult=M)
            cov_flat = _unpermute(
                _implied_nngp_cov(kernel, Z[order_flat], nn_flat, k, jitter), order_flat)

            order_hier, nn_hier = hierarchical_vecchia_dag(Z, k=k, n_levels=3)
            cov_hier = _unpermute(
                _implied_nngp_cov(kernel, Z[order_hier], nn_hier, k, jitter), order_hier)

            far = torch.cdist(Z, Z) > lengthscale
            denom = K[far].norm()
            err_flat = ((cov_flat - K)[far].norm() / denom).item()
            err_hier = ((cov_hier - K)[far].norm() / denom).item()

        assert err_hier < 0.6 * err_flat, (
            f"seed {seed}: hierarchical long-lag error {err_hier:.4f} did not beat "
            f"flat {err_flat:.4f} by the expected margin")
