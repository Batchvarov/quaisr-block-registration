"""A saved topology must rebuild the model exactly, not merely plausibly.

Rebuilding an NNGP for inference used to repeat everything that is a
deterministic function of the training inputs: the inducing-point allocation
(a KD-tree over every training point), the Hilbert sort, the hierarchical
Vecchia DAG, and -- the expensive one -- NNUtil.build_sequential_nn_idx, a
Python loop over the M-k inducing points issuing one single-row index search
and one insert per point.

construct_model(topology=...) skips all of it. That is only safe if the
rebuilt model is INDISTINGUISHABLE from the one that would have been rebuilt
the slow way, so these compare the two directly. The no-topology path must also
keep working, because checkpoints written before upscaling_tools 0.3.7 have no
such key.
"""
import gpytorch
import numpy as np
import torch

from upscaling_tools.inducing import GridCountInducing
from upscaling_tools.nngp import construct_model, model_topology

N = 400
NINDUCING = 120
K = 8


def _inputs(seed=0):
    torch.manual_seed(seed)
    X = torch.rand(N, 2)
    y = torch.sin(3 * X[:, 0]) * torch.cos(2 * X[:, 1])
    return X, y


def _parameters():
    return {"k": K, "training_batch_size": 64, "learning_rate": 1e-2,
            "training_epochs": 1, "milestones": [], "ninducing": NINDUCING}


def _build(X, y, topology=None, hierarchical=False, seed=0):
    torch.manual_seed(seed)
    kernel = gpytorch.kernels.ScaleKernel(gpytorch.kernels.MaternKernel(nu=2.5))
    likelihood = gpytorch.likelihoods.GaussianLikelihood()
    model, _, _, _ = construct_model(
        X, y, kernel, likelihood, _parameters(),
        mean_module=gpytorch.means.ConstantMean(),
        inducing_points_allocator=GridCountInducing(NINDUCING),
        topology=topology,
        use_hierarchical_vecchia=hierarchical,
        n_vecchia_levels=3,
    )
    return model


def _assert_same_structure(a, b):
    sa, sb = a.variational_strategy, b.variational_strategy
    torch.testing.assert_close(sa.inducing_points, sb.inducing_points, rtol=0, atol=0)
    assert torch.equal(sa.nn_xinduce_idx.squeeze(), sb.nn_xinduce_idx.squeeze())

    hier_a = getattr(a, "_hierarchical_nn_idx", None)
    hier_b = getattr(b, "_hierarchical_nn_idx", None)
    assert (hier_a is None) == (hier_b is None)
    if hier_a is not None:
        assert torch.equal(hier_a, hier_b)


def _assert_same_predictions(a, b, seed=5):
    xt = torch.from_numpy(
        np.random.default_rng(seed).uniform(0.05, 0.95, size=(300, 2))
    ).to(torch.float32)
    with torch.no_grad():
        pa = a.inference(xt, batch_size=128)
        pb = b.inference(xt, batch_size=128)
    for column in ("GP_mean", "GP_variance", "GP_std"):
        np.testing.assert_array_equal(pa[column].to_numpy(), pb[column].to_numpy())


def test_flat_topology_round_trip_is_exact():
    X, y = _inputs()
    trained = _build(X, y)
    rebuilt = _build(X, y, topology=model_topology(trained))
    rebuilt.load_state_dict(trained.state_dict())

    _assert_same_structure(trained, rebuilt)
    _assert_same_predictions(trained, rebuilt)


def test_hierarchical_topology_round_trip_is_exact():
    X, y = _inputs()
    trained = _build(X, y, hierarchical=True)
    rebuilt = _build(X, y, topology=model_topology(trained), hierarchical=True)
    rebuilt.load_state_dict(trained.state_dict())

    assert hasattr(rebuilt, "_hierarchical_nn_idx")
    _assert_same_structure(trained, rebuilt)
    _assert_same_predictions(trained, rebuilt)


def test_rebuild_without_topology_still_works():
    """Checkpoints predating the topology key must still load."""
    X, y = _inputs()
    trained = _build(X, y)
    rebuilt = _build(X, y, topology=None)
    rebuilt.load_state_dict(trained.state_dict())

    _assert_same_structure(trained, rebuilt)
    _assert_same_predictions(trained, rebuilt)


def test_topology_is_host_resident_and_complete():
    """It gets torch.save'd next to the state dict, so it must load anywhere."""
    X, y = _inputs()
    topology = model_topology(_build(X, y, hierarchical=True))

    assert set(topology) >= {"inducing_points", "nn_xinduce_idx",
                             "inducing_are_data", "hierarchical_nn_idx"}
    for key, value in topology.items():
        if torch.is_tensor(value):
            assert value.device.type == "cpu", f"{key} is not on the host"

    m_ind = topology["inducing_points"].shape[-2]
    assert topology["nn_xinduce_idx"].shape[-2:] == (m_ind - K, K)


def test_mismatched_nn_index_is_rejected():
    """A topology from a different model must fail loudly, not silently load."""
    X, y = _inputs()
    topology = model_topology(_build(X, y))
    topology["nn_xinduce_idx"] = topology["nn_xinduce_idx"][:-1]

    try:
        _build(X, y, topology=topology)
    except ValueError as exc:
        assert "nn_xinduce_idx" in str(exc)
    else:
        raise AssertionError("a truncated nn_xinduce_idx was accepted")


def test_hierarchical_dag_reaches_the_strategy():
    """The DAG must become the strategy's edges, not just a model attribute.

    GPyTorch reads nn_xinduce_idx only in _stochastic_kl_helper, so those edges
    ARE the NNGP prior p(u). A hierarchical run whose strategy still holds a
    sequential k-NN index has trained against the flat prior, while the pathwise
    sampler draws from the hierarchical one.
    """
    X, y = _inputs()
    model = _build(X, y, hierarchical=True)

    strategy_idx = model.variational_strategy.nn_xinduce_idx.squeeze()
    assert strategy_idx.shape == model._hierarchical_nn_idx.squeeze().shape
    assert torch.equal(strategy_idx, model._hierarchical_nn_idx.squeeze())


def test_hierarchical_topology_stores_one_index_copy():
    """Both keys name the same edges, so the checkpoint must hold them once.

    Detaching each separately would write the (M-k, k) index twice -- about
    128 MB of duplicate int64 at M=500k, k=32.
    """
    X, y = _inputs()
    topology = model_topology(_build(X, y, hierarchical=True))

    flat, hier = topology["nn_xinduce_idx"], topology["hierarchical_nn_idx"]
    assert torch.equal(flat, hier)
    assert flat.data_ptr() == hier.data_ptr(), "the DAG is stored twice"


def test_hierarchical_edges_survive_a_topology_round_trip():
    X, y = _inputs()
    trained = _build(X, y, hierarchical=True)
    rebuilt = _build(X, y, topology=model_topology(trained), hierarchical=True)

    assert torch.equal(
        rebuilt.variational_strategy.nn_xinduce_idx.squeeze().cpu(),
        trained.variational_strategy.nn_xinduce_idx.squeeze().cpu())
