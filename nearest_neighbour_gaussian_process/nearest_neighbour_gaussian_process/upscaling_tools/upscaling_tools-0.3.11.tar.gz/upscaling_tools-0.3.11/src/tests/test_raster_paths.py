"""The raster writers must create the directory they actually write into.

Both write_ers and write_geotiff used to `makedirs(f"{savepath}/grids/")` and
then write to `{savepath}/`, leaving an empty grids/ behind on every call. The
makedirs is still load-bearing -- callers rely on it to create savepath itself
(cluster_realisations never creates its per-cluster export directories) -- so
the fix is to create savepath, not to drop the call.

Stubs stand in for the xarray/rioxarray objects so the path behaviour is
testable without the raster stack installed.
"""
import os

import pytest

# raster.py imports rioxarray at module scope; skip where the raster stack is absent.
pytest.importorskip("rioxarray")

from upscaling_tools.raster import write_ers, write_geotiff  # noqa: E402


class _Rio:
    def __init__(self, sink):
        self._sink = sink

    def to_raster(self, path, **kwargs):
        self._sink.append(path)
        with open(path, "w") as handle:
            handle.write("")


class _Band:
    def __init__(self, sink):
        self.rio = _Rio(sink)


class _Dataset:
    """Minimal stand-in: indexing by name or by list both yield a writable band."""

    def __init__(self):
        self.written = []

    def __getitem__(self, key):
        return _Band(self.written)


def test_write_ers_creates_savepath_not_a_grids_subdir(tmp_path):
    savepath = os.path.join(str(tmp_path), "export", "cluster_0", "grids")
    ds = _Dataset()

    _, returned = write_ers(ds, "easting", "northing", savepath, ["band_a", "band_b"],
                            csv_path=False)

    assert returned == savepath
    assert os.path.isdir(savepath), "savepath must still be created for the caller"
    assert ds.written == [f"{savepath}/band_a.ers", f"{savepath}/band_b.ers"]
    assert not os.path.exists(os.path.join(savepath, "grids"))


def test_write_geotiff_creates_savepath_not_a_grids_subdir(tmp_path):
    savepath = os.path.join(str(tmp_path), "tiffs", "cluster_0")
    ds = _Dataset()

    write_geotiff(ds, "easting", "northing", savepath, ["band_a"],
                  fname="cluster_0_images.tiff", csv_path=False)

    assert os.path.isdir(savepath)
    assert ds.written == [f"{savepath}/cluster_0_images.tiff"]
    assert not os.path.exists(os.path.join(savepath, "grids"))


def test_writers_create_missing_parent_directories(tmp_path):
    # cluster_realisations never creates these itself -- it relies on the
    # writers doing it on the way down.
    savepath = os.path.join(str(tmp_path), "a", "b", "c")
    write_ers(_Dataset(), "easting", "northing", savepath, ["band"], csv_path=False)
    assert os.path.isdir(savepath)
