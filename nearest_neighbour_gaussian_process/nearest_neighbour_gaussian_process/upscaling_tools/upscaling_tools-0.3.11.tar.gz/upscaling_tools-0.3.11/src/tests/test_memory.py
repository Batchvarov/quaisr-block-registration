"""nngp_posterior_batch_size is a memory knob, so only its clamps are contractual.

Peak memory on the NNGP evaluation path is O(batch * k^2), so the batch must
fall as k rises and as the dtype widens, and must never leave the clamped range
whatever free memory reports.
"""
import torch

from upscaling_tools.memory import (
    BATCH_CEILING,
    BATCH_CPU_DEFAULT,
    BATCH_FLOOR,
    nngp_posterior_batch_size,
)

# 8 GiB free, which is inside both clamps for the k used below.
FREE_BYTES = 8 * (1 << 30)


def _fake_cuda(monkeypatch, free=FREE_BYTES):
    monkeypatch.setattr(torch.cuda, "is_available", lambda: True)
    monkeypatch.setattr(torch.cuda, "mem_get_info", lambda *a, **kw: (free, free))


def test_cpu_returns_the_fixed_default(monkeypatch):
    monkeypatch.setattr(torch.cuda, "is_available", lambda: False)
    assert nngp_posterior_batch_size(k=32) == BATCH_CPU_DEFAULT


def test_large_k_clamps_to_the_floor(monkeypatch):
    _fake_cuda(monkeypatch)
    assert nngp_posterior_batch_size(k=100_000) == BATCH_FLOOR


def test_small_k_clamps_to_the_ceiling(monkeypatch):
    _fake_cuda(monkeypatch)
    assert nngp_posterior_batch_size(k=1) == BATCH_CEILING


def test_a_wider_dtype_halves_the_batch(monkeypatch):
    _fake_cuda(monkeypatch)
    k = 64
    narrow = nngp_posterior_batch_size(k, dtype_bytes=4)
    wide = nngp_posterior_batch_size(k, dtype_bytes=8)
    assert BATCH_FLOOR < wide < narrow < BATCH_CEILING
    assert wide == narrow // 2


def test_the_batch_falls_as_k_rises(monkeypatch):
    _fake_cuda(monkeypatch)
    assert nngp_posterior_batch_size(k=32) > nngp_posterior_batch_size(k=128)
