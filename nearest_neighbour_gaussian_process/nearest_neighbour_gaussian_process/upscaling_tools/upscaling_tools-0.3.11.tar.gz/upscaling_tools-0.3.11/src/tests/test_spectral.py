import gpytorch
import numpy as np
import pytest
import torch

from upscaling_tools.nngp_fft_prior import GridSpec, _fft_sample_stationary
from upscaling_tools.spectral import (
    additive_correlation,
    bootstrap_ladder,
    correlation_range,
    empirical_correlation,
    fit_ladder,
    kernel_correlation,
    matern_correlation,
    spectral_misfit,
)


def _matern(lengthscale: float, nu: float, outputscale: float = 1.0):
    kernel = gpytorch.kernels.ScaleKernel(gpytorch.kernels.MaternKernel(nu=nu))
    kernel.base_kernel.lengthscale = torch.tensor(lengthscale)
    kernel.outputscale = torch.tensor(outputscale)
    return kernel


def _grid_points(grid: GridSpec) -> np.ndarray:
    axes = [
        torch.linspace(float(lo), float(hi), n, dtype=torch.float64)
        for lo, hi, n in zip(grid.mins, grid.maxs, grid.shape)
    ]
    mesh = torch.meshgrid(*axes, indexing="ij")
    return torch.stack(mesh, dim=-1).reshape(-1, len(axes)).numpy()


@pytest.mark.parametrize("nu", [0.5, 1.5, 2.5])
def test_matern_correlation_matches_gpytorch(nu):
    lags = np.linspace(0.0, 1.0, 25)
    kernel = _matern(0.2, nu)

    left = torch.zeros(len(lags), 2, dtype=torch.float32)
    right = torch.zeros(len(lags), 2, dtype=torch.float32)
    right[:, 0] = torch.as_tensor(lags, dtype=torch.float32)
    with torch.no_grad():
        expected = torch.stack([
            kernel(left[i:i + 1], right[i:i + 1]).to_dense().squeeze()
            for i in range(len(lags))
        ]).numpy()

    np.testing.assert_allclose(matern_correlation(lags, 0.2, nu), expected, atol=1e-5)


def test_matern_correlation_rejects_unsupported_nu():
    with pytest.raises(ValueError):
        matern_correlation(np.array([1.0]), 1.0, 3.5)


def test_kernel_correlation_matches_closed_form():
    lags = np.geomspace(0.01, 2.0, 30)
    kernel = _matern(0.3, 1.5, outputscale=7.0)
    np.testing.assert_allclose(
        kernel_correlation(kernel, lags),
        matern_correlation(lags, 0.3, 1.5),
        atol=1e-5,
    )


def test_kernel_correlation_of_additive_kernel_is_variance_weighted():
    lags = np.geomspace(0.01, 2.0, 30)
    kernel = gpytorch.kernels.AdditiveKernel(
        _matern(0.05, 1.5, outputscale=0.25),
        _matern(0.50, 2.5, outputscale=0.75),
    )
    expected = additive_correlation(lags, [0.05, 0.50], [0.25, 0.75], [1.5, 2.5])
    np.testing.assert_allclose(kernel_correlation(kernel, lags), expected, atol=1e-5)


def _draw_field(lengthscale: float, nu: float, shape: int, n_samples: int, seed: int):
    torch.manual_seed(seed)
    grid = GridSpec(mins=[0.0, 0.0], maxs=[1.0, 1.0], shape=(shape, shape))
    kernel = _matern(lengthscale, nu)
    draws = _fft_sample_stationary(kernel, grid, torch.Size([n_samples]), padding_factor=2)
    return _grid_points(grid), draws.reshape(n_samples, -1).double().numpy()


def test_empirical_correlation_recovers_matern():
    lengthscale, nu = 0.05, 1.5
    points, fields = _draw_field(lengthscale, nu, shape=96, n_samples=12, seed=0)

    curves = [
        empirical_correlation(points, field, min_lag=0.01, max_lag=0.30,
                              n_pairs=400_000, n_bins=20, seed=index)
        for index, field in enumerate(fields)
    ]
    lags = curves[0].lags
    rho = np.mean([curve.rho for curve in curves], axis=0)

    expected = matern_correlation(lags, lengthscale, nu)
    assert np.max(np.abs(rho - expected)) < 0.06
    assert spectral_misfit(lags, rho, expected) < 0.03


def test_empirical_correlation_ignores_a_linear_trend():
    points, fields = _draw_field(0.05, 1.5, shape=64, n_samples=1, seed=3)
    values = fields[0]
    tilted = values + 4.0 * points[:, 0] - 2.5 * points[:, 1] + 11.0

    plain = empirical_correlation(points, values, min_lag=0.02, max_lag=0.3, n_pairs=200_000)
    sloped = empirical_correlation(points, tilted, min_lag=0.02, max_lag=0.3, n_pairs=200_000)

    np.testing.assert_allclose(plain.rho, sloped.rho, atol=1e-8)


def test_empirical_correlation_needs_enough_pairs_per_bin():
    points, fields = _draw_field(0.05, 1.5, shape=32, n_samples=1, seed=4)
    with pytest.raises(ValueError, match="lag bins"):
        empirical_correlation(points, fields[0], min_lag=1e-6, max_lag=1e-5, n_pairs=1000)


def test_correlation_range_interpolates_in_log_lag():
    lags = np.array([1.0, 10.0, 100.0])
    rho = np.array([1.0, 0.6, 0.2])
    assert correlation_range(lags, rho, 0.6) == pytest.approx(10.0)
    assert correlation_range(lags, rho, 0.4) == pytest.approx(np.exp(np.log(10.0) + 0.5 * np.log(10.0)))
    assert np.isnan(correlation_range(lags, rho, 0.1))


def _synthetic_curve(lags, lengthscales, variances, nus):
    from upscaling_tools.spectral import CorrelationCurve
    rho = additive_correlation(lags, lengthscales, variances, nus)
    return CorrelationCurve(lags=lags, rho=rho, counts=np.full(len(lags), 1000), variance=1.0)


def test_fit_ladder_recovers_known_components():
    lengthscales = [0.60, 0.08, 0.01]
    variances = [0.30, 0.45, 0.15]
    nus = (2.5, 1.5, 1.5)
    lags = np.geomspace(0.002, 2.0, 40)
    curve = _synthetic_curve(lags, lengthscales, variances, nus)

    ladder = fit_ladder(curve, min_lengthscale=0.005, max_lengthscale=3.0, nus=nus)

    assert ladder.misfit < 0.01
    np.testing.assert_allclose(ladder.lengthscales, lengthscales, rtol=0.15)
    np.testing.assert_allclose(ladder.variances, variances, atol=0.05)
    assert ladder.unrepresentable == pytest.approx(0.10, abs=0.03)


def test_fit_ladder_reports_variance_below_the_floor():
    lags = np.geomspace(0.05, 2.0, 30)
    curve = _synthetic_curve(lags, [0.5, 0.004], [0.4, 0.6], (2.5, 1.5))

    ladder = fit_ladder(curve, min_lengthscale=0.05, max_lengthscale=3.0, nus=(2.5, 1.5))

    assert ladder.unrepresentable > 0.4
    assert ladder.lengthscales.min() >= 0.05 - 1e-9


def test_fit_ladder_returns_lengthscales_in_descending_order():
    lags = np.geomspace(0.002, 2.0, 40)
    curve = _synthetic_curve(lags, [0.60, 0.08, 0.01], [0.30, 0.45, 0.15], (2.5, 1.5, 1.5))
    ladder = fit_ladder(curve, min_lengthscale=0.005, max_lengthscale=3.0)
    assert np.all(np.diff(ladder.lengthscales) <= 0)
    assert len(ladder.nus) == 3


def test_empirical_correlation_covers_lags_far_below_the_domain():
    """Short bins must be populated, whatever the ratio of lag to domain.

    Pairs drawn uniformly over the point set land at a lag h at a rate of
    (h / domain)^2, so bins three decades below the domain would hold a handful
    of pairs and the correlation there would be noise.
    """
    points, fields = _draw_field(0.05, 1.5, shape=128, n_samples=1, seed=7)
    pitch = 1.0 / 127

    curve = empirical_correlation(points, fields[0], min_lag=pitch, max_lag=1.0,
                                  n_pairs=400_000, n_bins=30)

    # Uniformly drawn pairs would put about 400_000 * pitch ** 2, or 25 pairs,
    # in the whole range below 4 * pitch.
    short = curve.lags < 4 * pitch
    assert short.sum() >= 3
    assert curve.counts[short].min() > 1000
    assert curve.rho[short].min() > 0.75


def test_empirical_correlation_rejects_non_2d_points():
    values = np.arange(50, dtype=float)
    points = np.column_stack([values, values, values])
    with pytest.raises(ValueError, match="2D points"):
        empirical_correlation(points, values, min_lag=1.0, max_lag=10.0)


def _two_scale_field(seed, shape=96):
    """A field with a long and a short component, so a ladder has work to do."""
    torch.manual_seed(seed)
    grid = GridSpec(mins=[0.0, 0.0], maxs=[1.0, 1.0], shape=(shape, shape))
    long = _fft_sample_stationary(_matern(0.30, 2.5), grid, torch.Size([1]))[0]
    short = _fft_sample_stationary(_matern(0.03, 1.5), grid, torch.Size([1]))[0]
    field = (0.7 * long + 0.7 * short).reshape(-1).double().numpy()
    return _grid_points(grid), field


def _bootstrap(field_seed, nus=(2.5, 1.5), **kwargs):
    points, values = _two_scale_field(field_seed)
    pitch = 1.0 / 95
    return bootstrap_ladder(
        points, values, min_lengthscale=pitch, max_lengthscale=2.0,
        min_lag=pitch, max_lag=1.0, n_replicates=8, n_pairs=120_000, n_bins=20,
        nus=nus, **kwargs)


def test_bootstrap_ladder_reports_one_spread_per_component():
    result = _bootstrap(11, nus=(2.5, 1.5, 1.5))

    assert result.n_replicates <= 8
    assert len(result.lengthscale_log_sd) == 3
    assert np.all(result.lengthscale_log_sd >= 0)
    assert np.all(np.isfinite(result.lengthscale_log_sd))


def test_bootstrap_ladder_identifies_the_total_variance():
    """The policy caps outputscales by the total, so the total must be recovered.

    The two components carry 0.49 each, and the fit is floored well below the
    short one, so the whole 0.98 is representable.
    """
    for seed in (11, 12, 13):
        result = _bootstrap(seed)
        assert result.total_variance == pytest.approx(0.98, rel=0.2), f"seed {seed}"


def test_bootstrap_ladder_pins_the_total_better_than_any_component_variance():
    """Why outputscales are not banded per component: the split is not identified.

    Matern components at adjacent lengthscales are close to collinear, so
    replicates trade variance between them while tracing the same total curve.
    """
    points, values = _two_scale_field(11)
    pitch = 1.0 / 95
    totals, per_component = [], []
    for replicate in range(8):
        curve = empirical_correlation(points, values, min_lag=pitch, max_lag=1.0,
                                      n_pairs=120_000, n_bins=20, seed=replicate)
        ladder = fit_ladder(curve, pitch, 2.0)
        totals.append(ladder.variances.sum())
        per_component.append(ladder.variances)

    spread = lambda a: np.std(a) / max(np.mean(a), 1e-12)
    worst_component = max(spread(np.array(per_component)[:, j]) for j in range(3))
    assert spread(np.array(totals)) < 0.2 * worst_component


def test_bootstrap_ladder_is_deterministic_given_a_seed():
    first, second = _bootstrap(13, seed=4), _bootstrap(13, seed=4)
    np.testing.assert_allclose(first.lengthscale_log_sd, second.lengthscale_log_sd)
    assert first.total_variance == second.total_variance


def test_bootstrap_ladder_rejects_too_few_usable_blocks():
    points, values = _two_scale_field(14, shape=32)
    with pytest.raises(ValueError, match="blocks hold enough points"):
        bootstrap_ladder(points, values, min_lengthscale=0.02, max_lengthscale=2.0,
                         min_lag=0.02, max_lag=1.0, n_blocks=40, n_replicates=4)
