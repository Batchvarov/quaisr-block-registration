"""A predictive nugget that varies in space.

One nugget assumes the variance the kernel cannot represent is the same
everywhere. Where it is not, the survey-wide rate can look calibrated while both
halves of the survey are wrong in opposite directions. These tests pin the field
that replaces it, and in particular what it does where the residuals run out.
"""

import numpy as np
import pytest

from upscaling_tools.calibration import (
    MIN_CALIBRATION_POINTS,
    coverage,
    cross_fitted_field_error_rate,
    fit_nugget_field,
    fit_predictive_nugget,
    nugget_at,
)

CONTROL = np.array([[0.25, 0.5], [0.75, 0.5]])
RADIUS = 0.25


def _two_regimes(n=1200, quiet_sd=0.1, loud_sd=1.0, variance=0.002, seed=0):
    """Residuals ten times larger on the right half, on a too-narrow interval.

    The reported variance is too small for both halves, so neither is covered by
    accident -- a fixture where the quiet half is already over-covered would let
    a broken field pass.
    """
    rng = np.random.default_rng(seed)
    points = rng.uniform(0, 1, size=(n, 2))
    sd = np.where(points[:, 0] < 0.5, quiet_sd, loud_sd)
    return points, rng.normal(0.0, sd), np.full(n, variance)


def _halves(points):
    left = points[:, 0] < 0.5
    return left, ~left


def test_the_field_separates_the_two_regimes():
    points, residual, variance = _two_regimes()
    quiet, loud = fit_nugget_field(points, residual, variance, CONTROL, RADIUS).values
    assert loud > 20 * quiet, f"quiet {quiet:.4f} loud {loud:.4f}"


def test_one_nugget_hides_two_opposite_errors():
    """The defect the field exists to fix, and the statistic that conceals it."""
    points, residual, variance = _two_regimes()
    left, right = _halves(points)

    single = fit_predictive_nugget(residual, variance)
    aggregate = 1 - coverage(residual, variance + single)
    assert abs(aggregate - 0.05) < 0.01, "the survey-wide rate looks calibrated"
    assert 1 - coverage(residual[left], variance[left] + single) < 0.01
    assert 1 - coverage(residual[right], variance[right] + single) > 0.09

    field = fit_nugget_field(points, residual, variance, CONTROL, RADIUS)
    corrected = variance + nugget_at(points, field)
    assert 1 - coverage(residual[left], corrected[left]) < 0.08
    assert 1 - coverage(residual[right], corrected[right]) < 0.08


def test_the_field_reproduces_its_node_values_at_the_nodes():
    """Guards the leak: a wide interpolation lets a loud node swamp a quiet one.

    These values span orders of magnitude, so a tenth of the weight landing on a
    node a hundred times larger is enough to bury the local answer.
    """
    points, residual, variance = _two_regimes()
    field = fit_nugget_field(points, residual, variance, CONTROL, RADIUS)
    at_nodes = nugget_at(CONTROL, field)
    assert np.allclose(at_nodes, field.values, rtol=0.1), f"{at_nodes} vs {field.values}"


def test_the_interpolation_width_defaults_to_half_the_fit_radius():
    points, residual, variance = _two_regimes()
    field = fit_nugget_field(points, residual, variance, CONTROL, RADIUS)
    assert field.width == pytest.approx(RADIUS / 2)
    wider = fit_nugget_field(points, residual, variance, CONTROL, RADIUS, width=RADIUS)
    assert wider.width == pytest.approx(RADIUS)
    # The wide setting is what leaks; keeping it reachable keeps that testable.
    assert nugget_at(CONTROL, wider)[0] > 5 * nugget_at(CONTROL, field)[0]


def test_the_cross_fitted_rate_stays_sane():
    """A field has one parameter per node, so it can chase its own fit."""
    points, residual, variance = _two_regimes()
    rate = cross_fitted_field_error_rate(points, residual, variance, CONTROL, RADIUS)
    assert 0.02 < rate < 0.08, rate


def test_a_uniform_field_reproduces_the_single_nugget():
    rng = np.random.default_rng(1)
    points = rng.uniform(0, 1, size=(800, 2))
    residual = rng.normal(0.0, 0.5, size=800)
    variance = np.full(800, 0.04)

    single = fit_predictive_nugget(residual, variance)
    field = fit_nugget_field(points, residual, variance, CONTROL, RADIUS)
    assert np.allclose(field.values, single, rtol=0.25)


def test_a_thin_node_falls_back_to_the_survey_wide_fit():
    """A nugget fitted on a handful of residuals measures the points, not the field."""
    points, residual, variance = _two_regimes()
    control = np.vstack([CONTROL, [5.0, 5.0]])
    field = fit_nugget_field(points, residual, variance, control, RADIUS)
    assert field.counts[-1] < MIN_CALIBRATION_POINTS
    assert field.values[-1] == pytest.approx(field.global_nugget)


def test_interpolation_stays_between_the_node_values():
    points, residual, variance = _two_regimes()
    field = fit_nugget_field(points, residual, variance, CONTROL, RADIUS)
    grid = np.stack(np.meshgrid(np.linspace(-1, 2, 40), np.linspace(-1, 2, 40)),
                    axis=-1).reshape(-1, 2)
    values = nugget_at(grid, field)
    assert values.min() >= min(field.values.min(), field.global_nugget) - 1e-12
    assert values.max() <= max(field.values.max(), field.global_nugget) + 1e-12


def test_far_from_every_node_the_field_returns_the_survey_wide_value():
    """A gap wider than the control spacing has no local evidence to offer."""
    points, residual, variance = _two_regimes()
    field = fit_nugget_field(points, residual, variance, CONTROL, RADIUS)
    assert nugget_at(np.array([[500.0, 500.0]]), field)[0] == pytest.approx(
        field.global_nugget)


def test_the_field_is_never_negative():
    points, residual, variance = _two_regimes()
    field = fit_nugget_field(points, residual, variance, CONTROL, RADIUS)
    assert (field.values >= 0).all()
    grid = np.random.default_rng(2).uniform(-1, 2, size=(500, 2))
    assert (nugget_at(grid, field) >= 0).all()


def test_an_already_wide_interval_asks_for_nothing():
    rng = np.random.default_rng(3)
    points = rng.uniform(0, 1, size=(600, 2))
    residual = rng.normal(0.0, 0.05, size=600)
    field = fit_nugget_field(points, residual, np.full(600, 4.0), CONTROL, RADIUS)
    assert (field.values == 0).all()


def test_chunking_does_not_change_the_result():
    points, residual, variance = _two_regimes()
    field = fit_nugget_field(points, residual, variance, CONTROL, RADIUS)
    grid = np.random.default_rng(4).uniform(0, 1, size=(1000, 2))
    assert np.allclose(nugget_at(grid, field), nugget_at(grid, field, chunk=37))


def test_a_field_survives_the_checkpoint_round_trip():
    """The training block pickles this into the .pth the inference block loads."""
    import io

    import torch

    points, residual, variance = _two_regimes()
    field = fit_nugget_field(points, residual, variance, CONTROL, RADIUS)

    buffer = io.BytesIO()
    torch.save({"predictive_nugget_field": field}, buffer)
    buffer.seek(0)
    restored = torch.load(buffer, weights_only=False)["predictive_nugget_field"]

    grid = np.random.default_rng(5).uniform(0, 1, size=(200, 2))
    assert np.allclose(nugget_at(grid, restored), nugget_at(grid, field))
    assert restored.width == field.width
    assert restored.global_nugget == field.global_nugget


def test_an_absent_field_is_distinguishable_from_a_zero_one():
    """Old checkpoints carry no field at all; the scalar path has to stay reachable."""
    load_data = {"predictive_nugget": 0.3}
    assert load_data.get("predictive_nugget_field") is None
