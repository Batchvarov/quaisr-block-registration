import math

import pytest

from upscaling_tools.nngp import construct_likelihood


@pytest.mark.parametrize("noise", [1e-8, 1e-4, 1e-2, 1.0])
def test_fixed_noise_is_finite_and_frozen(noise):
    """The requested noise must sit strictly inside its Interval.

    Setting it exactly at the upper bound makes Interval's inverse sigmoid,
    log((v - lower) / (upper - v)), divide by zero, so raw_noise is stored as
    +inf and written straight into the saved state dict.
    """
    lik = construct_likelihood({'noise': noise})
    raw = lik.noise_covar.raw_noise

    assert math.isfinite(raw.item()), "raw_noise is non-finite (value sat on the bound)"
    assert not raw.requires_grad, "noise must stay fixed, not fitted"
    assert abs(lik.noise.item() - noise) / noise < 1e-3


def test_noise_floor_applies_to_missing_and_tiny_values():
    assert construct_likelihood({}).noise.item() == pytest.approx(1e-4, rel=1e-3)
    assert construct_likelihood({'noise': 0.0}).noise.item() == pytest.approx(1e-8, rel=1e-3)
