"""The prior draw for a kernel with a modulated component.

The FFT sampler embeds a covariance that depends on the lag alone, so it cannot
be handed a modulated kernel. `draw_prior_paths` draws each component from its
stationary part instead and multiplies g(x) back in. These tests check that the
sum has the covariance of the modulated kernel, not of the stationary one.
"""

import types

import gpytorch
import torch

from upscaling_tools.kernels import (
    AmplitudeModulatedKernel,
    control_grid,
    split_modulated,
)
from upscaling_tools.nngp_fft_prior import GridSpec
from upscaling_tools.nngp_sampling import SumOfPriorPaths, draw_prior_paths

GRID = GridSpec(mins=[0.0, 0.0], maxs=[1.0, 1.0], shape=(10, 10))


def _grid_points(grid=GRID):
    axes = [torch.linspace(float(lo), float(hi), n)
            for lo, hi, n in zip(grid.mins, grid.maxs, grid.shape)]
    return torch.stack(torch.meshgrid(*axes, indexing="ij"), dim=-1).reshape(-1, 2)


def _matern(lengthscale, outputscale=1.0):
    kernel = gpytorch.kernels.ScaleKernel(gpytorch.kernels.MaternKernel(nu=1.5))
    kernel.base_kernel.lengthscale = torch.tensor(lengthscale)
    kernel.outputscale = torch.tensor(outputscale)
    return kernel


def _modulated(lengthscale, weights, outputscale=1.0, cap=2.0):
    kernel = AmplitudeModulatedKernel(
        _matern(lengthscale, outputscale),
        control_points=control_grid(_grid_points(), 2),
        control_lengthscale=0.5,
        log_amplitude_constraint=gpytorch.constraints.Interval(-cap, cap))
    kernel.raw_log_amplitude.data = kernel.raw_log_amplitude_constraint.inverse_transform(
        torch.tensor(weights))
    return kernel


def _model(kernel, points):
    """The two attributes both prior samplers read off a model."""
    return types.SimpleNamespace(
        covar_module=kernel,
        variational_strategy=types.SimpleNamespace(inducing_points=points))


def _empirical_covariance(paths, points, n_samples):
    draws = paths(points)
    assert draws.shape == (n_samples, len(points))
    return (draws.mT @ draws) / n_samples


def test_split_puts_each_component_in_one_group():
    plain, modulated = _matern(0.3), _modulated(0.1, [-1.0, 0.5, 0.0, 1.0])
    stationary, found = split_modulated(gpytorch.kernels.AdditiveKernel(plain, modulated))
    assert found == [modulated]
    assert list(stationary.kernels) == [plain]


def test_split_leaves_an_unmodulated_kernel_alone():
    kernel = gpytorch.kernels.AdditiveKernel(_matern(0.3), _matern(0.1))
    stationary, modulated = split_modulated(kernel)
    assert stationary is kernel
    assert modulated == []


def test_split_handles_a_kernel_that_is_modulated_throughout():
    kernel = _modulated(0.1, [-1.0, 0.5, 0.0, 1.0])
    stationary, modulated = split_modulated(kernel)
    assert stationary is None
    assert modulated == [kernel]


def test_an_unmodulated_kernel_is_not_wrapped():
    points = _grid_points()
    model = _model(gpytorch.kernels.AdditiveKernel(_matern(0.3)), points)
    paths = draw_prior_paths(model, torch.Size([4]), output_grid=GRID)
    assert not isinstance(paths, SumOfPriorPaths)


def test_drawn_covariance_matches_the_modulated_kernel():
    """The point of the whole split: g(x) must reach the realisations."""
    torch.manual_seed(0)
    points = _grid_points()
    kernel = gpytorch.kernels.AdditiveKernel(
        _matern(0.35, outputscale=1.0),
        _modulated(0.12, [-1.5, 1.5, 1.5, -1.5], outputscale=1.0))
    model = _model(kernel, points)

    n_samples = 4000
    paths = draw_prior_paths(model, torch.Size([n_samples]), output_grid=GRID)
    assert isinstance(paths, SumOfPriorPaths)
    empirical = _empirical_covariance(paths, points, n_samples)

    with torch.no_grad():
        expected = kernel(points).to_dense()
    error = (empirical - expected).norm() / expected.norm()
    assert error < 0.15, f"covariance relative error {error:.3f}"


def test_the_drawn_covariance_is_not_the_stationary_one():
    """Guards the failure the split exists to stop: g silently dropped.

    One modulated component and nothing else, so g carries the whole difference.
    Mixed with a long stationary component the two covariances sit close enough
    that the comparison stops discriminating.
    """
    torch.manual_seed(0)
    points = _grid_points()
    modulated = _modulated(0.12, [-1.8, 1.8, 1.8, -1.8])
    model = _model(gpytorch.kernels.AdditiveKernel(modulated), points)

    n_samples = 4000
    paths = draw_prior_paths(model, torch.Size([n_samples]), output_grid=GRID)
    empirical = _empirical_covariance(paths, points, n_samples)

    with torch.no_grad():
        expected = modulated(points).to_dense()
        stationary = modulated.stationary_part()(points).to_dense()

    to_modulated = (empirical - expected).norm() / expected.norm()
    to_stationary = (empirical - stationary).norm() / stationary.norm()
    assert to_modulated < 0.15, f"{to_modulated:.3f}"
    assert to_stationary > 3 * to_modulated, (
        f"draw is no closer to the modulated kernel ({to_modulated:.3f}) "
        f"than to the stationary one ({to_stationary:.3f})")


def test_the_amplitude_shapes_the_realisation_variance():
    """A tile with a large g must draw rougher paths than one with a small g."""
    torch.manual_seed(0)
    points = _grid_points()
    modulated = _modulated(0.08, [-1.8, -1.8, 1.8, 1.8])
    model = _model(gpytorch.kernels.AdditiveKernel(modulated), points)

    n_samples = 3000
    paths = draw_prior_paths(model, torch.Size([n_samples]), output_grid=GRID)
    variance = paths(points).var(dim=0)

    amplitude = modulated.amplitude(points)
    quiet = variance[amplitude < amplitude.median()].mean()
    loud = variance[amplitude > amplitude.median()].mean()
    assert loud > 3 * quiet, f"quiet {quiet:.4f} loud {loud:.4f}"


def test_each_group_keeps_its_own_cached_spectrum():
    """One cache slot would rebuild the sampler's largest piece of work per group."""
    points = _grid_points()
    kernel = gpytorch.kernels.AdditiveKernel(
        _matern(0.35), _modulated(0.12, [-1.0, 1.0, 1.0, -1.0]))
    model = _model(kernel, points)

    draw_prior_paths(model, torch.Size([2]), output_grid=GRID)
    assert len(model._fft_spectrum_cache) == 2
    draw_prior_paths(model, torch.Size([2]), output_grid=GRID)
    assert len(model._fft_spectrum_cache) == 2


def test_the_model_keeps_its_kernel_after_a_split_draw():
    points = _grid_points()
    kernel = gpytorch.kernels.AdditiveKernel(
        _matern(0.35), _modulated(0.12, [-1.0, 1.0, 1.0, -1.0]))
    model = _model(kernel, points)
    draw_prior_paths(model, torch.Size([2]), output_grid=GRID)
    assert model.covar_module is kernel
