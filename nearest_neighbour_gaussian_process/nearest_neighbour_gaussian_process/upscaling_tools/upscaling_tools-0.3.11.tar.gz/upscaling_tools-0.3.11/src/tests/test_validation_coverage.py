"""compute_deutsch_coverages was vectorised; it must still agree with the
per-point reference it replaced."""
import numpy as np
import pandas as pd
import scipy.stats

from upscaling_tools.validation import compute_deutsch_coverages


def _reference(gp_infer, measured, p):
    normals = [scipy.stats.norm(loc=row["GP_mean"], scale=row["GP_std"])
               for _, row in gp_infer.iterrows()]
    indicators = []
    for dist, u in zip(normals, measured):
        z = dist.ppf([(1 - p) / 2, (1 + p) / 2])
        indicators.append(1 if z[0] < u < z[1] else 0)
    return np.mean(indicators)


def _frame(n=200, seed=0):
    rng = np.random.default_rng(seed)
    mean = rng.normal(size=n)
    std = rng.uniform(0.1, 2.0, size=n)
    measured = mean + rng.normal(scale=std)
    return pd.DataFrame({"GP_mean": mean, "GP_std": std}), measured


def test_matches_the_per_point_reference():
    gp_infer, measured = _frame()
    ps = np.linspace(0, 1, num=20)

    got = compute_deutsch_coverages(gp_infer, measured, ps)
    expected = [_reference(gp_infer, measured, p) for p in ps]

    assert np.allclose(got, expected)


def test_scalar_p_returns_a_scalar():
    gp_infer, measured = _frame(n=50, seed=1)
    got = compute_deutsch_coverages(gp_infer, measured, 0.5)

    assert isinstance(got, float)
    assert got == _reference(gp_infer, measured, 0.5)
