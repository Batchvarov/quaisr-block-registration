"""NNGPModel.inference batches by slicing the tensor, not through a DataLoader.

DataLoader(TensorDataset(xs)) with auto-collation indexes the tensor one ROW at
a time and re-stacks each batch -- roughly a microsecond per point on the host,
and a separate device slice per point for a CUDA tensor, which at grid scale is
minutes of pure overhead. xs.split() hands out a view per batch.

That is a scheduling change only, so the numbers must be bit-identical to the
DataLoader implementation, and identical across batch sizes: batch size is a
memory knob (peak is O(batch * k^2) from the neighbour covariance), never a
term in the answer.
"""
import gpytorch
import numpy as np
import pandas as pd
import pytest
import torch
from torch.utils.data import DataLoader, TensorDataset

from upscaling_tools.nngp import construct_model

M = 150
K = 8
N_EVAL = 700


def _model(seed=0):
    torch.manual_seed(seed)
    X = torch.rand(M, 2)
    y = torch.sin(3 * X[:, 0]) * torch.cos(2 * X[:, 1])
    kernel = gpytorch.kernels.ScaleKernel(gpytorch.kernels.MaternKernel(nu=2.5))
    likelihood = gpytorch.likelihoods.GaussianLikelihood()
    parameters = {"k": K, "training_batch_size": 32, "learning_rate": 1e-2,
                  "training_epochs": 1, "milestones": []}
    model, _, _, _ = construct_model(X, y, kernel, likelihood, parameters)
    return model


def _points(seed=1):
    return torch.from_numpy(
        np.random.default_rng(seed).uniform(0.05, 0.95, size=(N_EVAL, 2))
    ).to(torch.float32)


def _reference_inference(model, xs, output_scaler=None, batch_size=32):
    """The pre-change implementation, verbatim."""
    dataset = TensorDataset(xs)
    data_loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)
    model.eval()
    model.likelihood.eval()
    means, variances = [], []
    with torch.no_grad():
        for xbatch in data_loader:
            preds = model.likelihood(model(xbatch[0]))
            means.append(preds.mean.cpu())
            variances.append(preds.variance.cpu())
    y_mean = torch.cat(means)
    y_var = torch.cat(variances)
    if output_scaler is not None:
        y_mean = output_scaler.inverse_transform(y_mean.unsqueeze(-1))
        y_var = y_var * np.square(output_scaler.scale_)
    return pd.DataFrame({
        "GP_mean": y_mean.flatten(),
        "GP_variance": y_var.flatten(),
        "GP_std": torch.sqrt(y_var.flatten()),
    })


COLUMNS = ("GP_mean", "GP_variance", "GP_std")


def test_matches_the_dataloader_implementation():
    model, xs = _model(), _points()
    with torch.no_grad():
        got = model.inference(xs, batch_size=256)
    expected = _reference_inference(model, xs, batch_size=256)

    for column in COLUMNS:
        np.testing.assert_array_equal(got[column].to_numpy(),
                                      expected[column].to_numpy())


@pytest.mark.parametrize("batch_size", [1, 97, 256, N_EVAL, N_EVAL * 4])
def test_batch_size_does_not_change_the_answer(batch_size):
    """Includes sizes that do not divide the point count, and one beyond it."""
    model, xs = _model(), _points()
    with torch.no_grad():
        reference = model.inference(xs, batch_size=256)
        got = model.inference(xs, batch_size=batch_size)

    assert len(got) == N_EVAL
    for column in COLUMNS:
        np.testing.assert_array_equal(got[column].to_numpy(),
                                      reference[column].to_numpy())


def test_output_scaler_is_applied_as_before():
    from sklearn.preprocessing import StandardScaler

    model, xs = _model(), _points()
    scaler = StandardScaler().fit(
        np.random.default_rng(2).normal(loc=3.0, scale=7.0, size=(500, 1)))

    with torch.no_grad():
        got = model.inference(xs, batch_size=128, output_scaler=scaler)
    expected = _reference_inference(model, xs, batch_size=128, output_scaler=scaler)

    for column in COLUMNS:
        np.testing.assert_allclose(got[column].to_numpy(),
                                   expected[column].to_numpy(), rtol=0, atol=0)
