import os

from upscaling_tools.plotting import save_plot


class _Fig:
    """Minimal stand-in for a holoviews/panel object with .save()."""

    def __init__(self):
        self.saved_to = None

    def save(self, path):
        self.saved_to = path
        with open(path, "w") as handle:
            handle.write("")


def test_save_plot_writes_inside_the_directory(tmp_path):
    savepath = os.path.join(str(tmp_path), "validation")
    fig = _Fig()

    path = save_plot(fig, savepath, "parity")

    assert path == os.path.join(savepath, "parity.html")
    assert os.path.isfile(path)
    assert fig.saved_to == path
    # The old form wrote <savepath>parity.html next to an empty directory.
    assert not os.path.exists(savepath + "parity.html")


def test_save_plot_does_not_collide_across_prefixed_savepaths(tmp_path):
    a = save_plot(_Fig(), os.path.join(str(tmp_path), "results"), "parity")
    b = save_plot(_Fig(), os.path.join(str(tmp_path), "results2"), "parity")
    assert a != b
