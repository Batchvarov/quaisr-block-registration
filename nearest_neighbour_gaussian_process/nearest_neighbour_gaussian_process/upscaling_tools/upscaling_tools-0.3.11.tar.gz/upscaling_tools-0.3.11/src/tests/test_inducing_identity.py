"""The inducing-vs-data identity must come from the allocator, not a count.

GridCountInducing derives its grid as n_north = round(sqrt(ninducing*h/w)),
n_east = round(ninducing/n_north), whose product can overshoot ninducing. The
masked grid can therefore contain exactly len(X) points while being nothing
like the data -- and the old `len(inducing) == len(X)` test then sent training
down the inducing-indexed branch, pairing every target with an unrelated
training output.
"""
import torch
import pytest

from upscaling_tools.inducing import (
    DatapointsAsInducing,
    GridCountInducing,
    HilbertSortedInducing,
    MiniBatchKMeansInducing,
)

N = 100
NINDUCING = 99


def _colliding_case(max_seeds=50):
    """A seed where the masked grid lands on exactly N points without being X."""
    for seed in range(max_seeds):
        torch.manual_seed(seed)
        X = torch.rand(N, 2)
        allocator = GridCountInducing(NINDUCING)
        Z = allocator.initialise(X)
        if len(Z) == N:
            return seed, X, allocator, Z
    return None


def test_count_collision_is_reachable():
    case = _colliding_case()
    assert case is not None, "no (n, ninducing) collision found -- test is no longer exercising the bug"
    _, X, _, Z = case
    assert len(Z) == len(X)
    assert not torch.equal(Z, X)


def test_colliding_grid_does_not_claim_to_be_the_data():
    _, _, allocator, _ = _colliding_case()
    assert allocator.returns_data_points is False


def test_grid_count_delegating_to_datapoints_is_the_data():
    torch.manual_seed(0)
    X = torch.rand(N, 2)
    allocator = GridCountInducing(2 * N)
    Z = allocator.initialise(X)

    assert allocator.returns_data_points is True
    assert torch.equal(Z, X)


def test_datapoints_allocator_flags():
    assert DatapointsAsInducing().returns_data_points is True
    assert DatapointsAsInducing(nsample=10).returns_data_points is False


def test_minibatch_kmeans_flags():
    torch.manual_seed(0)
    X = torch.rand(N, 2)

    centroids = MiniBatchKMeansInducing(10)
    centroids.initialise(X)
    assert centroids.returns_data_points is False

    delegating = MiniBatchKMeansInducing(2 * N)
    assert torch.equal(delegating.initialise(X), X)
    assert delegating.returns_data_points is True


def test_hilbert_wrapper_never_claims_identity():
    # A permutation of the data is not the data *in order*: the inducing index
    # no longer matches the data index.
    assert HilbertSortedInducing(DatapointsAsInducing()).returns_data_points is False


def test_construct_model_records_the_flag():
    gpytorch = pytest.importorskip("gpytorch")
    from upscaling_tools.nngp import construct_model

    _, X, _, _ = _colliding_case()
    y = torch.rand(N)
    parameters = {'k': 5, 'training_batch_size': 10, 'learning_rate': 1e-2,
                  'training_epochs': 1, 'milestones': []}

    model, _, _, _ = construct_model(
        X, y, gpytorch.kernels.RBFKernel(), gpytorch.likelihoods.GaussianLikelihood(),
        parameters, inducing_points_allocator=GridCountInducing(NINDUCING),
    )
    # Same count as the data, but not the data -- training must minibatch.
    assert model.variational_strategy.inducing_points.size(-2) == N
    assert model.inducing_are_training_data is False

    model, _, _, _ = construct_model(
        X, y, gpytorch.kernels.RBFKernel(), gpytorch.likelihoods.GaussianLikelihood(),
        parameters, inducing_points_allocator=GridCountInducing(2 * N),
    )
    assert model.inducing_are_training_data is True
