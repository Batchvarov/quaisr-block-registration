import torch
import gpytorch
import pytest

from upscaling_tools.nngp_fft_prior import (
    GridSpec,
    GridFFTPath,
    _fft_sample_stationary,
    _kernel_first_row,
    _padded_lag_axes,
)


def _rbf_kernel(lengthscale: float, dim: int = 2) -> gpytorch.kernels.Kernel:
    k = gpytorch.kernels.RBFKernel()
    k.lengthscale = torch.tensor(lengthscale)
    return k


def test_gridspec_validation():
    with pytest.raises(ValueError):
        GridSpec(mins=[0.0, 0.0], maxs=[1.0], shape=(4, 4))
    with pytest.raises(ValueError):
        GridSpec(mins=[0.0, 0.0], maxs=[0.0, 1.0], shape=(4, 4))
    with pytest.raises(ValueError):
        GridSpec(mins=[0.0, 0.0], maxs=[1.0, 1.0], shape=(1, 4))


def test_gridspec_spacing_and_dim():
    g = GridSpec(mins=[0.0, 0.0, 0.0], maxs=[1.0, 2.0, 4.0], shape=(11, 21, 41))
    assert g.dim == 3
    torch.testing.assert_close(g.spacing, torch.tensor([0.1, 0.1, 0.1], dtype=torch.float64))


def test_covariance_matches_analytic_2d():
    torch.manual_seed(0)
    grid = GridSpec(mins=[0.0, 0.0], maxs=[1.0, 1.0], shape=(12, 12))
    kernel = _rbf_kernel(0.3)
    S = 3000
    draws = _fft_sample_stationary(kernel, grid, torch.Size([S]), padding_factor=2)
    flat = draws.reshape(S, -1)
    empirical = (flat.T @ flat) / S

    xs = torch.linspace(0, 1, 12, dtype=torch.float32)
    ys = torch.linspace(0, 1, 12, dtype=torch.float32)
    coords = torch.stack(torch.meshgrid(xs, ys, indexing="ij"), dim=-1).reshape(-1, 2)
    with torch.no_grad():
        K = kernel(coords).to_dense()

    rel_err = (empirical - K).norm() / K.norm()
    assert rel_err < 0.15, f"cov relative error {rel_err.item():.3f}"


def test_grid_node_interpolation_exact():
    torch.manual_seed(1)
    grid = GridSpec(mins=[0.0, 0.0], maxs=[1.0, 1.0], shape=(8, 8))
    kernel = _rbf_kernel(0.25)
    path = GridFFTPath(grid, kernel, sample_shape=torch.Size([2]))

    xs = torch.linspace(0.0, 1.0, 8)
    ys = torch.linspace(0.0, 1.0, 8)
    mesh = torch.stack(torch.meshgrid(xs, ys, indexing="ij"), dim=-1).reshape(-1, 2)

    interp = path(mesh)
    exact = path._draws.reshape(2, -1)
    err = (interp - exact).abs().max().item()
    assert err < 1e-4, f"grid-node interp mismatch {err}"


def test_forward_shape_2d():
    torch.manual_seed(2)
    grid = GridSpec(mins=[0.0, 0.0], maxs=[1.0, 1.0], shape=(16, 16))
    kernel = _rbf_kernel(0.2)
    path = GridFFTPath(grid, kernel, sample_shape=torch.Size([5]))
    X = torch.rand(37, 2)
    out = path(X)
    assert out.shape == (5, 37)
    assert torch.isfinite(out).all()


def test_forward_shape_3d():
    torch.manual_seed(3)
    grid = GridSpec(mins=[0.0, 0.0, 0.0], maxs=[1.0, 1.0, 1.0], shape=(8, 8, 8))
    kernel = _rbf_kernel(0.3, dim=3)
    path = GridFFTPath(grid, kernel, sample_shape=torch.Size([3]))
    X = torch.rand(11, 3)
    out = path(X)
    assert out.shape == (3, 11)
    assert torch.isfinite(out).all()


def test_forward_shape_1d():
    torch.manual_seed(4)
    grid = GridSpec(mins=[0.0], maxs=[1.0], shape=(64,))
    kernel = _rbf_kernel(0.1, dim=1)
    path = GridFFTPath(grid, kernel, sample_shape=torch.Size([4]))
    X = torch.rand(20, 1)
    out = path(X)
    assert out.shape == (4, 20)


def test_leading_batch_dims_preserved():
    torch.manual_seed(5)
    grid = GridSpec(mins=[0.0, 0.0], maxs=[1.0, 1.0], shape=(12, 12))
    kernel = _rbf_kernel(0.2)
    path = GridFFTPath(grid, kernel, sample_shape=torch.Size([2]))
    X = torch.rand(7, 13, 2)
    out = path(X)
    assert out.shape == (2, 7, 13)


# ── lag-grid symmetry ─────────────────────────────────────────────────────────
#
# _kernel_first_row evaluates only the non-negative-lag orthant and mirrors the
# rest, which is the largest single kernel evaluation in the sampler (~4x fewer
# evaluations in 2D). The mirror is only valid because c(h) is even along each
# axis. Note the fold is NOT min(i, n_pad - i): _padded_lag_axes wraps at
# n_pad // 2, so for an ODD n_pad the negative side runs one step further than
# the positive one.

def _full_kernel_first_row(kernel, grid, padding_factor, device, dtype,
                           chunk_size=1 << 21):
    """Evaluate every node of the padded lag grid -- the unmirrored reference."""
    axes = _padded_lag_axes(grid, padding_factor, dtype, device)
    padded_shape = tuple(a.shape[0] for a in axes)
    D = grid.dim

    n_total = 1
    for n in padded_shape:
        n_total *= n

    strides = [1] * D
    for i in range(D - 2, -1, -1):
        strides[i] = strides[i + 1] * padded_shape[i + 1]

    zero = torch.zeros(1, D, device=device, dtype=dtype)
    c_flat = torch.empty(n_total, device=device, dtype=dtype)
    with torch.no_grad():
        for start in range(0, n_total, chunk_size):
            stop = min(start + chunk_size, n_total)
            idx = torch.arange(start, stop, device=device)
            lag = torch.stack(
                [axes[d][torch.div(idx, strides[d], rounding_mode="floor")
                         % padded_shape[d]]
                 for d in range(D)],
                dim=-1,
            )
            c_flat[start:stop] = kernel(lag, zero).to_dense().reshape(-1)
    return c_flat.reshape(padded_shape), padded_shape


@pytest.mark.parametrize("shape", [(17,), (13, 9), (8, 8), (5, 6, 4)])
@pytest.mark.parametrize("padding_factor", [2, 3])  # 3 gives an odd padded size
def test_mirrored_first_row_matches_the_full_evaluation(shape, padding_factor):
    D = len(shape)
    grid = GridSpec(mins=torch.zeros(D), maxs=torch.full((D,), 3.0), shape=shape)
    kernel = gpytorch.kernels.ScaleKernel(
        gpytorch.kernels.MaternKernel(nu=1.5, ard_num_dims=D))
    device, dtype = torch.device("cpu"), torch.float64

    # A small chunk size so the flat-chunk enumeration is exercised, not skipped.
    got, got_shape = _kernel_first_row(kernel, grid, padding_factor, device, dtype,
                                       chunk_size=7)
    expected, expected_shape = _full_kernel_first_row(kernel, grid, padding_factor,
                                                      device, dtype)

    assert got_shape == expected_shape
    torch.testing.assert_close(got, expected, rtol=0, atol=1e-12)
