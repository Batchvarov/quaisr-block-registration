"""A bounded outputscale must still start positive.

``gpytorch.constraints.LessThan`` starts a parameter at
``upper_bound - softplus(0)``, about ``upper_bound - 0.693``. The auto kernel
caps its short-scale component at an outputscale of 0.1, so that component
started at -0.593: the additive kernel matrix became indefinite and the first
variational KL Cholesky died with ``NotPSDError``, which no amount of
likelihood noise can repair (the KL over the first k inducing points is taken
against the prior covariance, which carries no noise term).
"""
import gpytorch
import pytest
import torch

from upscaling_tools.kernels import construct_kernel, parse_constraint


@pytest.mark.parametrize("bound", [0.1, 0.5, 1.0, 5.0])
def test_lessthan_outputscale_starts_inside_the_bound_and_positive(bound):
    kernel = gpytorch.kernels.ScaleKernel(
        gpytorch.kernels.MaternKernel(nu=1.5),
        outputscale_constraint=parse_constraint(["lessthan", bound]),
    )
    assert 0 < float(kernel.outputscale) < bound


def _auto_kernel(outputscale_cap):
    bbox, spacing = 1.414, 0.01
    return construct_kernel([
        {"kernel": "rbf",
         "options": {"ard_num_dims": 1,
                     "lengthscale": ["greaterthan", bbox],
                     "keops": False}},
        {"kernel": "matern",
         "options": {"nu": 2.5, "ard_num_dims": 1,
                     "lengthscale": ["greaterthan", bbox / 4],
                     "keops": False}},
        {"kernel": "matern",
         "options": {"nu": 1.5, "ard_num_dims": 1,
                     "lengthscale": ["greaterthan", 2 * spacing],
                     "outputscale": ["lessthan", outputscale_cap],
                     "keops": False}},
    ])


def test_auto_kernel_is_psd_at_the_inducing_spacing():
    kernel = _auto_kernel(0.1)
    assert all(float(k.outputscale) > 0 for k in kernel.kernels)

    spacing = 0.01
    axis = torch.arange(8.0) * spacing
    points = torch.stack(torch.meshgrid(axis, axis, indexing="ij"), -1).reshape(-1, 2)
    with torch.no_grad():
        covar = kernel(points).to_dense().double()

    # 1e-4 is the largest jitter psd_safe_cholesky tries before it gives up.
    torch.linalg.cholesky(covar + 1e-4 * torch.eye(len(points), dtype=torch.float64))
