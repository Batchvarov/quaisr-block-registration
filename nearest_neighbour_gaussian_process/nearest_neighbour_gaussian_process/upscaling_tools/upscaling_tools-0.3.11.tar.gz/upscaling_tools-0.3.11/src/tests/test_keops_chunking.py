"""Kernel blocks must never be narrower than the KeOps floor.

``gpytorch.kernels.keops`` lazifies a kernel evaluation only when BOTH operands
have at least ``max_cholesky_size`` rows. ``beta_features.checkpoint_kernel``
splits with ``torch.split``, whose last chunk holds ``n % chunk`` rows, so a
chunk width that clears the floor can still hand the kernel a tail that does
not: 465053 inducing points split by 4096 leave 2205 rows, and that block took
the dense path and asked for a (2205, 465053, 2) broadcast -- 7.6 GiB -- which
no memory knob accounted for. The sampler splits its own blocks instead.
"""
import gpytorch
import torch

from upscaling_tools.kernels import chunked_kernel_matmul, keops_chunk_count


def _split_sizes(n_rows: int, chunk: int) -> list[int]:
    pieces = keops_chunk_count(n_rows, chunk)
    return [t.shape[-2] for t in
            torch.tensor_split(torch.zeros(n_rows, 2), pieces, dim=-2)]


def test_no_block_falls_below_the_keops_floor():
    floor = gpytorch.settings.max_cholesky_size.value()
    # 465053 x 4096 is the case that OOMed: torch.split leaves a 2205-row tail.
    for n_rows, chunk in [(465053, 4096), (178144, 22000), (262144, 4096),
                          (10000, 4096), (4097, 4096)]:
        sizes = _split_sizes(n_rows, chunk)
        assert sum(sizes) == n_rows
        assert min(sizes) >= min(max(chunk, floor), n_rows)


def test_fewer_rows_than_one_chunk_stay_in_one_block():
    assert _split_sizes(100, 4096) == [100]


def test_chunked_matmul_matches_the_unchunked_product():
    torch.manual_seed(0)
    x = torch.rand(97, 2)
    rhs = torch.rand(97, 3)
    kernel = gpytorch.kernels.RBFKernel()

    with torch.no_grad():
        expected = kernel(x, x).to_dense() @ rhs
        # A chunk of 10 rows is below the floor, so it is raised to the floor and
        # the product stays in one block; 48 splits the 97 rows in two.
        for chunk in (10, 48):
            got = chunked_kernel_matmul(kernel, x, x, rhs, chunk)
            torch.testing.assert_close(got, expected)
