"""The predictive nugget must reach the coverage it targets, and report honestly."""
import numpy as np
import pytest

from upscaling_tools.calibration import (
    TARGET_COVERAGE,
    coverage,
    cross_fitted_error_rate,
    fit_predictive_nugget,
)


def _under_confident(n=4000, reported=0.04, actual=1.0, seed=0):
    """A model claiming sd 0.2 whose residuals really have sd 1.0."""
    rng = np.random.default_rng(seed)
    variance = np.full(n, reported)
    residual = rng.normal(scale=np.sqrt(actual), size=n)
    return residual, variance


def test_reaches_the_target_coverage():
    residual, variance = _under_confident()
    nugget = fit_predictive_nugget(residual, variance)
    assert coverage(residual, variance + nugget) == pytest.approx(
        TARGET_COVERAGE, abs=0.01)


def test_recovers_the_missing_variance():
    residual, variance = _under_confident(reported=0.04, actual=1.0)
    # The interval needs total variance ~1.04, so the nugget is ~1.0.
    assert fit_predictive_nugget(residual, variance) == pytest.approx(1.0, rel=0.15)


def test_is_zero_when_the_interval_is_already_wide_enough():
    rng = np.random.default_rng(0)
    residual = rng.normal(scale=0.1, size=1000)
    assert fit_predictive_nugget(residual, np.full(1000, 4.0)) == 0.0


def test_handles_a_heavy_tail_beyond_the_initial_bracket():
    rng = np.random.default_rng(0)
    residual = rng.standard_cauchy(size=5000)
    nugget = fit_predictive_nugget(residual, np.full(5000, 1e-6))
    assert np.isfinite(nugget)
    assert coverage(residual, np.full(5000, 1e-6) + nugget) == pytest.approx(
        TARGET_COVERAGE, abs=0.01)


def test_cross_fitted_rate_is_measured_out_of_sample():
    """On 40 points the in-sample rate hits the target exactly; the honest one
    does not, because each half is scored under the other half's nugget."""
    residual, variance = _under_confident(n=40, seed=3)
    nugget = fit_predictive_nugget(residual, variance)
    in_sample = 1 - coverage(residual, variance + nugget)
    honest = cross_fitted_error_rate(residual, variance)
    assert in_sample == pytest.approx(1 - TARGET_COVERAGE, abs=0.03)
    assert honest != pytest.approx(in_sample, abs=1e-9)


def test_cross_fitted_rate_approaches_the_target_on_plenty_of_points():
    residual, variance = _under_confident(n=8000)
    assert cross_fitted_error_rate(residual, variance) == pytest.approx(
        1 - TARGET_COVERAGE, abs=0.02)


def test_too_few_points_to_split():
    assert np.isnan(cross_fitted_error_rate(np.array([1.0]), np.array([1.0])))
