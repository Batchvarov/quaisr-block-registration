"""The numbers the block's post-training health gate reads.

The gate itself lives in the block (core.py): it compares an r2 against
MIN_TRAINING_R2 and a nugget ratio against MAX_NUGGET_RATIO. What is tested here
is that the library produces the numbers those thresholds assume -- that a
collapsed fit really does give r2 <= 0, and that a fit whose residuals carry the
variance of the data really does need a nugget the size of that variance.

`plots=False` is what makes the probe cheap enough to run after every training
attempt, so it is tested to return the same metrics as the full call.
"""
import numpy as np
import pandas as pd
import pytest
import torch
from upscaling_tools.calibration import fit_predictive_nugget
from upscaling_tools.validation import compute_interp_perf, nngp_validation


class _StubModel:
    """A trained model as nngp_validation uses one: dtype, device, inference."""

    def __init__(self, mean, variance):
        self.train_inputs = torch.zeros(1, 2)
        self._mean = np.asarray(mean, dtype=float)
        self._variance = np.asarray(variance, dtype=float)

    def inference(self, X, output_scaler=None, batch_size=None):
        return pd.DataFrame({
            "GP_mean": self._mean,
            "GP_variance": self._variance,
            "GP_std": np.sqrt(self._variance),
        })


def _measured(n=400, seed=0):
    rng = np.random.default_rng(seed)
    return rng.normal(scale=3.0, size=n)


def test_plots_off_gives_the_same_metrics_and_writes_nothing(tmp_path):
    measured = _measured()
    model = _StubModel(measured + 0.1, np.full(measured.size, 0.25))
    X = torch.zeros(measured.size, 2)
    y = torch.from_numpy(measured)

    full, full_plots = nngp_validation(
        model, X, y, savepath=str(tmp_path), calibrate=True)
    bare, bare_plots = nngp_validation(
        model, X, y, savepath=str(tmp_path / "unused"), calibrate=True,
        plots=False)

    assert bare_plots == {}
    assert bare.keys() == full.keys()
    for key in full:
        assert bare[key] == pytest.approx(full[key])
    assert not (tmp_path / "unused").exists()


def test_a_collapsed_fit_gives_a_non_positive_r2():
    measured = _measured()
    # Every prediction is the mean of the data: the fit carries no information.
    gp_infer = pd.DataFrame({
        "measured": measured,
        "GP_mean": np.full(measured.size, measured.mean()),
    })

    assert compute_interp_perf(gp_infer, "measured", "GP_mean")["r2"] <= 0.0


def test_a_good_fit_gives_an_r2_near_one():
    measured = _measured()
    rng = np.random.default_rng(1)
    gp_infer = pd.DataFrame({
        "measured": measured,
        "GP_mean": measured + rng.normal(scale=0.1, size=measured.size),
    })

    assert compute_interp_perf(gp_infer, "measured", "GP_mean")["r2"] > 0.99


def test_a_fit_that_explains_nothing_puts_the_ratio_at_one():
    """The scale MAX_NUGGET_RATIO is read against.

    A model wrong by the full spread of the data needs a nugget of exactly that
    spread to cover 95% of its residuals, so the ratio lands on 1.0. The block's
    threshold sits at 0.5, below this: a fit does not have to explain literally
    nothing before it is rejected, only less than it misses.
    """
    measured = _measured()
    variance = float(np.var(measured))
    rng = np.random.default_rng(2)
    residual = rng.normal(scale=np.sqrt(variance), size=measured.size)
    reported = np.full(measured.size, 1e-6)

    ratio = fit_predictive_nugget(residual, reported) / variance

    assert ratio == pytest.approx(1.0, rel=0.05)


def test_the_ratio_tracks_the_share_of_the_variance_the_fit_misses():
    """Why 0.5 means what it says. Residuals carrying a given share of the data
    variance produce a ratio of that share, so the threshold reads directly as
    "the fit misses half the field"."""
    # 4,000 points rather than the 400 used elsewhere: the nugget is fitted to a
    # 95% coverage, so it reads the tails of the residuals and a small set puts
    # the ratio several percent out.
    measured = _measured(n=4000)
    variance = float(np.var(measured))
    for share in (0.25, 0.5, 0.75):
        rng = np.random.default_rng(int(share * 100))
        residual = rng.normal(
            scale=np.sqrt(share * variance), size=measured.size)
        reported = np.full(measured.size, 1e-6)

        ratio = fit_predictive_nugget(residual, reported) / variance

        assert ratio == pytest.approx(share, rel=0.1)


def test_an_honest_interval_needs_no_nugget():
    measured = _measured()
    variance = float(np.var(measured))
    rng = np.random.default_rng(3)
    reported = np.full(measured.size, 0.04)
    residual = rng.normal(scale=np.sqrt(reported), size=measured.size)

    ratio = fit_predictive_nugget(residual, reported) / variance

    assert ratio < 1.0
