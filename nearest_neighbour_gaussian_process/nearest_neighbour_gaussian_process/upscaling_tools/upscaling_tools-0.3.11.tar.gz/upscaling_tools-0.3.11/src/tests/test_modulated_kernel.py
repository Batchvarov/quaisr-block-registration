import gpytorch
import pytest
import torch
from linear_operator.operators import DiagLinearOperator

from upscaling_tools.kernels import (
    AmplitudeModulatedKernel,
    apply_modulation,
    construct_kernel,
    control_grid,
)


def _points(n=40, seed=0):
    generator = torch.Generator().manual_seed(seed)
    return torch.rand(n, 2, generator=generator, dtype=torch.float64) * 10.0


def _base(lengthscale=2.0, outputscale=1.0):
    kernel = gpytorch.kernels.ScaleKernel(gpytorch.kernels.MaternKernel(nu=1.5))
    kernel.base_kernel.lengthscale = torch.tensor(lengthscale)
    kernel.outputscale = torch.tensor(outputscale)
    return kernel.double()


def _modulated(points, weights=None, count=2, lengthscale=5.0, cap=1.0, keops=False):
    """`weights` are log-amplitudes, set through the constraint rather than raw."""
    base = _base() if not keops else gpytorch.kernels.ScaleKernel(
        gpytorch.kernels.keops.MaternKernel(nu=1.5))
    kernel = AmplitudeModulatedKernel(
        base, control_points=control_grid(points, count),
        control_lengthscale=lengthscale,
        log_amplitude_constraint=gpytorch.constraints.Interval(-cap, cap))
    kernel = kernel.double() if not keops else kernel
    if weights is not None:
        values = torch.as_tensor(weights, dtype=kernel.raw_log_amplitude.dtype)
        kernel.raw_log_amplitude.data = (
            kernel.raw_log_amplitude_constraint.inverse_transform(values))
    return kernel


def _operator_tree(operator):
    """Every node of a composed LinearOperator, parents first."""
    nodes = [operator]
    for attribute in ("left_linear_op", "right_linear_op", "base_linear_op"):
        if hasattr(operator, attribute):
            nodes += _operator_tree(getattr(operator, attribute))
    for child in getattr(operator, "linear_ops", ()):
        nodes += _operator_tree(child)
    return nodes


def test_unit_amplitude_reproduces_the_base_kernel():
    """Zero weights must leave the base kernel untouched, to floating point."""
    points = _points()
    kernel = _modulated(points)
    assert torch.allclose(kernel.amplitude(points), torch.ones(len(points), dtype=torch.float64))
    assert torch.allclose(
        kernel(points, points).to_dense(), _base()(points, points).to_dense(), atol=1e-12)


def test_matrix_stays_positive_definite_under_a_strong_field():
    """D_g K D_g is PSD for any g, which is the reason for this parameterisation."""
    points = _points()
    kernel = _modulated(points, weights=[-3.5, 3.5, 3.5, -3.5], cap=4.0)
    matrix = kernel(points, points).to_dense()
    matrix = 0.5 * (matrix + matrix.transpose(-1, -2))
    assert torch.linalg.eigvalsh(matrix).min() > -1e-10


def test_matrix_equals_the_outer_scaling_of_the_base_matrix():
    points = _points()
    kernel = _modulated(points, weights=[-0.8, 0.4, 0.2, 0.8])
    g = kernel.amplitude(points)
    expected = g.unsqueeze(-1) * _base()(points, points).to_dense() * g.unsqueeze(-2)
    assert torch.allclose(kernel(points, points).to_dense(), expected, atol=1e-12)


def test_diag_matches_the_full_matrix_diagonal():
    """The NNGP takes predictive variances off the diag path, not the matrix."""
    points = _points()
    kernel = _modulated(points, weights=[-0.8, 0.4, 0.2, 0.8])
    full = kernel(points, points).to_dense().diagonal(dim1=-2, dim2=-1)
    assert torch.allclose(kernel(points, points, diag=True), full, atol=1e-12)


def test_cross_covariance_uses_each_side_own_amplitude():
    left, right = _points(30, seed=1), _points(20, seed=2)
    kernel = _modulated(torch.cat([left, right]), weights=[-0.8, 0.4, 0.2, 0.8])
    expected = (kernel.amplitude(left).unsqueeze(-1)
                * _base()(left, right).to_dense()
                * kernel.amplitude(right).unsqueeze(-2))
    assert torch.allclose(kernel(left, right).to_dense(), expected, atol=1e-12)


def test_weights_are_centred_so_a_constant_shift_changes_nothing():
    """g and the outputscale are one parameter twice over without the gauge fix."""
    points = _points()
    flat = _modulated(points, weights=[0.3, 0.3, 0.3, 0.3])
    assert torch.allclose(flat.amplitude(points), torch.ones(len(points), dtype=torch.float64))

    shifted = _modulated(points, weights=[-0.6, -0.1, 0.15, 0.6], cap=2.0)
    same = _modulated(points, weights=[-0.4, 0.1, 0.35, 0.8], cap=2.0)
    assert torch.allclose(shifted.amplitude(points), same.amplitude(points), atol=1e-10)


def test_a_keops_base_kernel_is_never_materialised():
    """Laziness is the whole reason for D_g K D_g over an elementwise multiply.

    KeOps only lazifies above max_cholesky_size, so the point set has to clear
    it for this to test anything.
    """
    points = torch.rand(6000, 2, dtype=torch.float32) * 10.0
    kernel = _modulated(points, weights=[-0.5, 0.25, 0.1, 0.5], keops=True)
    with gpytorch.settings.lazily_evaluate_kernels(False):
        operator = kernel.forward(points, points)

    nodes = _operator_tree(operator)
    names = [type(node).__name__ for node in nodes]
    assert sum(isinstance(node, DiagLinearOperator) for node in nodes) == 2
    assert "KernelLinearOperator" in names, names
    assert "DenseLinearOperator" not in names, names

    probe = torch.ones(len(points), 1)
    expected = (kernel.amplitude(points).unsqueeze(-1)
                * kernel.base_kernel(points, points).to_dense()
                * kernel.amplitude(points).unsqueeze(-2)) @ probe
    assert torch.allclose(operator @ probe, expected, atol=1e-3)


def test_gradients_reach_the_control_weights():
    points = _points()
    kernel = _modulated(points, weights=[-0.8, 0.5, 0.0, 0.8])
    kernel(points, points).to_dense().sum().backward()
    assert kernel.raw_log_amplitude.grad is not None
    assert torch.isfinite(kernel.raw_log_amplitude.grad).all()
    assert kernel.raw_log_amplitude.grad.abs().sum() > 0


def test_control_points_are_a_buffer_not_a_parameter():
    """Fitting their positions lets the field chase individual points."""
    kernel = _modulated(_points())
    names = [name for name, _ in kernel.named_parameters()]
    assert "control_points" not in names
    assert "control_points" in dict(kernel.named_buffers())


def test_control_grid_is_inset_from_the_bounding_box():
    points = torch.tensor([[0.0, 0.0], [4.0, 4.0]], dtype=torch.float64)
    grid = control_grid(points, 2)
    assert grid.shape == (4, 2)
    assert grid.min() == pytest.approx(1.0)
    assert grid.max() == pytest.approx(3.0)


def test_construct_kernel_builds_a_modulated_component_from_a_definition():
    """The definition is what a checkpoint stores, so it must rebuild the module."""
    points = _points()
    definition = [{
        'kernel': 'matern',
        'options': {
            'nu': 1.5,
            'ard_num_dims': 1,
            'lengthscale': ['greaterthan', 0.1],
            'outputscale': ['interval', [1e-3, 0.1]],
            'keops': False,
            'modulation': {
                'control_points': control_grid(points, 2).tolist(),
                'lengthscale': 5.0,
                'log_amplitude': ['interval', [-1.0, 1.0]],
            },
        },
    }]
    kernel = construct_kernel(definition)
    component = kernel.kernels[0]
    assert isinstance(component, AmplitudeModulatedKernel)
    assert component.raw_log_amplitude.shape == (4,)
    # Interval starts at its midpoint, so an untrained component is unmodulated.
    assert torch.allclose(component.amplitude(points.float()),
                          torch.ones(len(points)), atol=1e-6)


def test_apply_modulation_without_a_definition_returns_the_kernel_unchanged():
    base = _base()
    assert apply_modulation(base, None) is base
    assert apply_modulation(base, {}) is base


def test_stationary_part_drops_the_modulation():
    """The FFT sampler embeds a lag-only covariance, so it needs this."""
    points = _points()
    kernel = _modulated(points, weights=[-0.8, 0.4, 0.2, 0.8])
    stationary = kernel.stationary_part()
    assert kernel.is_stationary is False
    assert stationary.is_stationary is True
    assert torch.allclose(
        stationary(points, points).to_dense(), _base()(points, points).to_dense(), atol=1e-12)


def test_the_fft_sampler_refuses_a_modulated_kernel():
    """`_kernel_first_row` evaluates kernel(h, 0), which a modulated kernel breaks.

    Nothing else in the package checks, and gpytorch's `is_stationary` cannot be
    used for it: AdditiveKernel reports False for a sum of stationary parts.
    """
    from upscaling_tools.nngp_fft_prior import GridSpec, build_fft_spectrum

    points = _points()
    grid = GridSpec(mins=[0.0, 0.0], maxs=[10.0, 10.0], shape=(8, 8))
    stationary = gpytorch.kernels.AdditiveKernel(_base().float())
    build_fft_spectrum(stationary, grid, padding_factor=2)

    mixed = gpytorch.kernels.AdditiveKernel(
        _base().float(), _modulated(points, weights=[-0.8, 0.4, 0.2, 0.8]).float())
    with pytest.raises(ValueError, match="non-stationary"):
        build_fft_spectrum(mixed, grid, padding_factor=2)
