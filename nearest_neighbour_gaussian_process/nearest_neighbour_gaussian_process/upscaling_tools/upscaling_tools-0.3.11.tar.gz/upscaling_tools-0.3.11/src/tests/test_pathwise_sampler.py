"""The pathwise sampler solves the posterior update once for all samples.

``sample_pathwise`` used to draw a fresh Matheron path per ``sample_batch_size``
group and evaluate it over every output point, so the dominant cost -- the
kernel evaluations behind ``K(x, Z)`` -- was repeated
``ceil(n / sample_batch_size)`` times. It now draws the prior per batch (that
buffer is what bounds GPU memory) but solves the update once for all ``n``
samples and applies it in a single pass over ``x``.

Two things must hold. The pieces that were meant to be exactly unchanged --
the batched update evaluation and the cached FFT spectrum -- must be bit-exact.
The sample statistics must match the previous implementation to within the
run-to-run noise that implementation shows against ITSELF under a different
seed; comparing against a fixed tolerance would either be flaky or vacuous.
"""
import gpytorch
import numpy as np
import pytest
import torch

import upscaling_tools.nngp_sampling as ns
from upscaling_tools.kernels import construct_kernel
from upscaling_tools.nngp import construct_model
from upscaling_tools.nngp_fft_prior import GridSpec, build_fft_spectrum

M = 120
K = 8
N_EVAL = 80
N_SAMPLES = 300


def _model(seed=0):
    torch.manual_seed(seed)
    X = torch.rand(M, 2)
    y = torch.sin(3 * X[:, 0]) * torch.cos(2 * X[:, 1])
    # Built through construct_kernel, as the blocks do: the random-feature prior
    # needs active_dims/ard_num_dims to infer the input dimension, and a bare
    # ScaleKernel(MaternKernel()) sets neither.
    kernel = construct_kernel([
        {"kernel": "matern",
         "options": {"nu": 2.5, "ard_num_dims": 1, "keops": False}},
    ])
    likelihood = gpytorch.likelihoods.GaussianLikelihood()
    parameters = {"k": K, "training_batch_size": 32, "learning_rate": 1e-2,
                  "training_epochs": 1, "milestones": []}
    model, _, _, _ = construct_model(X, y, kernel, likelihood, parameters)
    model.eval()
    model.likelihood.eval()
    return model


def _grid():
    return GridSpec(mins=[0.0, 0.0], maxs=[1.0, 1.0], shape=(32, 32))


def _fft_kwargs():
    return dict(output_grid=_grid(), fft_padding_factor=2,
                fft_peak_budget_bytes=1 << 22)


def _eval_points(seed=1):
    return torch.from_numpy(
        np.random.default_rng(seed).uniform(0.05, 0.95, size=(N_EVAL, 2))
    ).to(torch.float32)


def _legacy_sample_pathwise(model, x, n, batch_size, update_chunk_size,
                            sample_batch_size, **kwargs):
    """The pre-change loop: one Matheron path per sample batch, full x pass each."""
    import linear_operator
    from botorch.sampling.pathwise.posterior_samplers import draw_matheron_paths

    group = max(1, min(int(sample_batch_size or n), n))
    out_groups = []
    with torch.no_grad(), linear_operator.settings.max_cg_iterations(500):
        for start in range(0, n, group):
            s = min(group, n - start)
            path = draw_matheron_paths(
                model=model, sample_shape=torch.Size([s]),
                update_chunk_size=update_chunk_size, **kwargs)
            chunks = [path(c).cpu() for c in x.split(batch_size, dim=-2)]
            out_groups.append(torch.cat(chunks, dim=-1))
    return out_groups[0] if len(out_groups) == 1 else torch.cat(out_groups, dim=0)


# ── exact identities ──────────────────────────────────────────────────────────

def test_batched_update_evaluation_matches_the_generic_path():
    """The 2-D weight reshape is a KeOps optimisation, not a change of maths.

    GeneralizedLinearPath.forward computes `feat @ weight.unsqueeze(-1)`, which
    makes an (S, M) weight a batched matmul and runs the reduction once per
    sample. evaluate_update_path passes a 2-D (M, S) weight instead so one
    reduction serves every column -- and must return the same numbers.
    """
    from botorch.sampling.pathwise.update_strategies import gaussian_update

    model = _model()
    Z = model.variational_strategy.inducing_points
    x = _eval_points()

    torch.manual_seed(7)
    with torch.no_grad():
        prior = ns.draw_prior_paths(model, torch.Size([5]), update_chunk_size=32,
                                    **_fft_kwargs())
        sample_values = ns.prior_values_at(prior, Z, 32)
        update = gaussian_update(model=model, sample_values=sample_values,
                                 update_chunk_size=32)

        batched = ns.evaluate_update_path(update, x)
        generic = update(x)

    assert batched.shape == generic.shape == (5, N_EVAL)
    torch.testing.assert_close(batched, generic, rtol=0, atol=0)


class _ConstantBias(torch.nn.Module):
    """Bias module in the shape botorch expects: (..., N, D) -> (..., N)."""

    def forward(self, x):
        return torch.full(x.shape[:-1], 0.5, dtype=x.dtype, device=x.device)


def test_evaluate_update_path_falls_back_when_the_layout_is_not_plain():
    """A bias module means the fast path cannot apply; it must defer, not lie."""
    from botorch.sampling.pathwise.update_strategies import gaussian_update

    model = _model()
    Z = model.variational_strategy.inducing_points
    x = _eval_points()

    torch.manual_seed(8)
    with torch.no_grad():
        prior = ns.draw_prior_paths(model, torch.Size([3]), update_chunk_size=32,
                                    **_fft_kwargs())
        update = gaussian_update(model=model,
                                 sample_values=ns.prior_values_at(prior, Z, 32),
                                 update_chunk_size=32)
        plain = ns.evaluate_update_path(update, x)

        update.bias_module = _ConstantBias()
        biased = ns.evaluate_update_path(update, x)

    # Deferred to the generic path, so the bias is included -- the fast path
    # would have silently dropped it.
    torch.testing.assert_close(biased, update(x), rtol=0, atol=0)
    torch.testing.assert_close(biased - plain, torch.full_like(plain, 0.5))


def test_fft_spectrum_is_cached_and_identical_to_a_fresh_build():
    """Rebuilding the spectrum per sample batch was the second repeated cost.

    It depends only on the kernel hyperparameters and the grid, so caching it
    must return the very same object, holding the very same values.
    """
    model = _model()
    Z = model.variational_strategy.inducing_points
    grid = _grid()

    fresh = build_fft_spectrum(model.covar_module, grid, padding_factor=2,
                               device=Z.device, dtype=Z.dtype)
    cached = ns._get_fft_spectrum(model, grid, 2, Z.device, Z.dtype)
    again = ns._get_fft_spectrum(model, grid, 2, Z.device, Z.dtype)

    assert cached is again, "second lookup rebuilt the spectrum"
    torch.testing.assert_close(cached.sqrt_L, fresh.sqrt_L, rtol=0, atol=0)
    assert cached.padded_shape == fresh.padded_shape


def test_fft_spectrum_cache_misses_when_the_grid_changes():
    """The cache is keyed, not unconditional -- a different grid must rebuild."""
    model = _model()
    Z = model.variational_strategy.inducing_points

    first = ns._get_fft_spectrum(model, _grid(), 2, Z.device, Z.dtype)
    other = GridSpec(mins=[0.0, 0.0], maxs=[1.0, 1.0], shape=(16, 16))
    second = ns._get_fft_spectrum(model, other, 2, Z.device, Z.dtype)

    assert first is not second
    assert first.padded_shape != second.padded_shape


# ── distributional equivalence ────────────────────────────────────────────────

def _summary(draws):
    return draws.mean(0), draws.std(0)


def _deviation(candidate, reference, n_samples):
    """(largest |z| on the mean, min sd ratio, max sd ratio) vs a reference run."""
    mu_c, sd_c = _summary(candidate)
    mu_r, sd_r = _summary(reference)
    se = np.sqrt(sd_c ** 2 + sd_r ** 2) / np.sqrt(n_samples)
    z = np.abs(mu_c - mu_r) / np.maximum(se, 1e-9)
    ratio = sd_c / np.maximum(sd_r, 1e-12)
    return z.max(), ratio.min(), ratio.max()


@pytest.mark.parametrize("use_fft_prior", [True, False])
@pytest.mark.parametrize("sample_batch_size", [4, None])
def test_matches_the_legacy_sampler(use_fft_prior, sample_batch_size):
    """New vs old must sit inside old-vs-old run-to-run noise.

    Compared at a MATCHED sample_batch_size. With the random-feature prior the
    feature set is drawn once per batch, so the batch size is part of the
    approximation (it was in the old code too) and cross-batch-size comparison
    is meaningless. The FFT prior has no such sensitivity: its spectrum is
    exact, not a random approximation.
    """
    model = _model()
    x = _eval_points()
    kwargs = _fft_kwargs() if use_fft_prior else {}
    common = dict(batch_size=32, update_chunk_size=32,
                  sample_batch_size=sample_batch_size)

    torch.manual_seed(11)
    new = ns.sample_pathwise_batched(model, x, N_SAMPLES, **common, **kwargs).numpy()
    torch.manual_seed(22)
    legacy = _legacy_sample_pathwise(model, x, N_SAMPLES, **common, **kwargs).numpy()
    torch.manual_seed(33)
    control = _legacy_sample_pathwise(model, x, N_SAMPLES, **common, **kwargs).numpy()

    assert new.shape == legacy.shape == (N_SAMPLES, N_EVAL)
    assert np.isfinite(new).all()

    z_new, lo_new, hi_new = _deviation(new, legacy, N_SAMPLES)
    z_ctl, lo_ctl, hi_ctl = _deviation(control, legacy, N_SAMPLES)

    assert z_new <= max(z_ctl * 1.5, 5.0), (
        f"mean deviates by {z_new:.2f} sigma; the same implementation deviates "
        f"from itself by only {z_ctl:.2f}")
    assert lo_new >= min(lo_ctl, 0.80) * 0.95, (
        f"spread shrank to {lo_new:.3f}x; control floor was {lo_ctl:.3f}")
    assert hi_new <= max(hi_ctl, 1.25) * 1.05, (
        f"spread grew to {hi_new:.3f}x; control ceiling was {hi_ctl:.3f}")


def test_spatial_correlation_structure_is_preserved():
    """Marginals can survive a bug that destroys the correlation between points.

    Compare the correlation of the FLUCTUATIONS (samples minus their mean); the
    raw draws all carry the posterior mean and so always look alike.
    """
    model = _model()
    x = _eval_points()
    common = dict(batch_size=32, update_chunk_size=32, sample_batch_size=4)

    torch.manual_seed(11)
    new = ns.sample_pathwise_batched(model, x, N_SAMPLES, **common, **_fft_kwargs()).numpy()
    torch.manual_seed(22)
    legacy = _legacy_sample_pathwise(model, x, N_SAMPLES, **common, **_fft_kwargs()).numpy()
    torch.manual_seed(33)
    control = _legacy_sample_pathwise(model, x, N_SAMPLES, **common, **_fft_kwargs()).numpy()

    def fluctuation_corr(draws):
        return np.corrcoef((draws - draws.mean(0))[:, :20], rowvar=False)

    ref = fluctuation_corr(legacy)
    d_new = np.abs(fluctuation_corr(new) - ref).max()
    d_ctl = np.abs(fluctuation_corr(control) - ref).max()

    assert d_new <= max(d_ctl * 1.5, 0.25), (
        f"correlation structure moved by {d_new:.3f}; the same implementation "
        f"moves by {d_ctl:.3f}")
