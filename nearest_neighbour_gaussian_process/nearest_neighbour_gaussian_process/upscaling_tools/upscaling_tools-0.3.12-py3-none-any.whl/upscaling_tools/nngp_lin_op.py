import torch
from linear_operator.operators import LinearOperator
from linear_operator.utils.cholesky import psd_safe_cholesky


@torch.compile(fullgraph=False, dynamic=True)
def _forward_substitute(x: torch.Tensor, B: torch.Tensor, nn_idx: torch.Tensor, k: int) -> torch.Tensor:
    """Solve A^{-1} x in-place along the NNGP DAG via forward substitution.

    Sequential because point i+k depends on already-updated neighbors nn_idx[i,:] < i+k.
    torch.compile reduces per-iteration Python overhead.
    """
    for i in range(x.shape[-2] - k):
        x_neighbors = x[..., nn_idx[i], :]                              # (..., k, S)
        x[..., i + k, :] = x[..., i + k, :] + torch.einsum(
            '...k,...ks->...s', B[..., i, :], x_neighbors
        )
    return x


@torch.compile(fullgraph=False, dynamic=True)
def _cholesky_solve_impl(
    rhs: torch.Tensor,
    L_first: torch.Tensor,
    F: torch.Tensor,
    B: torch.Tensor,
    nn_idx_cols: tuple,
    nn_idx_base_views: tuple,
    k: int,
    M: int,
) -> torch.Tensor:
    S = rhs.shape[-1]

    correction = torch.zeros_like(rhs[..., k:, :])
    for j, idx_col in enumerate(nn_idx_cols):
        correction.addcmul_(B[..., :, j:j+1], rhs[..., idx_col, :])
    z1 = torch.cat([rhs[..., :k, :], rhs[..., k:, :] - correction], dim=-2)

    z2 = torch.empty_like(z1)
    tmp = torch.linalg.solve_triangular(L_first, z1[..., :k, :], upper=False)
    z2[..., :k, :] = torch.linalg.solve_triangular(L_first.mT, tmp, upper=True)
    z2[..., k:, :] = z1[..., k:, :] / F.unsqueeze(-1)

    w = z2.clone()
    for j, base_view in enumerate(nn_idx_base_views):
        idx_exp = base_view.expand(*w.shape[:-2], M - k, S)
        w.scatter_add_(-2, idx_exp, -(B[..., :, j:j+1] * z2[..., k:, :]))

    return w


class NNGPCholeskyLinearOperator(LinearOperator):
    """ 
    Implicitly represents the O(Mk) sparse lower-triangular Cholesky factor 
    L = A^{-1} F^{1/2} for VNNGP without materializing dense M x M matrices. 
    """ 
    def __init__(self, L_first: torch.Tensor, B: torch.Tensor, F: torch.Tensor, nn_idx: torch.Tensor): 
        # Compute the PSD-safe Cholesky factor for the first k points
        super().__init__(L_first, B, F, nn_idx)
        self.L_first = L_first
        self.B = B
        self.F = F
        self.nn_idx = nn_idx

        self._batch_shape = B.shape[:-2]
        self.k = L_first.shape[-1]
        self.M = B.shape[-2] + self.k
        self.F_sqrt = torch.sqrt(self.F).unsqueeze(-1)  # (..., M-k, 1)
        self._nn_idx_cols = self.nn_idx.unbind(-1)      # k tensors of shape (..., M-k)
        self._nn_idx_base_views = tuple(
            idx_col.view(*([1] * len(self._batch_shape)), -1, 1)
            for idx_col in self._nn_idx_cols
        )

    def _size(self) -> torch.Size:
        return self._batch_shape + torch.Size([self.M, self.M])

    def _transpose_nonbatch(self) -> LinearOperator:
        raise NotImplementedError("Transpose not implemented (and usually not needed for pathwise sampling).") 

    def _matmul(self, rhs: torch.Tensor) -> torch.Tensor:
        # rhs is usually a standard normal vector/matrix of shape (..., M, S)
        is_vector = rhs.ndim == len(self._batch_shape) + 1
        if is_vector:
            rhs = rhs.unsqueeze(-1)

        with torch.no_grad():
            # --- Step 1: Scale by F^{1/2} ---
            # First k points use the exact dense Cholesky
            y_first = self.L_first @ rhs[..., :self.k, :]

            # Remaining M-k points use the diagonal conditional variances
            y_rest = self.F_sqrt * rhs[..., self.k:, :]
            x = torch.cat([y_first, y_rest], dim=-2)  # (..., M, S)

            # --- Step 2: Forward substitution for A^{-1} x = y ---
            # nn_idx is always 2D (M-k, k) after the squeeze in the sampling code.
            nn_idx_2d = self.nn_idx if self.nn_idx.ndim == 2 else self.nn_idx.squeeze(0)
            x = _forward_substitute(x, self.B, nn_idx_2d, self.k)

        if is_vector:
            x = x.squeeze(-1)

        return x

    @classmethod
    def from_kernel(cls, kernel, Z: torch.Tensor, nn_idx: torch.Tensor, k: int,
                    jitter: float = 1e-6, chunk_size: int | None = None):
        """Build the sparse NNGP Cholesky from O(k²M) batched local kernel evaluations.

        Avoids the dense M×M Cholesky by factorising each k-point neighbourhood
        independently.  Memory: O(chunk_size × k²) transient, O(kM) persistent.

        Args:
            kernel:     GPyTorch kernel (e.g. model.covar_module).
            Z:          Inducing points, shape (..., M, D).
            nn_idx:     Nearest-neighbour indices, shape (M-k, k), entries in [0, M).
            k:          Number of nearest neighbours.
            jitter:     Added to every diagonal for numerical stability.
            chunk_size: Process this many points at a time. None = all at once.
        """
        M = Z.shape[-2]
        dtype, device = Z.dtype, Z.device
        eye_k = torch.eye(k, dtype=dtype, device=device)

        # ── First k points: k×k dense Cholesky ─────────────────────────────
        K_first = kernel(Z[..., :k, :], Z[..., :k, :]).to_dense()
        K_first = K_first + jitter * eye_k
        L_first = psd_safe_cholesky(K_first)                              # (..., k, k)

        # ── Remaining M-k points: batched k×k kernel evaluations ───────────
        Z_rest = Z[..., k:, :]                                            # (..., M-k, D)

        if chunk_size is None:
            B, F = cls._compute_B_F(kernel, Z, Z_rest, nn_idx, eye_k, jitter)
        else:
            B_parts, F_parts = [], []
            for start in range(0, M - k, chunk_size):
                end = min(start + chunk_size, M - k)
                nn_idx_c = nn_idx[..., start:end, :]
                Z_rest_c = Z_rest[..., start:end, :]
                B_c, F_c = cls._compute_B_F(kernel, Z, Z_rest_c, nn_idx_c, eye_k, jitter)
                B_parts.append(B_c)
                F_parts.append(F_c)
            B = torch.cat(B_parts, dim=-2)
            F = torch.cat(F_parts, dim=-1)

        return cls(L_first, B, F, nn_idx)

    @staticmethod
    def _compute_B_F(kernel, Z, Z_rest, nn_idx, eye_k, jitter):
        """Compute regression coefficients B and conditional variances F for a block."""
        dtype, device = Z.dtype, Z.device
        k = eye_k.shape[-1]

        Z_nn = Z[..., nn_idx, :]                                          # (..., c, k, D)

        K_nn = kernel(Z_nn, Z_nn).to_dense()
        K_nn = K_nn + jitter * eye_k
        K_point_nn = kernel(Z_rest.unsqueeze(-2), Z_nn).to_dense()        # (..., c, 1, k)
        K_diag = kernel(
            Z_rest.unsqueeze(-2), Z_rest.unsqueeze(-2)
        ).to_dense().squeeze(-1).squeeze(-1)                              # (..., c)

        L_nn = psd_safe_cholesky(K_nn)                                    # (..., c, k, k)
        B    = torch.cholesky_solve(K_point_nn.mT, L_nn).squeeze(-1)     # (..., c, k)
        F    = (K_diag - (B * K_point_nn.squeeze(-2)).sum(-1)).clamp(min=jitter)

        return B, F

    def cholesky_solve(self, rhs: torch.Tensor) -> torch.Tensor:
        """Compute (L L^T)^{-1} @ rhs using the NNGP sparse structure.

        Equivalent to torch.cholesky_solve(rhs, L.to_dense()) but O(kM) in memory
        and time instead of O(M²).

        Uses the identity (L L^T)^{-1} = A^T F^{-1} A where L = A^{-1} F^{1/2}.

        Args:
            rhs: Shape (..., M, S).

        Returns:
            Shape (..., M, S).
        """
        return _cholesky_solve_impl(
            rhs, self.L_first, self.F, self.B,
            self._nn_idx_cols, self._nn_idx_base_views,
            self.k, self.M,
        )
