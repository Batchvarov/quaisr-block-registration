from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass
from typing import Any

import torch
import torch.nn.functional as F
from torch import Size, Tensor

from botorch.sampling.pathwise.paths import SamplePath

from upscaling_tools.kernels import AmplitudeModulatedKernel

log = logging.getLogger(__name__)


@dataclass
class GridSpec:
    """Regular Cartesian grid in D dims with per-axis extents and shape."""

    mins: Tensor
    maxs: Tensor
    shape: tuple[int, ...]

    def __post_init__(self):
        self.mins = torch.as_tensor(self.mins).to(torch.float64).flatten()
        self.maxs = torch.as_tensor(self.maxs).to(torch.float64).flatten()
        self.shape = tuple(int(s) for s in self.shape)
        if self.mins.shape != self.maxs.shape or self.mins.shape[0] != len(self.shape):
            raise ValueError(
                f"mins/maxs/shape dimension mismatch: {self.mins.shape}, "
                f"{self.maxs.shape}, {self.shape}"
            )
        if not torch.all(self.maxs > self.mins):
            raise ValueError("maxs must be strictly greater than mins per axis.")
        if any(n < 2 for n in self.shape):
            raise ValueError("Each grid axis must have at least 2 points.")

    @property
    def dim(self) -> int:
        return len(self.shape)

    @property
    def spacing(self) -> Tensor:
        n = torch.tensor(self.shape, dtype=self.maxs.dtype)
        return (self.maxs - self.mins) / (n - 1)

    def normalized_coords(self, X: Tensor) -> Tensor:
        """Map X in [mins, maxs] to [-1, 1] along each axis."""
        mins = self.mins.to(device=X.device, dtype=X.dtype)
        maxs = self.maxs.to(device=X.device, dtype=X.dtype)
        return 2 * (X - mins) / (maxs - mins) - 1


def _padded_lag_axes(grid: GridSpec, padding_factor: int, dtype: torch.dtype, device: torch.device) -> list[Tensor]:
    """Signed-wrap lag values along each axis on padded grid."""
    d = grid.spacing.to(device=device, dtype=dtype)
    axes: list[Tensor] = []
    for i, n in enumerate(grid.shape):
        n_pad = padding_factor * n
        idx = torch.arange(n_pad, device=device, dtype=dtype)
        signed = torch.where(idx < n_pad // 2, idx, idx - n_pad)
        axes.append(signed * d[i])
    return axes


def _kernel_first_row(
    kernel: torch.nn.Module,
    grid: GridSpec,
    padding_factor: int,
    device: torch.device,
    dtype: torch.dtype,
    chunk_size: int = 1 << 21,
) -> tuple[Tensor, tuple[int, ...]]:
    """Evaluate c(h) = kernel(h, 0) on padded lag grid.

    The lag grid is enumerated in flat chunks rather than materialised with
    ``meshgrid``/``stack``: on a large output grid the padded lag grid has
    ``padding_factor**D * prod(grid.shape)`` nodes, and holding D mesh tensors
    plus the (N_pad, D) stack is several times the size of the result itself.

    Only the non-negative-lag orthant is evaluated; the rest is a mirror. Every
    kernel ``construct_kernel`` can build (RBF / Matern / constant, with a scalar
    or per-axis lengthscale) is a function of the per-axis absolute lags, so
    ``c`` is even along each axis independently and ``c[i] == c[(-i) mod n_pad]``.
    In 2D that cuts this -- the largest kernel evaluation in the sampler -- by ~4x.
    """
    d_spacing = grid.spacing.to(device=device, dtype=dtype)
    padded_shape = tuple(padding_factor * n for n in grid.shape)
    D = grid.dim

    # Non-negative half along each axis, and the fold that mirrors it back out.
    # _padded_lag_axes wraps at n_pad // 2, so |lag(i)| is i below the wrap and
    # n_pad - i at or above it. For odd n_pad that is NOT min(i, n_pad - i): the
    # negative side runs one step further than the positive one, so the half
    # needs n_pad - n_pad // 2 + 1 entries rather than n_pad // 2 + 1.
    half_shape = tuple(n - n // 2 + 1 for n in padded_shape)
    half_axes = [
        torch.arange(half_shape[i], device=device, dtype=dtype) * d_spacing[i]
        for i in range(D)
    ]
    folds = []
    for i in range(D):
        n_pad = padded_shape[i]
        idx = torch.arange(n_pad, device=device)
        folds.append(torch.where(idx < n_pad // 2, idx, n_pad - idx))

    n_half = 1
    for n in half_shape:
        n_half *= n

    # Row-major ("ij") strides over the half grid.
    strides = [1] * D
    for i in range(D - 2, -1, -1):
        strides[i] = strides[i + 1] * half_shape[i + 1]

    zero = torch.zeros(1, D, device=device, dtype=dtype)
    c_flat = torch.empty(n_half, device=device, dtype=dtype)
    with torch.no_grad():
        for start in range(0, n_half, chunk_size):
            stop = min(start + chunk_size, n_half)
            idx = torch.arange(start, stop, device=device)
            lag = torch.stack(
                [half_axes[d][torch.div(idx, strides[d], rounding_mode="floor") % half_shape[d]]
                 for d in range(D)],
                dim=-1,
            )
            c_flat[start:stop] = kernel(lag, zero).to_dense().reshape(-1)
            del lag, idx

    c = c_flat.reshape(half_shape)
    del c_flat
    for d in range(D):
        c = c.index_select(d, folds[d])
    return c.contiguous(), padded_shape


# Target peak footprint (bytes) of the per-chunk circulant draw. Exposed so a
# caller on a small GPU can trade throughput for headroom.
DEFAULT_FFT_PEAK_BUDGET_BYTES = 1 << 29  # 512 MiB


class FFTSpectrum:
    """Square root of the circulant spectrum for one (kernel, grid, padding).

    Depends only on the kernel hyperparameters and the output grid -- never on
    the samples drawn from it -- so it can be reused across every sample batch of
    a run. Building it costs a kernel evaluation over the whole padded lag grid
    plus an rfftn of the same size, which is the single largest piece of work in
    the FFT prior; recomputing it per batch is pure waste.
    """

    __slots__ = ("sqrt_L", "padded_shape", "fft_dims", "neg_frac")

    def __init__(self, sqrt_L: Tensor, padded_shape: tuple[int, ...], fft_dims: tuple[int, ...],
                 neg_frac: float):
        self.sqrt_L = sqrt_L
        self.padded_shape = padded_shape
        self.fft_dims = fft_dims
        self.neg_frac = neg_frac


def build_fft_spectrum(
    kernel: torch.nn.Module,
    grid: GridSpec,
    padding_factor: int = 2,
    max_padding_retries: int = 1,
    device: torch.device | None = None,
    dtype: torch.dtype | None = None,
) -> FFTSpectrum:
    """Evaluate the padded lag row and return its clipped spectral square root."""
    if device is None:
        device = torch.device("cpu")
    if dtype is None:
        dtype = torch.float32

    # gpytorch's is_stationary is no use as a guard here: AdditiveKernel reports
    # False even for a sum of stationary components. Name the one non-stationary
    # kernel this package can build instead.
    modulated = [name for name, module in kernel.named_modules()
                 if isinstance(module, AmplitudeModulatedKernel)]
    if modulated:
        raise ValueError(
            f"cannot build a circulant spectrum for a non-stationary kernel; "
            f"{modulated} modulate the amplitude, so kernel(h, 0) is not a "
            "function of the lag alone. Build the spectrum from each "
            "component's stationary_part() and multiply the drawn path by its "
            "amplitude() instead.")

    D = grid.dim
    fft_dims = tuple(range(-D, 0))
    factor = padding_factor
    neg_frac = 0.0

    for attempt in range(max_padding_retries + 1):
        c, padded_shape = _kernel_first_row(kernel, grid, factor, device, dtype)
        # c is real and symmetric under the signed lag wrap, so the circulant
        # spectrum is real and Hermitian-redundant: rfftn holds every distinct
        # eigenvalue in half the elements of fftn. ``.real`` on the transform
        # is a view that pins the complex buffer alive, so copy it out and drop
        # the temporary immediately.
        Lambda = torch.fft.rfftn(c, dim=fft_dims).real.contiguous()
        del c
        max_abs = Lambda.abs().max().clamp_min(1e-30)
        neg_frac = float(Lambda.clamp(max=0).abs().max() / max_abs)
        if neg_frac < 1e-6 or attempt == max_padding_retries:
            break
        log.debug("circulant embedding neg eigenvalue frac=%.2e; enlarging padding", neg_frac)
        factor *= 2

    if neg_frac >= 1e-3:
        warnings.warn(
            f"Circulant embedding has non-trivial negative eigenvalues "
            f"(rel {neg_frac:.2e}); values clipped. Increase padding_factor."
        )
    log.debug("FFT sampler padded_shape=%s neg_frac=%.2e", padded_shape, neg_frac)

    sqrt_L = Lambda.clamp(min=0).sqrt().to(dtype)
    del Lambda
    return FFTSpectrum(sqrt_L, padded_shape, fft_dims, neg_frac)


def _fft_sample_stationary(
    kernel: torch.nn.Module,
    grid: GridSpec,
    sample_shape: Size,
    padding_factor: int = 2,
    max_padding_retries: int = 1,
    device: torch.device | None = None,
    dtype: torch.dtype | None = None,
    peak_budget_bytes: int = DEFAULT_FFT_PEAK_BUDGET_BYTES,
    spectrum: FFTSpectrum | None = None,
) -> Tensor:
    """Draw zero-mean stationary GP samples on grid via circulant embedding.

    Returns tensor of shape (S_total, *grid.shape). Pass ``spectrum`` to reuse a
    previously built one instead of re-evaluating the padded lag grid.
    """
    if device is None:
        device = torch.device("cpu")
    if dtype is None:
        dtype = torch.float32

    if spectrum is None:
        spectrum = build_fft_spectrum(
            kernel, grid, padding_factor, max_padding_retries, device, dtype)
    sqrt_L = spectrum.sqrt_L
    padded_shape = spectrum.padded_shape
    fft_dims = spectrum.fft_dims

    if len(sample_shape) == 0:
        S_total = 1
    else:
        S_total = int(torch.tensor(list(sample_shape)).prod().item())

    grid_slices = tuple(slice(0, n) for n in grid.shape)

    # Chunk the sample batch. The circulant-embedding draw holds arrays of
    # shape (chunk, *padded_shape) live at once, so materialising the whole
    # S_total batch spikes GPU memory to O(S_total * prod(padded_shape)) and
    # OOMs on large grids. Cap the per-chunk footprint to a fixed budget
    # instead; each sample is drawn independently so chunking does not change
    # the result.
    elems_per_sample = 1
    for n in padded_shape:
        elems_per_sample *= n
    # Live per chunk: the real noise field (4 B/elem) and its rfftn (complex64
    # over ~half the elements, so also ~4 B/elem), plus slack for the FFT
    # workspace.
    bytes_per_elem = 4 + 4 + 4
    chunk = max(1, int(peak_budget_bytes) // max(1, elems_per_sample * bytes_per_elem))

    out = torch.empty(S_total, *grid.shape, device=device, dtype=dtype)
    with torch.no_grad():
        for start in range(0, S_total, chunk):
            s = min(chunk, S_total - start)
            # z = C^{1/2} w for real white noise w, evaluated as
            # irfftn(sqrt(Lambda) * rfftn(w)). The circulant square root is
            # real and symmetric, so Cov(z) is exactly the target circulant --
            # the same field the complex-noise form produced in its real part,
            # at half the memory and without discarding the imaginary half.
            noise = torch.randn(s, *padded_shape, device=device, dtype=dtype)
            W = torch.fft.rfftn(noise, dim=fft_dims)
            del noise
            W.mul_(sqrt_L)
            z = torch.fft.irfftn(W, s=padded_shape, dim=fft_dims)
            del W
            out[start:start + s] = z[(slice(None),) + grid_slices]
            del z

    return out.contiguous()


def _grid_sample_paths(
    draws: Tensor,
    X: Tensor,
    grid: GridSpec,
    sample_shape: Size,
) -> Tensor:
    """Trilinear interpolate draws at X.

    draws:  (S_total, *grid.shape)
    X:      (..., N, D)
    return: (*sample_shape, ..., N)
    """
    D = grid.dim
    if X.shape[-1] != D:
        raise ValueError(f"X trailing dim {X.shape[-1]} != grid.dim {D}")

    S_total = draws.shape[0]
    leading = X.shape[:-1]
    x_flat = X.reshape(-1, D).to(device=draws.device, dtype=draws.dtype)
    M = x_flat.shape[0]

    norm = grid.normalized_coords(x_flat)
    norm_flipped = norm.flip(-1)  # grid_sample expects (x_lastdim, ..., x_firstdim)

    draws_r = draws.reshape(1, S_total, *grid.shape)

    if D == 1:
        # F.grid_sample requires 2D+ input; expand to 2D with singleton axis.
        # Manual linear interp is cleaner.
        n1 = grid.shape[0]
        pos = (norm.squeeze(-1) + 1) * 0.5 * (n1 - 1)
        x0 = pos.floor().clamp(0, n1 - 1).long()
        x1 = (x0 + 1).clamp(0, n1 - 1)
        w = (pos - x0.to(pos.dtype)).unsqueeze(0)
        v0 = draws[:, x0]
        v1 = draws[:, x1]
        out = v0 * (1 - w) + v1 * w
    elif D == 2:
        grid_r = norm_flipped.reshape(1, 1, M, 2)
        out = F.grid_sample(draws_r, grid_r, mode="bilinear", align_corners=True, padding_mode="border")
        out = out[0, :, 0, :]
    elif D == 3:
        grid_r = norm_flipped.reshape(1, 1, 1, M, 3)
        out = F.grid_sample(draws_r, grid_r, mode="bilinear", align_corners=True, padding_mode="border")
        out = out[0, :, 0, 0, :]
    else:
        raise NotImplementedError(f"GridFFTPath supports D in {{1,2,3}}, got {D}")

    if len(sample_shape) == 0:
        return out.reshape(-1).reshape(*leading) if len(leading) else out.reshape(())
    return out.reshape(*sample_shape, *leading)


class GridFFTPath(SamplePath):
    """Stationary-GP prior sample stored on a regular Cartesian grid.

    Sampled once at construction via circulant embedding (Dietrich-Newsam).
    Evaluated at arbitrary inputs via trilinear interpolation; exact at grid nodes.
    Supports D in {1, 2, 3}.
    """

    def __init__(
        self,
        grid: GridSpec,
        kernel: torch.nn.Module,
        sample_shape: Size,
        padding_factor: int = 2,
        device: torch.device | None = None,
        dtype: torch.dtype | None = None,
        is_ensemble: bool = False,
        peak_budget_bytes: int = DEFAULT_FFT_PEAK_BUDGET_BYTES,
        spectrum: FFTSpectrum | None = None,
    ):
        super().__init__()
        self.grid = grid
        self.sample_shape = sample_shape
        self.is_ensemble = is_ensemble
        self.ensemble_as_batch = False
        draws = _fft_sample_stationary(
            kernel,
            grid,
            sample_shape,
            padding_factor=padding_factor,
            device=device,
            dtype=dtype,
            peak_budget_bytes=peak_budget_bytes,
            spectrum=spectrum,
        )
        self.register_buffer("_draws", draws)

    def set_ensemble_as_batch(self, ensemble_as_batch: bool) -> None:
        self.ensemble_as_batch = ensemble_as_batch

    def forward(self, x: Tensor, **_: Any) -> Tensor:
        return _grid_sample_paths(self._draws, x, self.grid, self.sample_shape)


class GridFFTPriorSampler:
    """Callable in the shape of botorch's TPathwisePriorSampler for grid targets."""

    def __call__(
        self,
        *,
        model,
        sample_shape: Size,
        output_grid: GridSpec,
        padding_factor: int = 2,
        fft_peak_budget_bytes: int = DEFAULT_FFT_PEAK_BUDGET_BYTES,
        spectrum: FFTSpectrum | None = None,
        **_: Any,
    ) -> GridFFTPath:
        kernel = model.covar_module
        Z = getattr(model.variational_strategy, "inducing_points", None)
        if Z is not None:
            device = Z.device
            dtype = Z.dtype
        else:
            param = next(kernel.parameters(), None)
            device = param.device if param is not None else torch.device("cpu")
            dtype = param.dtype if param is not None else torch.float32
        return GridFFTPath(
            grid=output_grid,
            kernel=kernel,
            sample_shape=sample_shape,
            padding_factor=padding_factor,
            device=device,
            dtype=dtype,
            peak_budget_bytes=fft_peak_budget_bytes,
            spectrum=spectrum,
        )
