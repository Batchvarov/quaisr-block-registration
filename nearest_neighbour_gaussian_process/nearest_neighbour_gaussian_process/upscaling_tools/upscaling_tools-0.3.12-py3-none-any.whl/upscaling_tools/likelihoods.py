import gpytorch
import torch

class NonGaussianMultitaskLikelihood(gpytorch.likelihoods.Likelihood):
    def __init__(self, base_likelihood):
        super().__init__()
        self.base_likelihood = base_likelihood

    def forward(self, function_samples, **kwargs):
        # TODO: This might accidentally double transpose with the below if we're not using a 1D likelihood,
        # but I was lazy when getting this to work for the thing I needed.
        return self.base_likelihood.forward(function_samples.transpose(-2, -1))

    def expected_log_prob(self, observations, function_dist, *params, **kwargs):
        if not self.training:
            # TODO: If we wanted this to work in eval, we'd need to handle the non independent case.
            raise RuntimeError(
                "NonGaussianMultitaskLikelihood supports evaluating expected_log_prob during training only"
            )

        function_dist = torch.distributions.Normal(
            function_dist.mean.transpose(-2, -1),
            function_dist.stddev.transpose(-2, -1)
        )

        observations = observations.transpose(-2, -1)

        elp = self.base_likelihood.expected_log_prob(observations, function_dist, *params, **kwargs)

        return elp.mean(-2)
