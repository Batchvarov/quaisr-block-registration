import pandas as pd
import sklearn

class InputScaler:
    def __init__(self, scaler, aggregate_dims=False) -> None:
        self.aggregate_dims = aggregate_dims
        self.scaler = scaler

    def fit_transform(self, X):
        Xs = pd.DataFrame(data = X)
        if self.aggregate_dims:
            shape = Xs.values.shape
            data = self.scaler.fit_transform(Xs.values.reshape(-1, 1))
            return data.reshape(shape)
        else:
            return self.scaler.fit_transform(Xs)

    def transform(self, X):
        Xs = pd.DataFrame(data = X)
        if self.aggregate_dims: 
            return self.scaler.transform(Xs.values.reshape(-1,1)).reshape(Xs.shape)
        else:
            return self.scaler.transform(Xs)

    def inverse_transform(self, X):
        Xs = pd.DataFrame(data = X)
        if self.aggregate_dims: 
            return self.scaler.inverse_transform(Xs.values.reshape(-1,1)).reshape(Xs.shape)
        else:
            return self.scaler.inverse_transform(Xs)

class GlobalMinMaxScaler(sklearn.base.BaseEstimator, sklearn.base.TransformerMixin):
    def fit(self, X, y=None):
        self.min_ = X.min()
        self.max_ = X.max()
        return self

    def transform(self, X, y=None):
        return 2 * (X - self.min_) / (self.max_ - self.min_) - 1

    def inverse_transform(self, X, y=None):
        return (X + 1) / 2 * (self.max_ - self.min_) + self.min_

