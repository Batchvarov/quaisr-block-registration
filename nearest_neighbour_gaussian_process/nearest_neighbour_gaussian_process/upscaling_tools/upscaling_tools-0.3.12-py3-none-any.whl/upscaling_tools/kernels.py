import logging

import gpytorch
import torch
from linear_operator import to_dense, to_linear_operator
from linear_operator.operators import DiagLinearOperator

log = logging.getLogger(__name__)


def clamp_keops_chunk(chunk: int) -> int:
    """Keep a kernel-checkpoint chunk large enough that KeOps stays enabled.

    ``gpytorch.kernels.keops`` only lazifies its inputs when *both* operands have
    at least ``max_cholesky_size`` rows. A checkpoint chunk below that threshold
    makes the KeOps kernels fall back to a dense ``(chunk, M, d)`` broadcast,
    which uses far more memory than not chunking at all. Applies equally to
    ``beta_features.checkpoint_kernel`` at training time and to the sampler's
    ``matmul_chunk_size``.
    """
    floor = gpytorch.settings.max_cholesky_size.value()
    if chunk < floor:
        log.warning(
            "kernel chunk size %d is below max_cholesky_size=%d, which would "
            "disable KeOps and materialise a dense kernel block; raising to %d",
            chunk, floor, floor,
        )
        return floor
    return chunk


def keops_chunk_count(n_rows: int, chunk: int) -> int:
    """Number of balanced row chunks, each at least ``chunk`` rows wide.

    ``torch.split``, which ``beta_features.checkpoint_kernel`` uses, leaves a
    last chunk of ``n_rows % chunk`` rows. KeOps needs BOTH operands to have at
    least ``max_cholesky_size`` rows, so a short tail falls back to a dense
    ``(tail, M, d)`` broadcast -- a 2205-row tail against 465k inducing points
    asks for 7.6 GiB, which no chunk knob accounts for. ``torch.tensor_split``
    into this many pieces keeps every piece at or above the requested width.
    """
    return max(1, n_rows // max(clamp_keops_chunk(chunk), 1))


def chunked_kernel_matmul(kernel, x1, x2, rhs, chunk: int):
    """``kernel(x1, x2) @ rhs``, evaluated in balanced chunks of ``x1`` rows.

    Replaces ``beta_features.checkpoint_kernel`` for this product, whose split
    is not safe here -- see ``keops_chunk_count``. Evaluating the kernel eagerly
    keeps any outer checkpoint setting from splitting the block a second time.
    """
    pieces = keops_chunk_count(x1.shape[-2], chunk)
    with gpytorch.settings.lazily_evaluate_kernels(False):
        return torch.cat(
            [to_linear_operator(kernel(sub, x2))._matmul(rhs)
             for sub in torch.tensor_split(x1, pieces, dim=-2)],
            dim=-2,
        )


def parse_constraint(constraint_def):
    bound_type, value, *rest = constraint_def
    initial_value = rest[0] if rest else None

    if bound_type == 'lessthan':
        # LessThan starts the parameter at upper_bound - softplus(0), i.e.
        # about upper_bound - 0.693, so any bound below 0.693 starts NEGATIVE.
        # A negative outputscale makes the kernel matrix indefinite and the
        # first variational KL Cholesky fails with NotPSDError.
        if initial_value is None and value > 0:
            initial_value = value / 2
        constraint = gpytorch.constraints.LessThan(value, initial_value=initial_value)
    elif bound_type == 'greaterthan':
        constraint = gpytorch.constraints.GreaterThan(value, initial_value=initial_value)
    elif bound_type == 'interval':
        constraint = gpytorch.constraints.Interval(*value, initial_value=initial_value)
    else:
        raise ValueError("Bound type not implemented. Accepted values are 'lessthan', 'greaterthan' and 'interval'")

    # An initial value sitting exactly on a bound inverts to a raw of +/-inf,
    # which is then written into the saved state dict. Reject it here rather
    # than let a model train and serialise around an infinity.
    if initial_value is not None and not torch.isfinite(constraint.initial_value).all():
        raise ValueError(
            f"initial value {initial_value} is not strictly inside the "
            f"'{bound_type}' bound {value}; it inverts to a non-finite raw parameter")

    return constraint


def parse_matern(matern_def: dict):
    nu = matern_def['nu']
    ard_num_dims = matern_def['ard_num_dims']
    use_keops = matern_def.get('keops', True)

    lengthscale_constraint = None
    if 'lengthscale' in matern_def:
        lengthscale_constraint = parse_constraint(matern_def['lengthscale'])

    outputscale_constraint = None
    if 'outputscale' in matern_def:
        outputscale_constraint = parse_constraint(matern_def['outputscale'])

    matern_cls = gpytorch.kernels.keops.MaternKernel if use_keops else gpytorch.kernels.MaternKernel
    kernel = gpytorch.kernels.ScaleKernel(
        matern_cls(
            nu=nu,
            ard_num_dims=ard_num_dims,
            lengthscale_constraint=lengthscale_constraint,
            active_dims=[0,1],
        ),
        outputscale_constraint=outputscale_constraint
    )
    return apply_modulation(kernel, matern_def.get('modulation'))

def parse_rbf(rbf_def: dict):
    ard_num_dims = rbf_def['ard_num_dims']
    use_keops = rbf_def.get('keops', True)

    lengthscale_constraint = None
    if 'lengthscale' in rbf_def:
        lengthscale_constraint = parse_constraint(rbf_def['lengthscale'])

    outputscale_constraint = None
    if 'outputscale' in rbf_def:
        outputscale_constraint = parse_constraint(rbf_def['outputscale'])

    rbf_cls = gpytorch.kernels.keops.RBFKernel if use_keops else gpytorch.kernels.RBFKernel
    kernel = gpytorch.kernels.ScaleKernel(
        rbf_cls(
            ard_num_dims=ard_num_dims,
            lengthscale_constraint=lengthscale_constraint,
            active_dims=[0,1],
        ),
        outputscale_constraint=outputscale_constraint
    )
    return apply_modulation(kernel, rbf_def.get('modulation'))

def parse_constant(constant_def: dict):
    return gpytorch.kernels.ConstantKernel()

def parse_kernel(kernel_def: dict):
    kernel = kernel_def['kernel']

    if kernel == 'matern':
        return parse_matern(kernel_def['options'])
    if kernel == 'rbf':
        return parse_rbf(kernel_def['options'])
    if kernel == 'constant':
        return parse_constant(kernel_def['options'])

    raise ValueError("Kernel type not implemented. Accepted values are 'rbf', 'matern', 'constant'")

def construct_kernel(kernel_defs):
    # TODO: User specified kernels have __dict__ method.
    kernels = [parse_kernel(kernel) for kernel in kernel_defs]
    return gpytorch.kernels.AdditiveKernel(*kernels)


def apply_modulation(kernel, modulation):
    """Wrap a component in an AmplitudeModulatedKernel, if its definition asks.

    `control_points` sits in the kernel definition rather than being derived
    from the training data here, so `construct_kernel` rebuilds an identical
    module from a saved checkpoint without seeing the data again. The block that
    builds the definition is the one that has the data.

    The default log-amplitude interval of [-1, 1] lets g range over a factor of
    e either way once the weights are centred. Widen it only with evidence: the
    ELBO rewards prior variance wherever it can be put, which is the same
    failure the outputscale caps exist to stop.
    """
    if not modulation:
        return kernel

    constraint = None
    if 'log_amplitude' in modulation:
        constraint = parse_constraint(modulation['log_amplitude'])

    return AmplitudeModulatedKernel(
        kernel,
        control_points=modulation['control_points'],
        control_lengthscale=modulation['lengthscale'],
        log_amplitude_constraint=constraint,
    )


def control_grid(points, count: int) -> torch.Tensor:
    """A count x count grid of control points over the bounding box of `points`.

    Inset by half a cell, so no control point sits on the boundary where only
    one side of it holds data.
    """
    points = torch.as_tensor(points)
    mins = points.min(dim=-2).values
    maxs = points.max(dim=-2).values
    step = (maxs - mins) / count
    axes = [torch.linspace(float(lo + h / 2), float(hi - h / 2), count,
                           dtype=points.dtype)
            for lo, hi, h in zip(mins, maxs, step)]
    mesh = torch.meshgrid(*axes, indexing="ij")
    return torch.stack(mesh, dim=-1).reshape(-1, points.shape[-1])


class AmplitudeModulatedKernel(gpytorch.kernels.Kernel):
    r"""Scale a stationary kernel by a smooth field of the inputs.

    .. math::
        \tilde k(x, x') = g(x)\, k(x, x')\, g(x')

    with :math:`\log g` an RBF-bump expansion on a fixed grid of control points.
    This says the component is present in some regions and absent in others,
    which is a different claim from a component whose lengthscale moves.

    Positive definite for any g, because the matrix is :math:`D_g K D_g`. That is
    also how it is built, so a KeOps base kernel stays lazy: the two diagonal
    operators multiply into a matmul rather than materialising K.

    The control points are a buffer, not a parameter. Fitting their positions as
    well as their weights makes the field able to chase individual points, and
    the ELBO already rewards prior variance wherever it is put.
    """

    def __init__(self, base_kernel, control_points, control_lengthscale: float,
                 log_amplitude_constraint=None, **kwargs):
        if base_kernel.active_dims is not None:
            kwargs["active_dims"] = base_kernel.active_dims
        super().__init__(**kwargs)

        if log_amplitude_constraint is None:
            log_amplitude_constraint = gpytorch.constraints.Interval(-1.0, 1.0)

        self.base_kernel = base_kernel
        self.register_buffer(
            "control_points", torch.as_tensor(control_points, dtype=torch.get_default_dtype()))
        self.register_buffer(
            "control_lengthscale", torch.as_tensor(float(control_lengthscale)))
        self.register_parameter(
            "raw_log_amplitude",
            torch.nn.Parameter(torch.zeros(len(self.control_points))))
        self.register_constraint("raw_log_amplitude", log_amplitude_constraint)

    @property
    def is_stationary(self) -> bool:
        return False

    @property
    def log_amplitude(self) -> torch.Tensor:
        return self.raw_log_amplitude_constraint.transform(self.raw_log_amplitude)

    def amplitude(self, x: torch.Tensor) -> torch.Tensor:
        """g(x), one value per input row.

        The weights are centred before they are used. g and the base kernel's
        outputscale are otherwise the same parameter twice over -- doubling g
        and quartering the outputscale leaves the kernel unchanged -- and the
        pair drifts along that direction without ever changing the ELBO.
        Centring fixes the gauge, so the outputscale keeps the overall level and
        g carries only the contrast.
        """
        weights = self.log_amplitude
        weights = weights - weights.mean()
        distance = torch.cdist(x, self.control_points.to(x))
        basis = torch.exp(-0.5 * (distance / self.control_lengthscale.to(x)) ** 2)
        return torch.exp(basis @ weights)

    def forward(self, x1, x2, diag=False, last_dim_is_batch=False, **params):
        if last_dim_is_batch:
            raise NotImplementedError(
                "AmplitudeModulatedKernel does not support last_dim_is_batch")

        base = self.base_kernel.forward(x1, x2, diag=diag, **params)
        g1 = self.amplitude(x1)
        g2 = self.amplitude(x2)
        if diag:
            return to_dense(base) * g1 * g2
        return DiagLinearOperator(g1) @ to_linear_operator(base) @ DiagLinearOperator(g2)

    def num_outputs_per_input(self, x1, x2):
        return self.base_kernel.num_outputs_per_input(x1, x2)

    def stationary_part(self):
        """The kernel with the modulation stripped.

        The FFT prior sampler embeds a covariance that depends on the lag alone
        (`nngp_fft_prior._kernel_first_row` evaluates `kernel(h, 0)`), so it has
        to be given this rather than the modulated kernel. Multiply the drawn
        path by `amplitude` afterwards to put the modulation back.
        """
        return self.base_kernel


def split_modulated(kernel):
    """Partition a kernel into its stationary part and its modulated components.

    Returns ``(stationary, modulated)``. ``stationary`` is None when every
    component is modulated, and ``modulated`` is empty for an ordinary kernel.

    The prior of a sum kernel is a sum of independent processes, so each group
    can be drawn on its own and added back. That is what lets the FFT sampler
    keep working: every group it is handed is stationary.

    Only the top level is split. A modulated kernel nested deeper is not found
    here, and `build_fft_spectrum` then raises on it -- its own search walks the
    whole module tree -- so the case fails loudly rather than sampling the wrong
    covariance.
    """
    if isinstance(kernel, AmplitudeModulatedKernel):
        return None, [kernel]

    if isinstance(kernel, gpytorch.kernels.AdditiveKernel):
        modulated = [part for part in kernel.kernels
                     if isinstance(part, AmplitudeModulatedKernel)]
        if not modulated:
            return kernel, []
        stationary = [part for part in kernel.kernels
                      if not isinstance(part, AmplitudeModulatedKernel)]
        return (gpytorch.kernels.AdditiveKernel(*stationary) if stationary else None), modulated

    return kernel, []
