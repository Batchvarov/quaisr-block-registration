#from gpytorch.variational import (
#    MeanFieldVariationalDistribution,
#    UnwhitenedVariationalStrategy,
#    VariationalStrategy,
#    CholeskyVariationalDistribution)
#import torch
#
#class VariationalGPModel(ApproximateGP):
#    def __init__(self,
#                 inducing_points,
#                 mean_module,
#                 covar_module,
#                 likelihood,
#                 feature_extractor=upscaling_tools.features.FeatureIdentity()
#                 ):
#
#        variational_distribution = CholeskyVariationalDistribution(
#            inducing_points.size(-2), batch_shape=covar_module.batch_shape)
#        variational_strategy = UnwhitenedVariationalStrategy(
#            self, inducing_points, variational_distribution, learn_inducing_locations=False)
#        super(VariationalGPModel, self).__init__(variational_strategy)
#
#        self.mean_module = mean_module
#        self.covar_module = covar_module
#        self.likelihood = likelihood
#        self.feature_extractor = feature_extractor
#
#    def forward(self, x: torch.Tensor):
#        projected_x = self.feature_extractor(x)
#        mean_x = self.mean_module(projected_x)
#        covar_x = self.covar_module(projected_x)
#        return gpytorch.distributions.MultivariateNormal(mean_x, covar_x)
#

#    def compute_covar(self, x1: torch.Tensor, x2: torch.Tensor):
#        x1proj = self.feature_extractor(x1)
#        x2proj = self.feature_extractor(x2)
#        return self.covar_module(x1proj, x2proj)

#    def sample_from_var(self, x, n, **kwargs):
#        with torch.no_grad(), gpytorch.settings.fast_pred_var():
#            vargp = self.get_var_gp()
#            vargp.eval()
#            vargp.likelihood.eval()
#            vargp.to(device=self.train_inputs.device)
#            vargp.likelihood.to(device=self.train_inputs.device)
#            posterior = vargp(x.to(device=self.train_inputs.device))
#            samples = posterior.sample(torch.Size([n, ]))
#            return samples, np.zeros(n)

#    def get_var_gp(self):
#        varmodel = VariationalGPModel(
#            self.train_inputs,
#            self.mean_module,
#            self.covar_module,
#            self.likelihood)
#        varmodel.to(device=self.train_inputs.device)
#        varmodel.likelihood.to(device=self.train_inputs.device)
#        varmodel.variational_strategy._variational_distribution.initialize_variational_distribution(
#            self(self.train_inputs))
#        varmodel.variational_strategy.variational_params_initialized = torch.tensor(1)
#        return varmodel

#    def get_botorch_model(self):
#        mean = self.variational_strategy.variational_distribution.mean
#        inducing_points = self.variational_strategy.inducing_points
#        return SingleTaskGP(inducing_points, mean.unsqueeze(dim=1),
#                            mean_module=self.mean_module,
#                            covar_module=self.covar_module,
#                            likelihood=self.likelihood,
#                            input_transform=None,
#                            outcome_transform=None,
#        )

