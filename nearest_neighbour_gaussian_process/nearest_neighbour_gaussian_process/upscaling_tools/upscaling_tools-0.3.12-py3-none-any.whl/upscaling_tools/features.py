import torch
import gpytorch

import numpy as np
import sklearn

class FeatureIdentity(torch.nn.Module):
    def __init__(self):
        super(FeatureIdentity, self).__init__()

    def forward(self, X) -> torch.Tensor:
        return X

class LargeFeatureExtractor(torch.nn.Sequential):
    def __init__(self, input_dim):
        super(LargeFeatureExtractor, self).__init__()
        self.add_module('linear1', torch.nn.Linear(input_dim, 500))
        self.add_module('relu1', torch.nn.ReLU())
        self.add_module('linear2', torch.nn.Linear(500, 250))
        self.add_module('relu2', torch.nn.ReLU())
        self.add_module('linear3', torch.nn.Linear(250, 25))
        self.add_module('relu3', torch.nn.ReLU())
        self.add_module('linear4', torch.nn.Linear(25, 2))
        self.add_module('scale', gpytorch.utils.grid.ScaleToBounds(-1., 1.))

class SmallFeatureExtractor(torch.nn.Sequential):
    def __init__(self, input_dim, n=20):
        super(SmallFeatureExtractor, self).__init__()
        self.add_module('linear1', torch.nn.Linear(input_dim, n))
        self.add_module('lrelu', torch.nn.ReLU())
        self.add_module('linear2', torch.nn.Linear(n, 2))
        self.add_module('scale', gpytorch.utils.grid.ScaleToBounds(-1., 1.))

class SmallFeatureExtractor2(torch.nn.Sequential):
    def __init__(self, input_dim, latent_dim):
        super(SmallFeatureExtractor2, self).__init__()
        self.latent_dim = latent_dim
        self.input_dim = input_dim
        self.add_module('linear1', torch.nn.Linear(input_dim, 100))
        self.add_module('relu1', torch.nn.ReLU())
        self.add_module('linear2', torch.nn.Linear(100, 50))
        self.add_module('relu2', torch.nn.ReLU())
        self.add_module('linear3', torch.nn.Linear(50, 5))
        self.add_module('relu3', torch.nn.ReLU())
        self.add_module('linear4', torch.nn.Linear(5, latent_dim))
