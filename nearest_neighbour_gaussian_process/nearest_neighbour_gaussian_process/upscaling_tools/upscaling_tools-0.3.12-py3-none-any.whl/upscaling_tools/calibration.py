"""Correct a reported predictive variance against held-out residuals.

The model reports the variance of what its kernel can represent. Whatever it
cannot -- a measurement nugget, or signal below the resolvable floor of
2 x the inducing spacing -- lands in the residual instead, so the interval comes
out too narrow by that amount.

Widening it by raising the likelihood noise during training does not work: the
noise is inside the ELBO, so it changes the fit, and the fit gets worse. This
module corrects the variance after training, which leaves the posterior mean
alone.

One additive constant is the right shape for the correction. The shortfall is a
property of the field rather than of how far a point sits from the data, and a
multiplicative factor would inflate the gaps -- already honest -- as much as the
covered ground, which is where the defect is.
"""

from typing import NamedTuple

import numpy as np
import scipy.spatial

# Matches compute_error_rate's default, so the two report the same interval.
NSTD = 1.96
TARGET_COVERAGE = 0.95

# Below this many points the fitted nugget is dominated by which points happened
# to land in the set, so a larger but biased source is the better trade.
MIN_CALIBRATION_POINTS = 50


def coverage(residual, variance, nstd: float = NSTD) -> float:
    """Fraction of residuals falling inside the nstd interval."""
    residual = np.asarray(residual, dtype=float)
    variance = np.asarray(variance, dtype=float)
    return float(np.mean(np.abs(residual) <= nstd * np.sqrt(np.maximum(variance, 0.0))))


def fit_predictive_nugget(residual, variance, target: float = TARGET_COVERAGE,
                          nstd: float = NSTD, iterations: int = 60) -> float:
    """Smallest variance to add so that `target` of the residuals fall inside.

    Returns 0.0 when the interval is already wide enough. Coverage rises
    monotonically with the added variance, so a bisection is exact to the
    iteration count.
    """
    residual = np.asarray(residual, dtype=float)
    variance = np.asarray(variance, dtype=float)
    if residual.size == 0 or coverage(residual, variance, nstd) >= target:
        return 0.0

    # Grow the bracket rather than assume one: a heavy-tailed residual can need
    # far more than a few times its own variance.
    low, high = 0.0, max(float(np.var(residual)), np.finfo(float).tiny)
    while coverage(residual, variance + high, nstd) < target and high < 1e30:
        high *= 4.0

    for _ in range(iterations):
        mid = 0.5 * (low + high)
        if coverage(residual, variance + mid, nstd) < target:
            low = mid
        else:
            high = mid
    return 0.5 * (low + high)


def cross_fitted_error_rate(residual, variance, target: float = TARGET_COVERAGE,
                            nstd: float = NSTD, seed: int = 0) -> float:
    """Error rate of the corrected interval, measured out of sample.

    Fitting the nugget and then reporting the coverage it was fitted to would
    report `1 - target` back whatever the data says. Split in two, fit on one
    half and measure on the other, then swap, so every point is measured under a
    nugget it did not inform.

    Returns nan when there are too few points to split.
    """
    residual = np.asarray(residual, dtype=float)
    variance = np.asarray(variance, dtype=float)
    if residual.size < 4:
        return float("nan")

    order = np.random.default_rng(seed).permutation(residual.size)
    halves = (order[: residual.size // 2], order[residual.size // 2:])

    inside = 0
    for fit_idx, eval_idx in (halves, halves[::-1]):
        nugget = fit_predictive_nugget(
            residual[fit_idx], variance[fit_idx], target, nstd)
        inside += coverage(
            residual[eval_idx], variance[eval_idx] + nugget, nstd) * eval_idx.size
    return 1.0 - inside / residual.size


class NuggetField(NamedTuple):
    """A predictive nugget that varies in space.

    One value per control point, plus the survey-wide fit that thinly covered
    nodes fall back to. `radius` is the neighbourhood each node is fitted from;
    `width` is how far a node's value carries when the field is evaluated.

    They are separate because they answer to different pressures. The radius has
    to be wide enough to hold MIN_CALIBRATION_POINTS residuals. The width has to
    be narrow enough that a loud node does not leak into a quiet one: these
    values span orders of magnitude, so even a tenth of the weight on a node a
    hundred times larger swamps the local answer. Half the radius is the default,
    which keeps the transition smooth without the leak.

    The values are variances in the units of the measurements, and the control
    points are in the model's scaled input space -- the space the residuals were
    measured in. Evaluating the field anywhere else silently returns the wrong
    correction.
    """

    control_points: np.ndarray
    values: np.ndarray
    radius: float
    width: float
    global_nugget: float
    counts: np.ndarray


def fit_nugget_field(points, residual, variance, control_points, radius,
                     target: float = TARGET_COVERAGE, nstd: float = NSTD,
                     min_points: int = MIN_CALIBRATION_POINTS,
                     width: float | None = None) -> NuggetField:
    """Fit one nugget per control point, from the residuals within `radius`.

    A single nugget assumes the variance the kernel cannot represent is the same
    everywhere. Where it is not, the reported interval comes out too narrow in
    the rough ground and too wide in the quiet ground, and the two errors hide
    each other in the survey-wide rate.

    Nodes holding fewer than `min_points` residuals take the survey-wide fit
    instead. A nugget fitted on a handful of points is dominated by which points
    happened to land there, which is the same reason `MIN_CALIBRATION_POINTS`
    exists for the global fit.
    """
    points = np.ascontiguousarray(points, dtype=float)
    control_points = np.ascontiguousarray(control_points, dtype=float)
    residual = np.asarray(residual, dtype=float).ravel()
    variance = np.asarray(variance, dtype=float).ravel()

    global_nugget = fit_predictive_nugget(residual, variance, target, nstd)
    tree = scipy.spatial.cKDTree(points)

    values = np.empty(len(control_points))
    counts = np.zeros(len(control_points), dtype=int)
    for node, centre in enumerate(control_points):
        near = tree.query_ball_point(centre, radius)
        counts[node] = len(near)
        values[node] = (
            fit_predictive_nugget(residual[near], variance[near], target, nstd)
            if len(near) >= min_points else global_nugget)

    return NuggetField(control_points=control_points, values=values, radius=float(radius),
                       width=float(radius / 2 if width is None else width),
                       global_nugget=float(global_nugget), counts=counts)


def nugget_at(points, field: NuggetField, chunk: int = 200_000) -> np.ndarray:
    """The nugget field evaluated at `points`, in the same scaled space.

    Gaussian weights of width `field.width`, normalised, so the result stays
    between the smallest and largest node value and cannot run away between
    nodes. A point further than a few widths from every node -- a gap wider than
    the control spacing -- takes the survey-wide value rather than the ratio of
    two numbers that have both underflowed.
    """
    points = np.ascontiguousarray(points, dtype=float)
    out = np.empty(len(points))
    for start in range(0, len(points), chunk):
        block = points[start:start + chunk]
        distance = scipy.spatial.distance.cdist(block, field.control_points)
        weight = np.exp(-0.5 * (distance / field.width) ** 2)
        total = weight.sum(axis=1)
        local = (weight @ field.values) / np.where(total > 0, total, 1.0)
        out[start:start + chunk] = np.where(total > 1e-12, local, field.global_nugget)
    return out


def cross_fitted_field_error_rate(points, residual, variance, control_points, radius,
                                  target: float = TARGET_COVERAGE, nstd: float = NSTD,
                                  min_points: int = MIN_CALIBRATION_POINTS,
                                  width: float | None = None, seed: int = 0) -> float:
    """Error rate of the field-corrected interval, measured out of sample.

    A field has one parameter per node rather than one in total, so the gap
    between the rate it was fitted to and the rate it earns is wider than for a
    single nugget. Splitting matters more here, not less.
    """
    residual = np.asarray(residual, dtype=float).ravel()
    variance = np.asarray(variance, dtype=float).ravel()
    points = np.ascontiguousarray(points, dtype=float)
    if residual.size < 4:
        return float("nan")

    order = np.random.default_rng(seed).permutation(residual.size)
    halves = (order[: residual.size // 2], order[residual.size // 2:])

    inside = 0
    for fit_idx, eval_idx in (halves, halves[::-1]):
        field = fit_nugget_field(
            points[fit_idx], residual[fit_idx], variance[fit_idx],
            control_points, radius, target, nstd, min_points, width)
        corrected = variance[eval_idx] + nugget_at(points[eval_idx], field)
        inside += coverage(residual[eval_idx], corrected, nstd) * eval_idx.size
    return 1.0 - inside / residual.size
