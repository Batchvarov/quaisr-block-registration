from copy import deepcopy
from typing import Any

from botorch.models.transforms.input import InputTransform
from botorch.sampling.pathwise.paths import GeneralizedLinearPath
from botorch.sampling.pathwise.prior_samplers import TPathwisePriorSampler
from botorch.sampling.pathwise.update_strategies import TPathwiseUpdate
from botorch.utils.types import NoneType
from gpytorch.kernels.kernel import ZeroLinearOperator
from gpytorch.module import LinearOperator
import numpy as np
import pandas as pd

from botorch.models import MultiTaskGP
from gpytorch.variational import CholeskyVariationalDistribution, LMCVariationalStrategy, UnwhitenedVariationalStrategy, VariationalStrategy
import torch
import gpytorch

from gpytorch.models import ApproximateGP, ExactGP
from gpytorch.variational.nearest_neighbor_variational_strategy import NNVariationalStrategy
from botorch.sampling.pathwise.posterior_samplers import DrawMatheronPaths, MatheronPath, draw_matheron_paths, get_matheron_path_model
from torch.types import Size, Tensor

from botorch.sampling.pathwise.update_strategies import GaussianUpdate, TPathwiseUpdate, _gaussian_update_exact
from botorch.utils.transforms import is_ensemble

import upscaling_tools.features
import upscaling_tools.inducing
import upscaling_tools.stream

from tqdm import tqdm

class MultiTaskGPModel(ApproximateGP):
    def __init__(self,
            inducing_points,
            likelihood,
            k,
            training_batch_size,
            kernel,
            num_tasks,
            num_latents,
            mean: gpytorch.means.Mean,
            batch_shape: torch.Size = torch.Size([]),
            feature_extractor = upscaling_tools.features.FeatureIdentity(),
    ):
        self.k = k

        variational_distribution = gpytorch.variational.MeanFieldVariationalDistribution(
            inducing_points.size(-2),
            batch_shape=batch_shape,
            learn_inducing_locations=False
        )
        variational_strategy = NNVariationalStrategy(
            self,
            inducing_points,
            variational_distribution,
            k=k,
            training_batch_size=training_batch_size)

        variational_strategy = gpytorch.variational.LMCVariationalStrategy(
            NNVariationalStrategy(self,
                inducing_points,
                variational_distribution,
                k=k,
                training_batch_size=training_batch_size),
            num_tasks=num_tasks,
            num_latents=num_latents,
            latent_dim=-1
        )

        super(MultiTaskGPModel, self).__init__(variational_strategy)
        self.feature_extractor = deepcopy(feature_extractor)
        self.mean_module = deepcopy(mean)
        self.covar_module = deepcopy(kernel)
        self.likelihood = deepcopy(likelihood)
        self.num_tasks = num_tasks
        self.num_latents = num_latents

    def forward(self, x: torch.Tensor):
        mean_x = self.mean_module(x)
        covar_x = self.covar_module(x)
        return gpytorch.distributions.MultivariateNormal(mean_x, covar_x)

    def __call__(self, x: torch.Tensor, prior=False, **kwargs):
        if x is not None:
            if x.dim() == 1:
                x = x.unsqueeze(-1)
        return self.variational_strategy(x=x, prior=False, **kwargs)

    def sample_pathwise(self, x, n, **kwargs):
        with torch.no_grad():
            self.eval()
            sampler = draw_matheron_paths(model=self, sample_shape=torch.Size([n, ]), **kwargs)
            samples = sampler(x)
            return samples, np.zeros(n)

    def sample_from_multitask(self, x, n, latent=False, **kwargs):
        with torch.no_grad(), gpytorch.settings.fast_pred_var():
            self.eval()
            self.likelihood.eval()
            if latent:
                posterior = self(x.to(device=self.train_inputs.device))
            else:
                posterior = self.likelihood(self(x.to(device=self.train_inputs.device)))

            samples = posterior.sample(torch.Size([n, ]))
            return samples, np.zeros(n)

    def inference(self, xs, output_scaler = None):
        dtype = self.train_inputs.dtype
        # Assume xs given in the inputs pre-transformation.
        xs_transformed = xs.to(dtype=dtype)

        with torch.no_grad():
            vargp = self#.get_var_gp()
            vargp.eval()
            vargp.likelihood.eval()
            y_preds = vargp.likelihood(vargp(xs_transformed))
            y_mean = y_preds.mean.detach().cpu()
            y_var = y_preds.variance.detach().cpu()

            if hasattr(y_preds, "confidence_region"):
                y_lower, y_upper = y_preds.confidence_region()
                y_lower.cpu()
                y_upper.cpu()

            if output_scaler is not None:
                y_mean = output_scaler.inverse_transform(y_mean)
                y_var = y_var #* np.square(output_scaler.scale_)

                if hasattr(y_preds, "confidence_region"):
                    y_lower = output_scaler.inverse_transform(y_lower)
                    y_upper = output_scaler.inverse_transform(y_upper)

            dfs = []
            for task in range(0, self.num_tasks):
                df = pd.DataFrame({
                    f'GP_mean_task_{task}': y_mean[..., task].flatten(),
                    f'GP_variance_task_{task}': y_var[..., task].flatten(),
                    f'GP_std_task_{task}': torch.sqrt(y_var[..., task].flatten()),
                })

                if hasattr(y_preds, "confidence_region"):
                    df[f'GP_upper_task_{task}'] = y_upper[..., task].flatten()
                    df[f'GP_lower_task_{task}'] = y_lower[..., task].flatten()

                dfs.append(df)

            return pd.concat(dfs, axis=1)

    def sample_gp(self, xs, n_samples, latent: bool = False, output_scaler = None, **kwargs):
        xs_transformed = xs
        f_samples, _ = self.sample_from_multitask(xs_transformed, n_samples, latent=latent, **kwargs)

        dfs = []
        for sample in range(0, n_samples):
            sample_ = f_samples[sample, ...]
            if output_scaler is not None:
                sample_ = output_scaler.inverse_transform(sample_)

            for task in range(0, self.num_tasks):
                to_save = sample_[..., task]
                df = pd.DataFrame({f'GP_sample_{sample}_task_{task}': to_save})
                dfs.append(df)

        return pd.concat(dfs, axis=1)

#@DrawMatheronPaths.register(ApproximateGP, LMCVariationalStrategy)
#def _draw_matheron_paths_ApproximateGP_fallback(
#    model: ApproximateGP,
#    _: NNVariationalStrategy,
#    *,
#    sample_shape: Size,
#    prior_sampler: TPathwisePriorSampler,
#    update_strategy: TPathwiseUpdate,
#    **kwargs: Any,
#) -> MatheronPath:
#    # Note: Inducing points are assumed to be pre-transformed
#    Z = model.variational_strategy.base_variational_strategy.inducing_points
#
#    # Generate draws from the prior
#    prior_paths = prior_sampler(model=model, sample_shape=sample_shape, **kwargs)
#    sample_values = prior_paths.forward(Z)  # forward bypasses transforms
#
#    # Compute pathwise updates
#    update_paths = update_strategy(model=model, sample_values=sample_values)
#    return MatheronPath(prior_paths=prior_paths, update_paths=update_paths)
#
#@GaussianUpdate.register(ApproximateGP, LMCVariationalStrategy)
#def _gaussian_update_ApproximateGP_unwhitened(
#    model: ApproximateGP,
#    variational_strategy: VariationalStrategy,
#    *,
#    sample_values: Tensor,
#    target_values: Tensor | None = None,
#    noise_covariance: Tensor | LinearOperator | None = None,
#    input_transform: InputTransform | None = None,
#    **ignore: Any,
#) -> GeneralizedLinearPath:
#    # TODO: Account for jitter added by `psd_safe_cholesky`
#    if not isinstance(noise_covariance, (NoneType, ZeroLinearOperator)):
#        raise NotImplementedError(
#            f"`noise_covariance` argument not yet supported for {type(model)}."
#        )
#
#    # Inducing points `Z` are assumed to live in transformed space
#    batch_shape = model.covar_module.batch_shape
#    Z = variational_strategy.base_variational_strategy.inducing_points
#    L = variational_strategy.base_variational_strategy._cholesky_factor(
#        variational_strategy(Z, prior=True).lazy_covariance_matrix
#    ).to(dtype=sample_values.dtype)
#
#    # Generate whitened inducing variables `u`, then location-scale transform
#    if target_values is None:
#        target_values = variational_strategy.variational_distribution.rsample(
#            sample_values.shape[: sample_values.ndim - len(batch_shape) - 1],
#        )
#
#    return _gaussian_update_exact(
#        kernel=model.covar_module,
#        points=Z,
#        target_values=target_values,
#        sample_values=sample_values,
#        scale_tril=L,
#        input_transform=input_transform,
#        is_ensemble=is_ensemble(model),
#    )
#

def construct_model(X, y, kernel, likelihood, parameters,
        batch_shape = torch.Size([]),
        inducing_points_allocator: upscaling_tools.inducing.InducingPointsAllocation = upscaling_tools.inducing.DatapointsAsInducing(),
        mean_module = gpytorch.means.ConstantMean(),
        mll = gpytorch.mlls.VariationalELBO,
        **kwargs):
    device = torch.device('cpu')
    dtype = torch.float32

    if torch.cuda.is_available():
        device = torch.device("cuda")

    torch.set_default_dtype(dtype)
    k = parameters['k']
    training_batch_size = parameters['training_batch_size']

    X = X.detach().clone()
    y = y.detach().clone()

    inducing_points = inducing_points_allocator.initialise(X)
    model = MultiTaskGPModel(
        mean=mean_module,
        inducing_points=inducing_points,
        likelihood=likelihood,
        k=k,
        training_batch_size=training_batch_size,
        kernel=kernel,
        batch_shape=batch_shape,
        **kwargs)

    mll = mll(likelihood, model, num_data=y.size(0))

    model.train_inputs = X.to(dtype=dtype)
    model.train_outputs = y.to(dtype=dtype)

    model.to(dtype=dtype).to(device=device)
    likelihood.to(dtype=dtype).to(device=device)

    print('Initialised a GP model.')
    model.train()
    likelihood.train()

    return model, mll, device, dtype

def multitask_training(X, y, kernel, likelihood, parameters, loss_stream = upscaling_tools.stream.StreamList(), **kwargs):
    model, mll, device, dtype = construct_model(X, y, kernel, likelihood, parameters, **kwargs)

    training_batch_size = parameters['training_batch_size']
    learning_rate = parameters['learning_rate']
    training_epochs = parameters['training_epochs']
    milestones = parameters['milestones']

    print('Initialised an optimizer.')
    optimizer = torch.optim.Adam([
        {'params': model.covar_module.parameters()},
        {'params': model.mean_module.parameters()},
        {'params': model.likelihood.parameters()},
        {'params': model.variational_parameters()},
        {'params': model.feature_extractor.parameters(), 'lr': 1e-2}
    ], lr=learning_rate)

    scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=milestones, gamma=0.1)
    losses = []

    num_batches = model.variational_strategy.base_variational_strategy._total_training_batches
    epochs_iter = tqdm(range(training_epochs), desc="Epoch")

    for epoch in epochs_iter:
        minibatch_iter = tqdm(range(num_batches), desc="Minibatch", disable=True)
        for _ in minibatch_iter:
            optimizer.zero_grad()
            output = model(x=None)
            current_training_indices = model.variational_strategy.base_variational_strategy.current_training_indices
            y_batch = model.train_outputs[current_training_indices, ...].to(device=device, dtype=dtype)
            loss = -mll(output, y_batch)

            loss_item = loss.item()
            losses.append(loss_item)
            loss_stream.write_list(losses)
            minibatch_iter.set_postfix(loss=loss.item())

            loss.backward()
            optimizer.step()
            scheduler.step()

        epochs_iter.set_description("Loss %f" % losses[-1])

    return model, losses
