import warnings
from itertools import accumulate

import torch
from hilbertsfc.torch import hilbert_encode_2d, hilbert_encode_3d
from scipy.spatial import KDTree


def hilbert_sort_indices(X: torch.Tensor, nbits: int = 20) -> torch.Tensor:
    """Return indices that sort rows of X by Hilbert curve distance.

    Spatially close points get close indices, which makes NNGP Cholesky
    a much better preconditioner: PCG typically converges in 2-5 iters
    instead of 50+ with random ordering.

    Args:
        X:     (M, D) tensor of coordinates. D must be 1, 2, or 3.
        nbits: bits per coordinate axis (default 20 → ~1M grid cells per axis).
               Max 32 for 2D, max 21 for 3D.

    Returns:
        (M,) LongTensor of sorted indices, on the same device as X.
    """
    lo = X.amin(dim=0)
    hi = X.amax(dim=0)
    span = (hi - lo).clamp(min=1e-10)
    scale = (1 << nbits) - 1
    norm = ((X - lo) / span * scale).long()

    D = X.shape[1]
    if D == 1:
        codes = norm[:, 0]
    elif D == 2:
        codes = hilbert_encode_2d(norm[:, 0], norm[:, 1], nbits=nbits)
    elif D == 3:
        codes = hilbert_encode_3d(norm[:, 0], norm[:, 1], norm[:, 2], nbits=nbits)
    else:
        codes = norm[:, 0]  # D>3: sort on first coordinate only

    return torch.argsort(codes)


def _geometric_split(R: int, J: int) -> list[int]:
    """Split R items into J groups with geometrically increasing sizes (ratio 2)."""
    total_parts = (1 << J) - 1
    sizes = [max(1, R * (1 << j) // total_parts) for j in range(J - 1)]
    sizes.append(R - sum(sizes))
    return sizes


def assign_level_sizes(M: int, n_levels: int, k: int) -> list[int]:
    """Compute point count per hierarchical Vecchia level.

    L_0 has exactly k points (global skeleton = NNGPCholeskyLinearOperator L_first block).
    L_1..L_{n_levels-1} split remaining M-k points geometrically (ratio 2).
    """
    if M < 2 * k:
        raise ValueError(f"M={M} must be >= 2*k={2*k} for hierarchical Vecchia")
    max_levels = max(1, M // k)
    if n_levels > max_levels:
        warnings.warn(f"n_levels reduced {n_levels} -> {max_levels} (M={M}, k={k})")
        n_levels = max_levels
    if n_levels == 1:
        return [M]
    if n_levels == 2:
        return [k, M - k]
    return [k] + _geometric_split(M - k, n_levels - 1)


def _build_kdtree(keys: torch.Tensor) -> KDTree:
    """Build a KDTree on a CPU float copy of keys. Reuse across slab queries."""
    return KDTree(keys.float().cpu().numpy())


def _kdtree_query(tree: KDTree, query: torch.Tensor, n_neighbors: int) -> torch.Tensor:
    """Return (N_q, n_neighbors) neighbor indices from a pre-built KDTree.

    Peak memory: O(N_q × n_neighbors) for the result plus the tree already held
    by the caller. Building the tree once per level and querying slab-by-slab
    keeps the transient result small while amortising the tree build.
    """
    n_neighbors = min(n_neighbors, tree.n)
    _, I = tree.query(query.float().cpu().numpy(), k=n_neighbors, workers=-1)
    if I.ndim == 1:
        I = I[:, None]
    return torch.from_numpy(I).long().to(query.device)


def _causal_knn_slab(
    Z_j: torch.Tensor,
    s_start: int,
    s_end: int,
    k_max: int,
    chunk_size: int,
    window_mult: int = 16,
) -> torch.Tensor:
    """Return (s_end - s_start, k_max) causal NN indices for rows [s_start, s_end).

    For row s in the slab, valid neighbors are indices < s within Z_j
    (predecessors only). Rows where s < k_max have fewer than k_max valid
    predecessors; the caller slices to min(s, k_max) to avoid stale trailing entries.

    Z_j is Hilbert-sorted within its level, so causal k-NNs are spatially local.
    The backward window W = max(k_max * window_mult, chunk_size) exploits
    this: peak memory is O(slab × W) instead of O(slab × n_j).
    """
    n_j = Z_j.shape[0]
    c = s_end - s_start
    if k_max == 0 or n_j <= 1:
        return torch.zeros(c, k_max, dtype=torch.long, device=Z_j.device)

    k_topk = min(k_max, n_j - 1)
    W = max(k_max * window_mult, chunk_size)
    w_start = max(0, s_start - W)

    # Keys: predecessors within window plus the current slab itself
    # (intra-slab causality handled by masking below).
    keys = Z_j[w_start:s_end]  # (s_end - w_start, D)
    dists = torch.cdist(Z_j[s_start:s_end], keys)  # (c, s_end - w_start)

    # Causal mask in local key space: key local-index lk is valid for query
    # local-index li only if its global index (w_start + lk) < (s_start + li).
    n_keys = s_end - w_start
    lk = torch.arange(n_keys, device=Z_j.device)
    li = torch.arange(c, device=Z_j.device)
    threshold = (s_start - w_start) + li  # (c,)
    causal_mask = lk.unsqueeze(0) >= threshold.unsqueeze(1)  # (c, n_keys)
    dists.masked_fill_(causal_mask, float("inf"))

    k_take = min(k_topk, n_keys)
    nn = dists.topk(k_take, largest=False).indices + w_start  # (c, k_take)

    if k_take < k_max:
        pad = torch.zeros(c, k_max - k_take, dtype=torch.long, device=Z_j.device)
        nn = torch.cat([nn, pad], dim=1)
    return nn


def _assemble_parents(
    s: int,
    k: int,
    k_l0_budget: int,
    k_interm_budget: int,
    n_l0: int,
    l0_nn_s: torch.Tensor,
    interm_nn_s: torch.Tensor | None,
    same_nn_s: torch.Tensor,
    start_j: int,
) -> torch.Tensor:
    """Assemble k parent indices (final-order space) for level-local point s.

    Sources: L_0 skeleton (cross, long-range), intermediate coarse levels (cross,
    medium-range), causal same-level neighbors (local). Shortfall from small s
    is back-filled from extra L_0 slots.
    """
    actual_cross = k_l0_budget + k_interm_budget
    actual_same = min(k - actual_cross, s)
    shortfall = k - actual_cross - actual_same
    extra_l0 = min(shortfall, n_l0 - k_l0_budget)
    actual_l0_total = k_l0_budget + extra_l0

    cp_l0 = l0_nn_s[:actual_l0_total]
    if interm_nn_s is not None and k_interm_budget > 0:
        cp = torch.cat([cp_l0, interm_nn_s[:k_interm_budget]])
    else:
        cp = cp_l0

    sp = same_nn_s[:actual_same] + start_j

    parents = torch.cat([cp, sp])
    if parents.shape[0] < k:
        n_pad = k - parents.shape[0]
        pad_start = actual_l0_total
        parents = torch.cat([parents, l0_nn_s[pad_start:pad_start + n_pad]])

    return parents[:k]


def hierarchical_vecchia_dag(
    Z: torch.Tensor,
    k: int,
    n_levels: int = 3,
    nbits: int = 20,
    chunk_size: int = 2000,
    k_cross_ratio: float = 0.5,
    k_l0_fraction: float = 0.5,
    causal_window_mult: int = 16,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Build hierarchical Vecchia DAG ordering and parent indices.

    Points are partitioned into levels L_0 (k-point global skeleton) through
    L_{n_levels-1} (fine). Each non-skeleton point i conditions on k_cross
    parents from coarser levels (long-range) and k_same parents from earlier
    same-level points (local), with k_cross = k * k_cross_ratio by default.

    Cross-level parents are stratified: k_l0_fraction of the cross budget is
    reserved for L_0 (global skeleton), so long-range dependencies are captured
    even when intermediate coarse points are spatially nearby. Remaining cross
    slots come from the nearest points in L_1..L_{j-1}.

    Args:
        Z: (M, D) inducing points (CPU tensor).
        k: parents per point; also the size of NNGPCholeskyLinearOperator.L_first.
        n_levels: number of hierarchy levels.
        nbits: bits for Hilbert encoding within each level.
        chunk_size: max points per distance computation (memory bound).
        k_cross_ratio: fraction of k allocated to cross-level parents. Default 0.5.
        k_l0_fraction: fraction of cross budget guaranteed from L_0 skeleton.
                       Default 0.5. Increase (e.g. 0.67) for longer-range kernels.
        causal_window_mult: window size for same-level causal KNN, expressed as a
                            multiple of k. Window = max(k_same * causal_window_mult,
                            chunk_size). Z_j is Hilbert-sorted within each level so
                            true predecessors are spatially local; the default of 16
                            is effectively exact for well-sorted inputs.

    Returns:
        order:  (M,) permutation mapping final position -> original Z row index.
        nn_idx: (M-k, k) parent indices in final-order space.
                Satisfies nn_idx[i, j] < i + k for all i, j (causal invariant).
    """
    M = Z.shape[0]
    level_sizes = assign_level_sizes(M, n_levels, k)
    n_levels = len(level_sizes)

    global_order = hilbert_sort_indices(Z, nbits=nbits)

    S = M // k
    skeleton_ranks = torch.arange(k, dtype=torch.long, device=Z.device) * S

    is_skeleton = torch.zeros(M, dtype=torch.bool, device=Z.device)
    is_skeleton[skeleton_ranks] = True
    non_skeleton_ranks = (~is_skeleton).nonzero(as_tuple=False).flatten()

    level_rank_lists = [skeleton_ranks]
    offset = 0
    for j in range(1, n_levels):
        sz = level_sizes[j]
        level_rank_lists.append(non_skeleton_ranks[offset: offset + sz])
        offset += sz

    all_ranks = torch.cat(level_rank_lists)
    order = global_order[all_ranks]
    Z_sorted = Z[order]

    level_ends = list(accumulate(level_sizes))
    level_starts = [0] + level_ends[:-1]

    nn_idx = torch.zeros(M - k, k, dtype=torch.long, device=Z.device)
    k_cross_base = max(1, round(k * k_cross_ratio))

    # L_0 skeleton is invariant across levels; build its KDTree once.
    tree_l0 = _build_kdtree(Z_sorted[:k])

    for j in range(1, n_levels):
        start_j = level_starts[j]
        end_j = level_ends[j]
        n_j = level_sizes[j]
        n_intermediate = start_j - k

        Z_j = Z_sorted[start_j:end_j]

        if n_intermediate > 0:
            k_l0_budget = max(1, min(round(k_cross_base * k_l0_fraction), k))
            k_interm_budget = min(k_cross_base - k_l0_budget, n_intermediate)
        else:
            k_l0_budget = min(k_cross_base, k)
            k_interm_budget = 0

        actual_cross = k_l0_budget + k_interm_budget
        k_same = max(0, k - actual_cross)
        k_same_max = k_same
        s_threshold = min(k_same, n_j)

        tree_interm = (
            _build_kdtree(Z_sorted[k:start_j]) if k_interm_budget > 0 else None
        )

        # Stream slab-by-slab: query the trees and same-level causal KNN for
        # each slab, then write straight into nn_idx. Peak transient per slab
        # is O(chunk_size × k) rather than O(n_j × k).
        for s_start in range(0, n_j, chunk_size):
            s_end = min(s_start + chunk_size, n_j)
            c = s_end - s_start
            Z_slab = Z_j[s_start:s_end]

            l0_nn_slab = _kdtree_query(tree_l0, Z_slab, k)  # (c, k)
            if tree_interm is not None:
                interm_nn_slab = _kdtree_query(tree_interm, Z_slab, k_interm_budget) + k
            else:
                interm_nn_slab = None
            same_nn_slab = _causal_knn_slab(
                Z_j, s_start, s_end, k_same_max, chunk_size, causal_window_mult
            )

            # Scalar assembly for early points where s < s_threshold. Only
            # touches the first slab and runs at most k iterations total.
            local_scalar_end = min(max(0, s_threshold - s_start), c)
            for local_s in range(local_scalar_end):
                s = s_start + local_s
                nn_idx[start_j + s - k] = _assemble_parents(
                    s=s,
                    k=k,
                    k_l0_budget=k_l0_budget,
                    k_interm_budget=k_interm_budget,
                    n_l0=k,
                    l0_nn_s=l0_nn_slab[local_s],
                    interm_nn_s=interm_nn_slab[local_s] if interm_nn_slab is not None else None,
                    same_nn_s=same_nn_slab[local_s],
                    start_j=start_j,
                )

            # Vectorized assembly for the remaining rows of the slab, which
            # all have full same-level budget and no shortfall.
            if local_scalar_end < c:
                sl = slice(local_scalar_end, c)
                parts = [l0_nn_slab[sl, :k_l0_budget]]
                if k_interm_budget > 0:
                    parts.append(interm_nn_slab[sl, :k_interm_budget])
                if k_same > 0:
                    parts.append(same_nn_slab[sl, :k_same] + start_j)
                row_start = start_j + s_start + local_scalar_end - k
                row_end = start_j + s_end - k
                nn_idx[row_start:row_end] = torch.cat(parts, dim=1)

            del l0_nn_slab, same_nn_slab
            if interm_nn_slab is not None:
                del interm_nn_slab

        if tree_interm is not None:
            del tree_interm

    del tree_l0

    return order, nn_idx
