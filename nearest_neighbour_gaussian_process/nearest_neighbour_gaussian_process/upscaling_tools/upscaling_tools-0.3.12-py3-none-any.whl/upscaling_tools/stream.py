from typing import List

class StreamList(List):
    # Extend the python list with a write_list method to use as placeholder for
    # quaisr output stream.
    def write_list(self, value):
        self.append(value)

class StreamTime:
    def write_time(self, value):
        pass
