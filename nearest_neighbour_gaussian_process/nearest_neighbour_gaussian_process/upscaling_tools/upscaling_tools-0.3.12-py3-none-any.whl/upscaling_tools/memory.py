"""Batch sizes derived from free device memory."""

import torch

# Points per posterior batch, clamped to this range whatever the memory says.
BATCH_FLOOR = 1024
BATCH_CEILING = 1 << 17
# Used when there is no cheap free-memory query, i.e. on CPU.
BATCH_CPU_DEFAULT = 8192


def nngp_posterior_batch_size(k: int, dtype_bytes: int = 4) -> int:
    """Points per posterior batch for the NNGP evaluation path.

    The path holds a handful of ``(batch, k, k)`` tensors live at once -- the
    neighbour covariance, its Cholesky factor and the solve workspace -- so peak
    memory is ``O(batch * k^2)`` and the ceiling comes from ``k`` rather than
    from the number of points. Budget a quarter of free device memory across
    roughly eight such buffers.
    """
    if not torch.cuda.is_available():
        return BATCH_CPU_DEFAULT
    free, _ = torch.cuda.mem_get_info()
    per_point = 8 * k * k * dtype_bytes
    batch = int((free // 4) // max(per_point, 1))
    return max(BATCH_FLOOR, min(batch, BATCH_CEILING))
