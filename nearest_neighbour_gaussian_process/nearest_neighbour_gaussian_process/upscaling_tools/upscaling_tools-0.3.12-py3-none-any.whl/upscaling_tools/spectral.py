"""Measure the wavelengths in a scattered field, and score a kernel against them.

The auto kernel in the NNGP block sets its lengthscale and outputscale bounds
from the survey outline and from hardcoded constants. These functions measure
the correlation function of the data itself, so a ladder and a variance budget
can be derived from it and a trained kernel can be scored against it.

Everything works in the units of the points passed in. The NNGP block scales its
inputs before building the kernel, so pass the scaled inputs to compare against a
trained kernel.
"""

import logging
from typing import NamedTuple

import numpy as np
import scipy.optimize
import scipy.spatial
import torch

log = logging.getLogger(__name__)

# Bins holding fewer pairs than this are dropped: the bin mean is the estimator,
# and the shortest log-spaced bins hold very few pairs.
MIN_BIN_PAIRS = 30


class CorrelationCurve(NamedTuple):
    """A binned correlation function.

    lags and rho hold one entry per retained bin. variance is the variance of
    the detrended values, the quantity rho is normalised by.
    """
    lags: np.ndarray
    rho: np.ndarray
    counts: np.ndarray
    variance: float


class Ladder(NamedTuple):
    """A scale ladder and variance budget fitted to a CorrelationCurve.

    unrepresentable is the variance fraction the fit could not place, because
    the shortest component is floored at the resolvable scale.
    """
    lengthscales: np.ndarray
    variances: np.ndarray
    nus: tuple
    unrepresentable: float
    misfit: float


def detrend(points: np.ndarray, values: np.ndarray) -> np.ndarray:
    """Remove a linear trend in the coordinates by least squares.

    The NNGP model carries a LinearMean, so the kernel only ever sees this
    residual. The residual's correlation is the target, not the raw field's.
    """
    design = np.column_stack([np.ones(len(points)), points])
    coefficients, *_ = np.linalg.lstsq(design, values, rcond=None)
    return values - design @ coefficients


def empirical_correlation(
    points: np.ndarray,
    values: np.ndarray,
    min_lag: float,
    max_lag: float,
    n_pairs: int = 1_000_000,
    n_bins: int = 40,
    seed: int = 0,
    min_bin_pairs: int = MIN_BIN_PAIRS,
) -> CorrelationCurve:
    """Correlation against lag, from binned products over point pairs.

    The bins are log spaced. A multiscale kernel spans two decades of lag, and
    linear bins put almost every bin in the longest decade.

    The pairs are drawn per bin, not uniformly over the point set. Uniformly
    drawn pairs land at short lags at a rate of (lag / domain)^2, so the
    shortest decade -- where most of a field's variance sits -- would be
    estimated from a handful of pairs. Each bin instead gets its own budget:
    take a random point, step a random direction and a random distance inside
    the bin, and pair it with the nearest point to where that lands. Selection
    uses geometry alone, so the per-bin mean stays unbiased.

    rho is not forced to 1 at zero lag. The shortfall at the shortest bin is the
    variance below that lag plus measurement noise, and it is a result worth
    reading rather than an artefact to normalise away.

    2D only: the random step is drawn as an angle and a radius.
    """
    points = np.ascontiguousarray(points, dtype=np.float64)
    values = np.ascontiguousarray(values, dtype=np.float64).ravel()
    if points.shape[1] != 2:
        raise ValueError(f"expected 2D points, got {points.shape[1]} columns")
    residual = detrend(points, values)
    variance = float(residual.var())
    if variance <= 0:
        raise ValueError("detrended values have zero variance")

    rng = np.random.default_rng(seed)
    tree = scipy.spatial.cKDTree(points)
    edges = np.geomspace(min_lag, max_lag, n_bins + 1)
    per_bin = max(n_pairs // n_bins, 1)

    lags, rho, counts = [], [], []
    for low, high in zip(edges[:-1], edges[1:]):
        left = rng.integers(0, len(points), per_bin)
        # Uniform in area across the annulus, not in radius: a bin spans a wide
        # ratio of radii, and uniform radius would crowd its inner edge.
        radius = np.sqrt(rng.uniform(low ** 2, high ** 2, per_bin))
        angle = rng.uniform(0.0, 2.0 * np.pi, per_bin)
        targets = points[left] + np.column_stack(
            [radius * np.cos(angle), radius * np.sin(angle)])

        _, right = tree.query(targets, workers=-1)
        lag = np.linalg.norm(points[left] - points[right], axis=1)
        # The nearest point to the target can sit outside the bin, and does
        # wherever the coverage has a gap. Bin on the realised lag.
        keep = (right != left) & (lag >= low) & (lag < high)
        if keep.sum() < min_bin_pairs:
            continue

        lag = lag[keep]
        product = residual[left[keep]] * residual[right[keep]]
        lags.append(lag.mean())
        rho.append(product.mean() / variance)
        counts.append(int(keep.sum()))

    if len(lags) < 3:
        raise ValueError(
            f"only {len(lags)} lag bins hold at least {min_bin_pairs} pairs; "
            f"raise n_pairs or narrow [{min_lag:g}, {max_lag:g}]")

    return CorrelationCurve(
        lags=np.asarray(lags),
        rho=np.asarray(rho),
        counts=np.asarray(counts),
        variance=variance,
    )


def correlation_range(lags: np.ndarray, rho: np.ndarray, threshold: float) -> float:
    """Lag at which rho first falls below threshold, interpolated in log lag.

    Returns NaN if rho stays at or above threshold over the whole range.
    """
    below = np.nonzero(rho < threshold)[0]
    if len(below) == 0:
        return float("nan")
    index = below[0]
    if index == 0:
        return float(lags[0])
    high, low = rho[index - 1], rho[index]
    fraction = (high - threshold) / (high - low)
    log_lags = np.log(lags)
    return float(np.exp(log_lags[index - 1] + fraction * (log_lags[index] - log_lags[index - 1])))


def matern_correlation(lags: np.ndarray, lengthscale: float, nu: float) -> np.ndarray:
    """Matern correlation, in gpytorch's parameterisation."""
    scaled = np.asarray(lags, dtype=np.float64) / lengthscale
    if nu == 0.5:
        return np.exp(-scaled)
    if nu == 1.5:
        root = np.sqrt(3.0) * scaled
        return (1.0 + root) * np.exp(-root)
    if nu == 2.5:
        root = np.sqrt(5.0) * scaled
        return (1.0 + root + 5.0 / 3.0 * scaled ** 2) * np.exp(-root)
    raise ValueError(f"nu must be 0.5, 1.5 or 2.5, not {nu}")


def additive_correlation(lags, lengthscales, variances, nus) -> np.ndarray:
    """Correlation of a sum of Matern components, unnormalised.

    The components are not rescaled to sum to 1. The shortfall below 1 at zero
    lag is the variance the components do not carry.
    """
    return sum(
        variance * matern_correlation(lags, lengthscale, nu)
        for lengthscale, variance, nu in zip(lengthscales, variances, nus)
    )


def kernel_correlation(kernel, lags) -> np.ndarray:
    """Normalised correlation of a fitted gpytorch kernel against lag.

    Evaluates the kernel rather than rebuilding its closed form, so any set of
    components works. The auto kernel is isotropic, so one axis is enough.
    """
    parameter = next(kernel.parameters())
    lags = torch.as_tensor(np.asarray(lags), dtype=parameter.dtype, device=parameter.device)

    origin = torch.zeros(1, 2, dtype=parameter.dtype, device=parameter.device)
    offsets = torch.zeros(len(lags), 2, dtype=parameter.dtype, device=parameter.device)
    offsets[:, 0] = lags

    # Imported here, not at module scope: gpytorch is an optional extra, and
    # every other function in this module needs only numpy.
    import gpytorch

    with torch.no_grad(), gpytorch.settings.lazily_evaluate_kernels(False):
        at_zero = kernel(origin, origin).to_dense()
        at_lag = kernel(origin, offsets).to_dense()
    return (at_lag / at_zero).reshape(-1).cpu().numpy()


def spectral_misfit(lags, rho_data, rho_model) -> float:
    """Mean absolute correlation difference, integrated in log lag.

    Integrating in log lag stops the longest decade, which holds most of the
    lag range and almost none of the variance, from setting the score.
    """
    log_lags = np.log(np.asarray(lags, dtype=np.float64))
    difference = np.abs(np.asarray(rho_data) - np.asarray(rho_model))
    return float(np.trapezoid(difference, log_lags) / (log_lags[-1] - log_lags[0]))


def fit_ladder(
    curve: CorrelationCurve,
    min_lengthscale: float,
    max_lengthscale: float,
    nus: tuple = (2.5, 1.5, 1.5),
    initial_lengthscales=None,
) -> Ladder:
    """Fit an additive Matern correlation to a measured curve.

    Returns the lengthscales and the variance each component carries, so both
    the scale ladder and the outputscale budget come from one fit.

    min_lengthscale floors every component at the resolvable scale. The variance
    the data holds below it cannot be placed, and comes back as
    unrepresentable.
    """
    n = len(nus)
    if initial_lengthscales is None:
        initial_lengthscales = np.geomspace(min_lengthscale, max_lengthscale / 4, n)[::-1]
    initial = np.concatenate([
        np.log(np.clip(initial_lengthscales, min_lengthscale, max_lengthscale)),
        np.full(n, max(curve.rho[0], 1e-3) / n),
    ])
    lower = np.concatenate([np.full(n, np.log(min_lengthscale)), np.zeros(n)])
    upper = np.concatenate([np.full(n, np.log(max_lengthscale)), np.full(n, 1.5)])

    def residual(parameters):
        lengthscales = np.exp(parameters[:n])
        variances = parameters[n:]
        return additive_correlation(curve.lags, lengthscales, variances, nus) - curve.rho

    solution = scipy.optimize.least_squares(
        residual, initial, bounds=(lower, upper), x_scale="jac")

    lengthscales = np.exp(solution.x[:n])
    variances = solution.x[n:]
    order = np.argsort(lengthscales)[::-1]

    fitted = additive_correlation(curve.lags, lengthscales, variances, nus)
    return Ladder(
        lengthscales=lengthscales[order],
        variances=variances[order],
        nus=tuple(np.asarray(nus)[order]),
        unrepresentable=float(np.clip(1.0 - variances.sum(), 0.0, 1.0)),
        misfit=spectral_misfit(curve.lags, curve.rho, fitted),
    )


class LadderUncertainty(NamedTuple):
    """How tightly the data pins a fitted ladder.

    lengthscale_log_sd holds one standard deviation per component, in log
    lengthscale, so a band is a multiplicative factor: exp(k * sd).

    There is no per-component variance entry. Matern components at adjacent
    lengthscales are close to collinear, so replicates shuffle variance between
    them while reproducing the same total curve. Only total_variance is
    identified.
    """
    lengthscale_log_sd: np.ndarray
    total_variance: float
    total_variance_log_sd: float
    n_replicates: int


def bootstrap_ladder(
    points: np.ndarray,
    values: np.ndarray,
    min_lengthscale: float,
    max_lengthscale: float,
    min_lag: float,
    max_lag: float,
    n_blocks: int = 8,
    n_replicates: int = 40,
    seed: int = 0,
    nus: tuple = (2.5, 1.5, 1.5),
    **curve_kwargs,
) -> LadderUncertainty:
    """Spread of a fitted ladder under a spatial block bootstrap.

    Splits the domain into n_blocks x n_blocks tiles and resamples tiles with
    replacement, so whole neighbourhoods drop in and out. That measures how far
    the ladder depends on which part of the survey was seen, which is the
    uncertainty a bound has to leave room for. Resampling individual points
    would only measure pair-draw noise, which is 2-3x smaller.

    A block bootstrap breaks correlation longer than one block, so the longest
    component's spread comes back wide. Read it as an upper estimate.

    Components are matched across replicates by rank, since fit_ladder returns
    them longest first.
    """
    points = np.ascontiguousarray(points, dtype=np.float64)
    values = np.ascontiguousarray(values, dtype=np.float64).ravel()
    rng = np.random.default_rng(seed)

    def tile(column, count):
        spread = np.ptp(column)
        scaled = (column - column.min()) / (spread if spread > 0 else 1.0)
        return np.clip((scaled * count).astype(int), 0, count - 1)

    block = tile(points[:, 0], n_blocks) * n_blocks + tile(points[:, 1], n_blocks)
    members = [index for index in
               (np.nonzero(block == b)[0] for b in range(n_blocks ** 2))
               if len(index) > 50]
    if len(members) < 4:
        raise ValueError(
            f"only {len(members)} of {n_blocks ** 2} blocks hold enough points; "
            "lower n_blocks")

    lengthscales, totals = [], []
    for replicate in range(n_replicates):
        picked = rng.integers(0, len(members), len(members))
        index = np.concatenate([members[p] for p in picked])
        try:
            curve = empirical_correlation(
                points[index], values[index], min_lag=min_lag, max_lag=max_lag,
                seed=replicate, **curve_kwargs)
            ladder = fit_ladder(curve, min_lengthscale, max_lengthscale, nus=nus)
        except ValueError:
            # A resample can leave a bin too thin to estimate. Drop the
            # replicate rather than let one thin draw decide a bound.
            continue
        lengthscales.append(ladder.lengthscales)
        totals.append(float(ladder.variances.sum()))

    if len(lengthscales) < max(5, n_replicates // 4):
        raise ValueError(
            f"only {len(lengthscales)} of {n_replicates} bootstrap replicates "
            "produced a fit; widen the lag range or raise n_pairs")

    lengthscales = np.asarray(lengthscales)
    totals = np.asarray(totals)
    positive = totals[totals > 0]
    return LadderUncertainty(
        lengthscale_log_sd=np.std(np.log(lengthscales), axis=0),
        total_variance=float(np.median(totals)),
        total_variance_log_sd=float(np.std(np.log(positive))) if len(positive) > 2 else 0.0,
        n_replicates=len(lengthscales),
    )
