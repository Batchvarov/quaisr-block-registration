import os

import numpy as np
import rioxarray
import rasterio
import xarray as xr
from upscaling_tools.utils import grid_data

INT16_NODATA = -32768

# Tile size and the smallest overview side kept. 256 is the COG convention and
# lets a viewer decode one tile instead of a whole strip.
GEOTIFF_TILE_SIZE = 256
MIN_OVERVIEW_SIDE = 256
# Bin count of the histogram behind the p1/p99 tags. Matches the viewer's.
STATS_HIST_BINS = 1024


def _quantize_int16(dsout, gridnames):
    """Quantize float bands to int16 with a shared scale/offset.

    Maps [vmin, vmax] across all gridnames linearly onto [-32767, 32767];
    -32768 is reserved as nodata for NaN pixels. Halves file/decoded size vs
    float32. Reconstruct in the viewer as: value = pixel * scale + offset.
    Returns (int16 dataset, scale, offset).
    """
    vmin = min(float(dsout[n].min(skipna=True)) for n in gridnames)
    vmax = max(float(dsout[n].max(skipna=True)) for n in gridnames)
    if not (np.isfinite(vmin) and np.isfinite(vmax)) or vmax <= vmin:
        # All-NaN or constant band: avoid divide-by-zero, identity-ish mapping.
        scale = 1.0
        offset = vmin if np.isfinite(vmin) else 0.0
    else:
        scale = (vmax - vmin) / 65534.0
        offset = vmin + 32767.0 * scale

    ds16 = dsout.copy()
    for n in gridnames:
        da = dsout[n]
        q = ((da - offset) / scale).round().clip(-32767, 32767)
        q = q.where(da.notnull(), INT16_NODATA)
        # write_nodata is a DataArray-level accessor (not available on the
        # Dataset accessor), so set nodata per band here.
        ds16[n] = q.astype(np.int16).rio.write_nodata(INT16_NODATA)
    return ds16, scale, offset


def _global_stats(dsout, gridnames):
    """Min, max and approximate p1/p99 over every band, in display units.

    The viewer needs these to set its colour range. Without them it decodes
    every band twice in the browser. Two passes with a histogram, one band at a
    time, so no pass holds more than one band.
    """
    vmin, vmax, count = np.inf, -np.inf, 0
    for name in gridnames:
        finite = dsout[name].values
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            continue
        vmin = min(vmin, float(finite.min()))
        vmax = max(vmax, float(finite.max()))
        count += int(finite.size)

    if count == 0 or not (np.isfinite(vmin) and np.isfinite(vmax)):
        return None
    if vmax <= vmin:
        return {"min": vmin, "max": vmax, "p1": vmin, "p99": vmax}

    hist = np.zeros(STATS_HIST_BINS, dtype=np.int64)
    for name in gridnames:
        finite = dsout[name].values
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            continue
        hist += np.histogram(finite, bins=STATS_HIST_BINS, range=(vmin, vmax))[0]

    cumulative = np.cumsum(hist)
    centres = vmin + (np.arange(STATS_HIST_BINS) + 0.5) * (vmax - vmin) / STATS_HIST_BINS

    def percentile(fraction):
        index = int(np.searchsorted(cumulative, fraction * (count - 1), side="right"))
        return float(centres[min(index, STATS_HIST_BINS - 1)])

    return {"min": vmin, "max": vmax, "p1": percentile(0.01), "p99": percentile(0.99)}


def _build_overviews(path, compression_kwagrs):
    """Add power-of-two overviews, so a viewer decodes a small image.

    GDAL reads the overview compression from config options, not from the
    dataset, so the main raster's compression is passed through here.
    """
    with rasterio.open(path) as src:
        side = min(src.width, src.height)

    factors = []
    factor = 2
    while side // factor >= MIN_OVERVIEW_SIDE:
        factors.append(factor)
        factor *= 2
    if not factors:
        return

    env = {}
    compress = compression_kwagrs.get("compress")
    if compress:
        env["COMPRESS_OVERVIEW"] = str(compress).upper()
    predictor = compression_kwagrs.get("predictor")
    if predictor is not None:
        env["PREDICTOR_OVERVIEW"] = str(predictor)

    with rasterio.Env(**env), rasterio.open(path, "r+") as dst:
        dst.build_overviews(factors, rasterio.enums.Resampling.average)


def _reproject_bands(dsout, xname, yname, gridnames, crs, shape, resampling):
    """Reproject a multi-band dataset one band at a time.

    rio.reproject on the whole Dataset warps every band into GDAL's working
    buffers simultaneously; with cubic_spline over large grids and many bands
    that OOMs. Warping band-by-band caps the transient warp memory to a single
    band while producing an identical result.
    """
    dsout = dsout.rio.write_crs(crs, inplace=True)
    reprojected = {}
    for name in gridnames:
        # Extracting dsout[name] yields a fresh DataArray with its own
        # rioxarray accessor, which re-runs x/y auto-detection and fails on
        # non-standard dim names. Re-assert the spatial dims per band.
        band = dsout[name].rio.set_spatial_dims(x_dim=xname, y_dim=yname)
        band = band.rio.reproject(
            dsout.rio.crs,
            shape=shape,
            resampling=resampling,
        )
        reprojected[name] = band
    return xr.Dataset(reprojected)


def _write_point_csv(dsout, xname, yname, path, target_cells=1_000_000):
    """Write the long-format point CSV without materialising the whole grid.

    dsout.to_dataframe() (one row per pixel, one column per band) OOMs on large
    grids / many-band clusters. Chunk the grid along y and let dask stream the
    CSV partition-by-partition (single_file collates to one file); peak RAM is
    one partition. Columns are [y, x, *bands].

    Size reductions vs the naive dump: no index column, %.4g float format, and
    all-NaN pixel rows (outside the masked extent) dropped.
    """
    nx = dsout.sizes[xname]
    block_y = max(1, target_cells // max(1, nx))
    ddf = dsout.chunk({yname: block_y}).to_dask_dataframe(dim_order=[yname, xname])
    band_cols = [c for c in ddf.columns if c not in (xname, yname)]
    if band_cols:
        ddf = ddf.dropna(how="all", subset=band_cols)
    ddf.to_csv(path, single_file=True, index=False, float_format="%.4g")


def reproject_grid(ds, xname, yname, gridnames, crs, upscale_factor=1, resampling=None):
    """Reproject/resample gridnames to an (upscale_factor)x grid, band-by-band.

    Split out so callers that write both an ERS export and a geotiff of the same
    data reproject once and hand the result to write_ers/write_geotiff, instead
    of warping the grid twice. Returned dims are (yname, xname).
    """
    if resampling is None:
        resampling = rasterio.enums.Resampling.cubic_spline

    dsout = ds[gridnames]
    dsout = dsout.transpose(yname, xname)
    dsout = dsout.rio.set_spatial_dims(x_dim=xname, y_dim=yname, inplace=True)

    new_width = dsout.rio.width * upscale_factor
    new_height = dsout.rio.height * upscale_factor

    dsout = _reproject_bands(
        dsout, xname, yname, gridnames, crs,
        shape=(new_height, new_width),
        resampling=resampling)

    return dsout.rename({"x": xname, "y": yname})


def _maybe_write_csv(dsout, xname, yname, savepath, csv_path):
    # csv_path=False skips the CSV; None falls back to <savepath>/point_data.csv.
    if csv_path is False:
        return
    csv_target = csv_path if csv_path is not None else f"{savepath}/point_data.csv"
    os.makedirs(os.path.dirname(csv_target), exist_ok=True)
    _write_point_csv(dsout, xname, yname, csv_target)


def write_ers(dsout, xname, yname, savepath, gridnames, csv_path=None):
    """Write an already-reprojected grid (see reproject_grid) as ERS bands."""
    # savepath itself, not savepath/grids: the bands are written directly into
    # savepath below, so the old form left an empty grids/ behind on every call.
    os.makedirs(savepath, exist_ok=True)
    _maybe_write_csv(dsout, xname, yname, savepath, csv_path)
    for name in gridnames:
        dsout[name].rio.to_raster(f"{savepath}/{name}.ers")
    return dsout, f"{savepath}"


def write_geotiff(dsout, xname, yname, savepath, gridnames, fname=None, csv_path=None, quantize_int16=False, **compression_kwagrs):
    """Write an already-reprojected grid (see reproject_grid) as a geotiff.

    quantize_int16=True stores bands as int16 with a shared scale/offset (and
    -32768 nodata) written to GDAL metadata tags — halves what the browser
    decodes. Recover floats as: value = pixel * scale + offset.
    """
    if fname is None:
        fname = "raster.tiff"
    # See write_ers: the raster lands in savepath, so create that, not a
    # grids/ subdirectory that nothing ever writes to.
    os.makedirs(savepath, exist_ok=True)
    # CSV is written from the original float grid, before any quantization.
    _maybe_write_csv(dsout, xname, yname, savepath, csv_path)

    tags = {}
    out = dsout[gridnames]
    if quantize_int16:
        crs = dsout.rio.crs
        ds16, scale, offset = _quantize_int16(dsout, gridnames)
        out = ds16[gridnames].rio.write_crs(crs)
        tags = {"scale": scale, "offset": offset, "nodata": INT16_NODATA,
                "value_formula": "value = pixel * scale + offset"}

    # Stats come from the float grid, so they are in display units whether or
    # not the bands are quantized.
    stats = _global_stats(dsout, gridnames)
    if stats is not None:
        tags.update({f"global_{key}": value for key, value in stats.items()})

    path = f"{savepath}/{fname}"
    # Merge, do not splat: a caller that passes tiled/blockxsize/blockysize in
    # compression_kwagrs would otherwise give to_raster two values for the same
    # keyword and raise TypeError.
    raster_kwargs = {
        "tiled": True,
        "blockxsize": GEOTIFF_TILE_SIZE,
        "blockysize": GEOTIFF_TILE_SIZE,
    }
    raster_kwargs.update(compression_kwagrs)
    out.rio.to_raster(path, tags=tags or None, **raster_kwargs)
    _build_overviews(path, compression_kwagrs)
    return dsout, f"{savepath}"


def save_as_ers_raster(ds, xname, yname, savepath, gridnames, crs, upscale_factor=1, csv_path=None):
    dsout = reproject_grid(ds, xname, yname, gridnames, crs, upscale_factor)
    return write_ers(dsout, xname, yname, savepath, gridnames, csv_path=csv_path)


def save_as_geotiff_raster(ds, xname, yname, savepath, gridnames, crs, upscale_factor=1, fname=None, csv_path=None, **compression_kwagrs):
    dsout = reproject_grid(ds, xname, yname, gridnames, crs, upscale_factor)
    return write_geotiff(dsout, xname, yname, savepath, gridnames, fname=fname, csv_path=csv_path, **compression_kwagrs)
