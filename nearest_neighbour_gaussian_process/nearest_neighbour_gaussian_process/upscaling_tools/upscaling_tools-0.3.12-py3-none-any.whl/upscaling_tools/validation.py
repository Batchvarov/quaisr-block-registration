import numpy as np
import scipy
import scipy.stats
import sklearn

import upscaling_tools.plotting
from upscaling_tools.calibration import (
    cross_fitted_error_rate,
    fit_predictive_nugget,
)


def lower_higher_ci(df, meankey, variancekey, nstd=1.96):
    df["ci_lower"] = df[meankey] - nstd*np.sqrt(df[variancekey])
    df["ci_upper"] = df[meankey] + nstd*np.sqrt(df[variancekey])
    return df

def compute_error_rate(df, meankey, variancekey, measuredkey, nstd=1.96):
    # Compute the error rate
    df = lower_higher_ci(df, meankey, variancekey)
    measured = df[measuredkey]
    lmax =  (measured < df["ci_upper"])
    gmin =  (measured > df["ci_lower"])

    df["within_error_bound"] = lmax * gmin 
    df["within_error_bound"] = df["within_error_bound"].astype(int)

    error_rate = 1 - sum(df["within_error_bound"]) / len(df["within_error_bound"])

    return error_rate

def deutsch_indicator(dist, u, p):
    z = dist.ppf([(1 - p)/2, (1 + p)/2])
    return 1 if z[0] < u < z[1] else 0

def deutsch_coverage(dists, us, p):
    ind = [deutsch_indicator(dist, u, p) for dist, u in zip(dists, us)]
    return np.mean(ind)

def a(dists, us, p):
    coverage = deutsch_coverage(dists, us, p) 
    if coverage > p:
        return 1
    else:
        return 0

def compute_deutsch_accuracy(gp_infer, df_test, dname):
    normals = [scipy.stats.norm(loc=row["GP_mean"], scale=row["GP_std"]) for _, row in gp_infer.iterrows()]
    accuracy = scipy.integrate.quad(lambda x: a(normals, df_test[dname], x), 0, 1.0)[0]
    print(f"Accuracy = {accuracy}")
    return accuracy

def compute_deutsch_precision(gp_infer, df_test, dname):
    normals = [
        scipy.stats.norm(loc=row["GP_mean"], scale=row["GP_std"]) for _, row in gp_infer.iterrows()]

    precision = 1.0 - scipy.integrate.quad(lambda x: 
        a(normals, df_test[dname], x) * (deutsch_coverage(normals, df_test[dname], x) - x), 0, 1.0)[0]

    print(f"Precision = {precision}")
    return precision

def compute_deutsch_coverages(gp_infer, measured, ps):
    """Deutsch (1997) coverage at each probability in `ps`.

    Vectorised: one frozen normal over the whole column and two array `ppf`
    calls. The previous form rebuilt one scipy.stats.norm per row via
    iterrows() on every call, then called .ppf() a point at a time -- at the
    block's 100k-point validation cap and 20 probabilities that was 2M frozen
    distributions through 20 full iterrows() passes.

    Accepts a scalar `p` or an array of them, and returns a scalar or an array
    to match.
    """
    scalar = np.ndim(ps) == 0
    ps = np.atleast_1d(np.asarray(ps, dtype=float))[:, None]
    dist = scipy.stats.norm(
        loc=np.asarray(gp_infer["GP_mean"], dtype=float),
        scale=np.asarray(gp_infer["GP_std"], dtype=float))
    measured = np.asarray(measured, dtype=float)
    lower = dist.ppf((1 - ps) / 2)
    upper = dist.ppf((1 + ps) / 2)
    coverages = ((lower < measured) & (measured < upper)).mean(axis=1)
    return float(coverages[0]) if scalar else coverages


def compute_deutsch_goodness(gp_infer, df_test, dname):
    normals = [
        scipy.stats.norm(loc=row["GP_mean"], scale=row["GP_std"]) for _, row in gp_infer.iterrows()]

    goodness = 1.0 - scipy.integrate.quad(lambda x: (3*a(normals, df_test[dname], x) - 2) * (deutsch_coverage(normals, df_test[dname], x) - x), 0, 1.0)[0]

    print(f"Goodness = {goodness}")
    return goodness

def compute_interp_perf(gp_infer, measured, predicted):
    linear_regression = sklearn.linear_model.LinearRegression().fit(
        np.asarray(gp_infer[measured]).reshape(-1, 1), 
        np.asarray(gp_infer[predicted]).reshape(-1, 1)
    )

    return {
        "rmse" : sklearn.metrics.root_mean_squared_error(gp_infer[measured], gp_infer[predicted]),
        "r2" : sklearn.metrics.r2_score(gp_infer[measured], gp_infer[predicted]),
        "rho" : float(linear_regression.coef_[0][0])
    }

def nngp_validation(trained_model, test_X, test_y, savepath="results/", output_scaler=None,
                    batch_size=8192, calibrate=False, calibration_out=None,
                    plots=True):
    """Metrics and plots for one point set.

    `calibration_out`, when a dict is passed, receives the points, residuals and
    variances this run measured. Fitting a nugget FIELD needs the positions, and
    the metrics dict goes straight onto a Quaisr wire that holds floats only, so
    the arrays leave through here instead.

    `plots=False` returns the metrics alone and writes no files. The figures cost
    far more than the metrics do, so a caller that only reads numbers -- a
    post-training health check, say -- turns them off.
    """
    # TODO: Deutsch accuracy, precision, goodness.

    # Error rate. batch_size is passed explicitly: leaving it at the model's
    # default meant up to 100k validation points went through in tiny batches,
    # which is thousands of round trips for no memory benefit.
    gp_infer = trained_model.inference(
        test_X.to(dtype=trained_model.train_inputs.dtype, device=trained_model.train_inputs.device).contiguous(),
        output_scaler=output_scaler,
        batch_size=batch_size)

    if hasattr(test_y, "detach"):
        test_y = test_y.detach().cpu().numpy()

    gp_infer["measured"] = test_y
    error_rate = compute_error_rate(gp_infer, "GP_mean", "GP_variance", "measured")

    validation_dict = compute_interp_perf(gp_infer, "measured", "GP_mean")
    validation_dict["error_rate"] = error_rate

    if calibrate:
        # Held-out points give the honest nugget. Callers may also ask for one on
        # training points, as a fallback when the test set is too small to fit
        # anything on; the model fits those better, so that nugget runs small.
        residual = gp_infer["measured"].values - gp_infer["GP_mean"].values
        variance = gp_infer["GP_variance"].values
        validation_dict["predictive_nugget"] = fit_predictive_nugget(
            residual, variance)
        validation_dict["error_rate_calibrated"] = cross_fitted_error_rate(
            residual, variance)
        if calibration_out is not None:
            calibration_out.update(
                points=np.asarray(test_X.detach().cpu() if hasattr(test_X, "detach")
                                  else test_X, dtype=float),
                residual=residual, variance=variance)

    if not plots:
        return validation_dict, {}

    # TODO Plots: Deutsch coverage v ci
    ps = np.linspace(0, 1, num=20)
    cv = compute_deutsch_coverages(gp_infer, test_y, ps)
    fig_coverage_ci = upscaling_tools.plotting.plot_coverage_ci(ps, cv)

    # Return the dictionary of saved html plot locations.
    fig_parity = upscaling_tools.plotting.plot_parity(gp_infer, "measured", "GP_mean")
    fig_error = upscaling_tools.plotting.plot_error_distribution(gp_infer, "measured", "GP_mean")

    validation_plots = {
        "parity plot" : upscaling_tools.plotting.save_plot(fig_parity, savepath, "parity"),
        "error distribution" : upscaling_tools.plotting.save_plot(fig_error, savepath, "error_distribution"),
#        "coverage against ci" : upscaling_tools.plotting.save_plot(fig_coverage_ci, savepath, "coverage_ci"),
    }

#    if test_X.shape[1] == 2:
#        fig_cov = upscaling_tools.plotting.plot_3d_coverage(gp_infer, 'x_0', 'x_1', "ci_upper", "ci_lower", 'measured', "within_error_bound")
#        validation_plots["3d coverage"] = upscaling_tools.plotting.save_plot(fig_cov, savepath, "coverage") 

    return validation_dict, validation_plots
