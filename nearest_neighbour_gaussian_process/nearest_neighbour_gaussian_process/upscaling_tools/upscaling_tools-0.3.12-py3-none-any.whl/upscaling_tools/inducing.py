import typing

import numpy as np
import torch
import verde as vd
import scipy
import scipy.spatial
import sklearn
import sklearn.cluster

import upscaling_tools.utils

class InducingPointsAllocation:
    #: True when initialise() returns the training points themselves, in the
    #: same order. Training reads this to decide whether the inducing index and
    #: the data index are the same index -- never infer it from a count, since
    #: an allocator can return exactly len(X) points that are not the data.
    returns_data_points = False

class DatapointsAsInducing(InducingPointsAllocation):
    def __init__(self, nsample=None) -> None:
        self.nsample = nsample

    @property
    def returns_data_points(self) -> bool:
        # A random subsample is not the data in order.
        return self.nsample is None

    def initialise(self, X) -> typing.Any:
        if self.nsample is not None:
            indices = torch.randperm(len(X)) 
            return X[indices[:self.nsample]]
        else:
            return X

class GridInducing(InducingPointsAllocation):
    def __init__(self, shape) -> None:
        self.shape = shape

    def initialise(self, X) -> typing.Any:
        region = vd.get_region((X[:, 0].tolist(), X[:, 1].tolist()))
        mesh = vd.grid_coordinates(region=region, shape=self.shape, meshgrid=True, adjust="region")
        ds = vd.make_xarray_grid(mesh, data=None, data_names=None)
        ds_ = ds.stack(points=ds.dims)
        return torch.tensor(ds_.indexes["points"].values.tolist())

class KMeansInducing(InducingPointsAllocation):
    def __init__(self, ninducing) -> None:
        self.ninducing = ninducing

    def initialise(self, X) -> typing.Any:
        inducing = scipy.cluster.vq.kmeans2(X, self.ninducing)[0]
        return torch.tensor(inducing)

class GridCountInducing(InducingPointsAllocation):
    """Regular grid of ~ninducing inducing points, masked to the data coverage.

    Takes a single target count instead of a (nx, ny) shape: it derives a
    near-square grid whose cell aspect matches the data's spatial extent, so
    cells stay roughly square in space (valid because the upstream
    GlobalMinMaxScaler applies one global scale and preserves aspect). Grid
    cells with no data within ~one cell spacing are dropped (cKDTree nearest
    query) so no inducing points land in empty regions -- unlike a convex hull
    this follows concave boundaries and interior holes. The surviving count is
    therefore <= ninducing (the honest number of cells actually over data).
    O(N log N) -- no clustering -- so it scales to millions of points where
    k-means stalls. Falls back to every data point when ninducing >= N.
    """
    def __init__(self, ninducing) -> None:
        self.ninducing = ninducing
        self._delegated = False

    @property
    def returns_data_points(self) -> bool:
        # Only the ninducing >= n fallback returns the data; the masked grid
        # never does, even when its surviving count happens to equal n.
        return self._delegated

    def initialise(self, X) -> torch.Tensor:
        n = len(X)
        if self.ninducing >= n:
            self._delegated = True
            return DatapointsAsInducing().initialise(X)
        self._delegated = False
        Xt = X if isinstance(X, torch.Tensor) else torch.as_tensor(X)
        width = max(float(Xt[:, 0].max() - Xt[:, 0].min()), 1e-12)
        height = max(float(Xt[:, 1].max() - Xt[:, 1].min()), 1e-12)
        n_north = max(1, round((self.ninducing * height / width) ** 0.5))
        n_east = max(1, round(self.ninducing / n_north))
        grid = GridInducing(shape=(n_north, n_east)).initialise(X)

        # Drop grid cells with no data within one cell diagonal so no inducing
        # points land in empty regions (handles concave edges and holes).
        threshold = ((width / n_east) ** 2 + (height / n_north) ** 2) ** 0.5
        tree = scipy.spatial.cKDTree(Xt[:, :2].detach().cpu().numpy())
        dist, _ = tree.query(grid[:, :2].detach().cpu().numpy(), k=1, workers=-1)
        return grid[torch.as_tensor(dist <= threshold)]


class MiniBatchKMeansInducing(InducingPointsAllocation):
    """Inducing points as mini-batch k-means centroids.

    Mini-batch k-means scales to millions of points, where the full-batch
    scipy.cluster.vq.kmeans2 used by KMeansInducing stalls. Falls back to using
    every data point as an inducing point when ninducing >= number of data
    points (delegates to DatapointsAsInducing).
    """
    def __init__(self, ninducing, batch_size: int = 10000) -> None:
        self.ninducing = ninducing
        self.batch_size = batch_size
        self._delegated = False

    @property
    def returns_data_points(self) -> bool:
        # Only the ninducing >= n fallback returns the data; centroids never do.
        return self._delegated

    def initialise(self, X) -> torch.Tensor:
        n = len(X)
        if self.ninducing >= n:
            self._delegated = True
            return DatapointsAsInducing().initialise(X)
        self._delegated = False
        X_np = X.detach().cpu().numpy() if isinstance(X, torch.Tensor) else np.asarray(X)
        km = sklearn.cluster.MiniBatchKMeans(
            n_clusters=self.ninducing,
            batch_size=self.batch_size,
            n_init=3,
            random_state=0,
        )
        km.fit(X_np.astype("float32"))
        return torch.as_tensor(km.cluster_centers_, dtype=torch.float32)


class StratifiedClusterSampleInducing(InducingPointsAllocation):
    # Perform K-Means clustering of the samples and provide a stratified sample random sample based on the proportion of points in each cluster.
    def __init__(self, nsamples, nclusters) -> None:
        self.nsamples = nsamples
        self.nclusters = nclusters

    def initialise(self, X) -> torch.Tensor:
        clusters = scipy.cluster.vq.kmeans2(X, self.nclusters)[1]
        inducing, _ = sklearn.model_selection.train_test_split(X, test_size=self.nsamples, stratify=clusters)
        return torch.tensor(inducing)


class HilbertSortedInducing(InducingPointsAllocation):
    """Wraps any allocator and sorts inducing points by Hilbert curve order.

    Hilbert ordering ensures each point's k nearest earlier neighbours are
    its spatial neighbours, making the NNGP Cholesky preconditioner effective
    and reducing PCG iterations from 50+ to 2-5.
    """
    def __init__(self, base: InducingPointsAllocation, nbits: int = 20) -> None:
        self.base = base
        self.nbits = nbits

    @property
    def returns_data_points(self) -> bool:
        # Always False, even over DatapointsAsInducing: the result is a
        # permutation of the base output, so it is no longer the data *in
        # order*, and the inducing index no longer matches the data index.
        return False

    def initialise(self, X: torch.Tensor) -> torch.Tensor:
        from upscaling_tools.ordering import hilbert_sort_indices
        Z = self.base.initialise(X)
        return Z[hilbert_sort_indices(Z, nbits=self.nbits)]

