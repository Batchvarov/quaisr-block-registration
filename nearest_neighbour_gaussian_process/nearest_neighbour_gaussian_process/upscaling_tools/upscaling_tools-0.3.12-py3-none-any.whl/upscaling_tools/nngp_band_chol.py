from __future__ import annotations

import math
import torch
from torch import Tensor

from gpytorch.models import ApproximateGP
from gpytorch.distributions import MultivariateNormal
from gpytorch.variational._variational_distribution import _VariationalDistribution
from gpytorch.variational.nearest_neighbor_variational_strategy import NNVariationalStrategy
from gpytorch.variational.unwhitened_variational_strategy import UnwhitenedVariationalStrategy
from gpytorch.utils.nearest_neighbors import NNUtil
from gpytorch.utils.memoize import add_to_cache, pop_from_cache
from gpytorch.utils.errors import CachingError

from linear_operator.operators import DiagLinearOperator, DenseLinearOperator


class BandCholeskyVariationalDistribution(_VariationalDistribution):
    """
    Variational distribution q(u) = N(m, L̃L̃ᵀ) where L̃ is stored in band-sparse form.

    L̃ has nonzeros only at the same sparsity pattern as the NNGP prior precision:
    row i is nonzero only at col_indices[i] = sort(n(i) ∪ {i}).

    Parameters: O(MK) vs O(M²) for full Cholesky.
    col_indices is a buffer — populated by _init_col_indices() after NN computation.
    """

    def __init__(
        self,
        num_inducing_points: int,
        k: int,
        batch_shape: torch.Size = torch.Size([]),
        mean_init_std: float = 1e-3,
    ):
        super().__init__(
            num_inducing_points=num_inducing_points,
            batch_shape=batch_shape,
            mean_init_std=mean_init_std,
        )
        self.k = k
        M = num_inducing_points

        mean_init = torch.zeros(*batch_shape, M)
        # L_band[i, j] = L̃[i, col_indices[i, j]]
        # Initialised to identity-like (diagonal=1e-2) after _init_col_indices
        L_band_init = torch.zeros(*batch_shape, M, k + 1)

        self.register_parameter("variational_mean", torch.nn.Parameter(mean_init))
        self.register_parameter("L_band", torch.nn.Parameter(L_band_init))
        # col_indices populated by _init_col_indices; placeholder until then
        self.register_buffer("col_indices", torch.zeros(M, k + 1, dtype=torch.long))
        self._col_indices_initialised = False

    def _init_col_indices(self, nn_xinduce_idx: Tensor) -> None:
        """
        Build col_indices from the NNGP neighbour structure and initialise L_band.

        nn_xinduce_idx: (M-k, k) — from NNVariationalStrategy.nn_xinduce_idx.
        For i < k: only self (diagonal-only band, no predecessors).
        For i >= k: sort(nn_xinduce_idx[i-k] ∪ {i}).
        Diagonal entry L̃[i,i] is always stored at col_indices[i, -1] (last slot).
        """
        M = self.col_indices.shape[0]
        k = self.k
        device = nn_xinduce_idx.device
        col_indices = torch.zeros(M, k + 1, dtype=torch.long, device=device)

        # First k rows: no predecessors → col_indices[i] = [i, i, ..., i]
        for i in range(k):
            col_indices[i] = i

        # Rows k..M-1: sorted neighbors ∪ self
        for i in range(k, M):
            neighbors = nn_xinduce_idx[i - k]        # (k,)
            all_cols = torch.cat([neighbors, torch.tensor([i], device=device)])
            col_indices[i] = all_cols.sort().values   # (k+1,) sorted, self at end

        self.col_indices.copy_(col_indices)

        # Initialise L_band: off-diagonal=0, diagonal raw ≈ -4.6 so softplus(raw) ≈ 1e-2
        _raw_diag_init = float(torch.tensor(1e-2).expm1().log().item())  # inv_softplus(1e-2)
        with torch.no_grad():
            self.L_band.data.zero_()
            self.L_band.data[..., -1].fill_(_raw_diag_init)

        self._col_indices_initialised = True

    def _effective_L_band_rows(self, row_indices: Tensor) -> Tensor:
        """
        Return L̃ rows for row_indices with softplus-constrained diagonal.
        Off-diagonal entries are unconstrained. Shape: (n, K+1).
        """
        import torch.nn.functional as F
        rows = self.L_band[row_indices]                                # (n, K+1)
        diag_constrained = F.softplus(rows[..., -1]).unsqueeze(-1)    # (n, 1)
        return torch.cat([rows[..., :-1], diag_constrained], dim=-1)  # (n, K+1)

    @property
    def L_diag(self) -> Tensor:
        """Positive-constrained diagonal L̃[i,i] via softplus. Shape: (*bs, M)."""
        import torch.nn.functional as F
        return F.softplus(self.L_band[..., -1])

    @property
    def S_diag(self) -> Tensor:
        """Diagonal of L̃L̃ᵀ = ||L̃[i,:]||² per row (with constrained diagonal). Shape: (*bs, M). O(MK)."""
        off_diag_sq = (self.L_band[..., :-1] ** 2).sum(-1)
        return off_diag_sq + self.L_diag ** 2

    def S_submatrix(self, row_indices: Tensor) -> Tensor:
        """
        Compute S[row_indices, :][:, row_indices] = (L̃[rows,:]) @ (L̃[rows,:])ᵀ
        without materialising the full M×M matrix.

        Uses 'local scatter': scatter band nonzeros into a compact (n, n_unique_cols)
        dense matrix, then matmul. O(n·K) memory, O(n²·K) compute.

        row_indices: (n,) int64
        Returns: (n, n)
        """
        n = row_indices.shape[0]
        K1 = self.L_band.shape[-1]   # K+1

        band_rows = self._effective_L_band_rows(row_indices)  # (n, K+1), diagonal softplus-constrained
        col_rows  = self.col_indices[row_indices]              # (n, K+1)

        all_cols_flat = col_rows.reshape(-1)                               # (n*(K+1),)
        _, inverse = all_cols_flat.unique(return_inverse=True)             # (n*(K+1),)
        n_u = int(inverse.max().item()) + 1

        L_local = band_rows.new_zeros(n, n_u)
        row_idx = torch.arange(n, device=band_rows.device).unsqueeze(1).expand(n, K1)
        L_local[row_idx.reshape(-1), inverse] = band_rows.reshape(-1)

        return L_local @ L_local.T   # (n, n)

    def forward(self) -> MultivariateNormal:
        return MultivariateNormal(
            self.variational_mean,
            DiagLinearOperator(self.S_diag),
        )

    def initialize_variational_distribution(self, prior_dist: MultivariateNormal) -> None:
        self.variational_mean.data.copy_(prior_dist.mean)
        self.variational_mean.data.add_(
            torch.randn_like(prior_dist.mean), alpha=self.mean_init_std
        )
        # L_band is initialised in _init_col_indices; nothing to do here


class NNBandCholeskyVariationalStrategy(NNVariationalStrategy):
    """
    NNVariationalStrategy with BandCholeskyVariationalDistribution.

    Replaces the mean-field diagonal variational covariance with a band-sparse
    lower-triangular L̃, matching the NNGP prior precision sparsity pattern.

    KL changes (Appendix B of Wu et al. 2022):
    - logdet_q  : 2 * Σ log(L̃_ii)  instead of  Σ log(s_i²)
    - trace_term: uses S_diag = ||L̃[i,:]||²  instead of  s_i²
    - invquad_term: unchanged
    - eval forward: k×k covariance via S_submatrix instead of diagonal
    """

    def __init__(
        self,
        model: ApproximateGP,
        inducing_points: Tensor,
        variational_distribution: BandCholeskyVariationalDistribution,
        k: int,
        training_batch_size: int | None = None,
        jitter_val: float = 1e-3,
        compute_full_kl: bool = False,
    ):
        assert isinstance(variational_distribution, BandCholeskyVariationalDistribution)

        # Bypass NNVariationalStrategy.__init__ (mean-field assertion) by calling grandparent
        UnwhitenedVariationalStrategy.__init__(
            self, model, inducing_points, variational_distribution,
            learn_inducing_locations=False, jitter_val=jitter_val,
        )

        # Replicate NNVariationalStrategy.__init__ body (minus the mean-field assertion)
        object.__setattr__(self, "model", model)
        self.inducing_points = inducing_points
        self.M, self.D = inducing_points.shape[-2:]
        self.k = k
        assert self.k < self.M

        self._inducing_batch_shape = inducing_points.shape[:-2]
        self._model_batch_shape = variational_distribution.variational_mean.shape[:-1]
        self._batch_shape = torch.broadcast_shapes(
            self._inducing_batch_shape, self._model_batch_shape
        )

        self.nn_util = NNUtil(
            k, dim=self.D,
            batch_shape=self._inducing_batch_shape,
            device=inducing_points.device,
        )
        self._compute_nn()

        # nn_xinduce_idx now exists — complete the band distribution setup
        variational_distribution._init_col_indices(self.nn_xinduce_idx)

        self.training_batch_size = training_batch_size if training_batch_size is not None else self.M
        self._set_training_iterator()
        self.compute_full_kl = compute_full_kl

    def __call__(self, x, prior=False, **kwargs):
        if prior:
            return self.model.forward(x, **kwargs)

        if x is not None:
            if not (self.inducing_points.shape[:-2] == x.shape[:-2]):
                try:
                    x = x.expand(*self.inducing_points.shape[:-2], *x.shape[-2:]).contiguous()
                except RuntimeError:
                    raise RuntimeError(
                        f"x batch shape must match or broadcast with inducing points' batch shape, "
                        f"but got x={x.shape[:-2]}, inducing={self.inducing_points.shape[:-2]}."
                    )

        if self.training:
            self._clear_cache()

            if not self.variational_params_initialized.item():
                prior_dist = self.prior_distribution
                vd = self._variational_distribution
                vd.variational_mean.data.copy_(prior_dist.mean)
                vd.variational_mean.data.add_(
                    torch.randn_like(prior_dist.mean), alpha=vd.mean_init_std
                )
                # Init L_diag near sqrt(noise) so the ELL gradient stays O(1)
                # throughout training. Starting at 0.01 with noise=1e-8 gives
                # initial gradient ~1e4, which poisons Adam's second-moment
                # estimator and stalls convergence after a few steps.
                try:
                    noise = float(self.model.likelihood.noise.item())
                    l_diag_init = max(noise ** 0.5, 1e-8)
                except AttributeError:
                    l_diag_init = 1e-2
                _raw_diag = math.log(math.expm1(l_diag_init))
                with torch.no_grad():
                    vd.L_band.data.zero_()
                    vd.L_band.data[..., -1].fill_(_raw_diag)
                self.variational_params_initialized.fill_(1)

            return self.forward(
                x, self.inducing_points, inducing_values=None, variational_inducing_covar=None, **kwargs
            )
        else:
            return self.forward(x, self.inducing_points, inducing_values=None, variational_inducing_covar=None, **kwargs)

    def forward(self, x, inducing_points, inducing_values, variational_inducing_covar=None, **kwargs):
        if self.training:
            # Training forward: identical to NNVariationalStrategy — use variational mean/var
            # directly. We use S_diag for the predictive variance (diagonal of posterior).
            vd = self._variational_distribution

            if x is None:
                x_indices = self._get_training_indices()
                kl_indices = x_indices
                predictive_mean = vd.variational_mean[..., x_indices]
                predictive_var  = vd.S_diag[..., x_indices]
            else:
                x_indices = self.nn_util.find_nn_idx(x.float(), k=1).squeeze(-1)
                expanded_x_indices = x_indices.expand(*self._batch_shape, x_indices.shape[-1])
                expanded_mean = vd.variational_mean.expand(*self._batch_shape, self.M)
                expanded_var  = vd.S_diag.expand(*self._batch_shape, self.M)
                predictive_mean = expanded_mean.gather(-1, expanded_x_indices)
                predictive_var  = expanded_var.gather(-1, expanded_x_indices)
                kl_indices = self._get_training_indices()

            kl = self._kl_divergence(kl_indices)
            add_to_cache(self, "kl_divergence_memo", kl)
            return MultivariateNormal(predictive_mean, DiagLinearOperator(predictive_var))

        else:
            # Eval forward: compute k×k posterior covariance via S_submatrix
            nn_indices = self.nn_util.find_nn_idx(x.float())

            x_batch_shape = x.shape[:-2]
            batch_shape   = torch.broadcast_shapes(self._batch_shape, x_batch_shape)
            x_bsz = x.shape[-2]

            vd = self._variational_distribution

            # Variational mean for k nearest neighbours (same as parent)
            inducing_values = vd.variational_mean
            expanded_inducing_values = inducing_values.unsqueeze(-1).expand(*batch_shape, self.M, self.k)
            expanded_nn_indices = nn_indices.expand(*batch_shape, x_bsz, self.k)
            inducing_values = expanded_inducing_values.gather(-2, expanded_nn_indices)

            # Band k×k covariance blocks — one per test point
            covar_blocks = []
            for i in range(x_bsz):
                nn_i = nn_indices[..., i, :].reshape(-1)   # (k,) flat
                S_sub = vd.S_submatrix(nn_i)               # (k, k)
                covar_blocks.append(S_sub)
            variational_inducing_covar = torch.stack(covar_blocks, dim=0)  # (x_bsz, k, k)
            variational_inducing_covar = variational_inducing_covar.expand(
                *batch_shape, x_bsz, self.k, self.k
            )

            # Select inducing point locations for k neighbours (same as parent)
            expanded_nn_idx_pts = nn_indices.unsqueeze(-1).expand(*x_batch_shape, x_bsz, self.k, self.D)
            expanded_inducing_pts = inducing_points.unsqueeze(-2).expand(*x_batch_shape, self.M, self.k, self.D)
            inducing_points_nn = expanded_inducing_pts.gather(-3, expanded_nn_idx_pts)

            # Permute to (x_bsz, *batch_shape, ...) for batched UnwhitenedVariationalStrategy.forward
            _batch_dims = tuple(range(len(batch_shape)))
            x_exp = x.unsqueeze(-2).expand(*batch_shape, x_bsz, 1, self.D)
            _x             = x_exp.permute((-3,) + _batch_dims + (-2, -1))
            inducing_points_nn = inducing_points_nn.expand(*batch_shape, x_bsz, self.k, self.D)
            _inducing_pts  = inducing_points_nn.permute((-3,) + _batch_dims + (-2, -1))
            _inducing_vals = inducing_values.permute((-2,) + _batch_dims + (-1,))
            _var_covar     = variational_inducing_covar.permute((-3,) + _batch_dims + (-2, -1))

            from linear_operator.operators import DenseLinearOperator as _Dense
            _var_covar_op = _Dense(_var_covar)

            dist = UnwhitenedVariationalStrategy.forward(
                self, _x, _inducing_pts, _inducing_vals, _var_covar_op, **kwargs
            )

            _x_batch_dims = tuple(range(1, 1 + len(batch_shape)))
            predictive_mean  = dist.mean.permute(_x_batch_dims + (0, -1)).squeeze(-1)
            predictive_covar = dist.covariance_matrix.permute(_x_batch_dims + (0, -2, -1))
            predictive_var   = predictive_covar.squeeze(-2).squeeze(-1)

            return MultivariateNormal(predictive_mean, DiagLinearOperator(predictive_var))

    def _firstk_kl_helper(self):
        train_x_firstk = self.inducing_points[..., :self.k, :]
        full_output = self.model.forward(train_x_firstk)
        induc_mean, induc_covar = full_output.mean, full_output.lazy_covariance_matrix
        prior_dist = MultivariateNormal(induc_mean, induc_covar.add_jitter(self.jitter_val))

        vd = self._variational_distribution
        inducing_values = vd.variational_mean[..., :self.k]
        covar_firstk = vd.S_submatrix(
            torch.arange(self.k, device=self.inducing_points.device)
        )   # (k, k)
        variational_inducing_covar = DenseLinearOperator(covar_firstk)
        variational_dist = MultivariateNormal(inducing_values, variational_inducing_covar)
        return torch.distributions.kl.kl_divergence(variational_dist, prior_dist)

    def _stochastic_kl_helper(self, kl_indices):
        kl_bs = len(kl_indices)
        vd = self._variational_distribution
        variational_mean = vd.variational_mean          # (*model_bs, M)
        S_diag = vd.S_diag                              # (*model_bs, M)
        L_diag = vd.L_diag                              # (*model_bs, M)

        # (1) logdet_q = 2 * Σ log(L̃_ii)  [Appendix B, Eq 40]
        logdet_q = 2.0 * torch.sum(torch.log(L_diag[..., kl_indices]), dim=-1)

        # (2) logdet_p — identical to parent: uses NNGP conditional variances F
        inducing_points = self.inducing_points[..., kl_indices, :].expand(*self._batch_shape, kl_bs, self.D)
        nearest_neighbor_indices = self.nn_xinduce_idx[..., kl_indices - self.k, :].to(inducing_points.device)
        expanded_inducing_points_all = self.inducing_points.unsqueeze(-2).expand(
            *self._batch_shape, self.M, self.k, self.D
        )
        expanded_nearest_neighbor_indices = nearest_neighbor_indices.unsqueeze(-1).expand(
            *self._batch_shape, kl_bs, self.k, self.D
        )
        nearest_neighbors = expanded_inducing_points_all.gather(-3, expanded_nearest_neighbor_indices)

        nearest_neighbors_ = nearest_neighbors.permute((-3,) + tuple(range(len(self._batch_shape))) + (-2, -1))
        inducing_points_   = inducing_points.permute((-2,) + tuple(range(len(self._batch_shape))) + (-1,))
        full_output = self.model.forward(
            torch.cat([nearest_neighbors_, inducing_points_.unsqueeze(-2)], dim=-2)
        )
        full_mean, full_covar = full_output.mean, full_output.covariance_matrix

        _undo_permute_dims = tuple(range(1, 1 + len(self._batch_shape))) + (0, -1)
        nearest_neighbors_prior_mean = full_mean[..., :self.k].permute(_undo_permute_dims)
        inducing_prior_mean          = full_mean[..., self.k:].permute(_undo_permute_dims).squeeze(-1)
        nearest_neighbors_prior_cov  = full_covar[..., :self.k, :self.k]
        nn_induc_cross_cov           = full_covar[..., :self.k, self.k:]
        inducing_prior_cov           = full_covar[..., self.k:, self.k:]
        inducing_prior_cov           = (
            inducing_prior_cov.squeeze(-1).squeeze(-1)
            .permute((-1,) + tuple(range(len(self._batch_shape))))
        )

        interp_term = torch.linalg.solve(
            nearest_neighbors_prior_cov + self.jitter_val * torch.eye(self.k, device=self.inducing_points.device),
            nn_induc_cross_cov,
        ).squeeze(-1).permute(_undo_permute_dims)

        nn_induc_cross_cov_perm = nn_induc_cross_cov.squeeze(-1).permute(_undo_permute_dims)
        invquad_for_F = torch.sum(interp_term * nn_induc_cross_cov_perm, dim=-1)

        inducing_prior_cov_diag = self.model.covar_module.forward(
            inducing_points, inducing_points, diag=True
        )
        F = inducing_prior_cov_diag - invquad_for_F + self.jitter_val
        logdet_p = F.log().sum(dim=-1)

        # (3) trace_term: replace s_k² with S_diag[k]  [Appendix B, Eq 40]
        expanded_S_diag = S_diag.unsqueeze(-1).expand(*self._batch_shape, self.M, self.k)
        expanded_nn_indices_flat = nearest_neighbor_indices.expand(*self._batch_shape, kl_bs, self.k)
        nearest_neighbor_variational_covar = expanded_S_diag.gather(-2, expanded_nn_indices_flat)
        bjsquared_s_nn = torch.sum(interp_term ** 2 * nearest_neighbor_variational_covar, dim=-1)
        inducing_point_variational_covar = S_diag[..., kl_indices]
        trace_term = (1.0 / F * (bjsquared_s_nn + inducing_point_variational_covar)).sum(dim=-1)

        # (4) invquad_term — unchanged, depends only on variational_mean
        expanded_variational_mean = variational_mean.unsqueeze(-1).expand(*self._batch_shape, self.M, self.k)
        nearest_neighbors_variational_mean = expanded_variational_mean.gather(-2, expanded_nn_indices_flat)
        Bj_m_nn = torch.sum(
            interp_term * (nearest_neighbors_variational_mean - nearest_neighbors_prior_mean), dim=-1
        )
        inducing_variational_mean = variational_mean[..., kl_indices]
        invquad_term = torch.sum(
            (inducing_variational_mean - inducing_prior_mean - Bj_m_nn) ** 2 / F, dim=-1
        )

        kl = (logdet_p - logdet_q - kl_bs + trace_term + invquad_term) * 0.5
        return kl

    def kl_divergence(self):
        try:
            return pop_from_cache(self, "kl_divergence_memo")
        except CachingError:
            raise RuntimeError("KL Divergence called before nearest neighbours were set.")
