import os

import pandas as pd
import xarray as xr
import numpy as np
import holoviews as hv
import panel as pn
import upscaling_tools.utils
#import upscaling_tools.hillshade

#from datashader.transfer_functions import stack, shade
from holoviews.operation import decimate

import sklearn

hv.extension('bokeh')
decimate.max_samples=1000
renderer = hv.renderer('bokeh')

#def plot_hillshade(dataset: xr.Dataset, dname: str):
#    hillshade = upscaling_tools.hillshade.hillshade(dataset[dname])
#    image = stack(
#        shade(dataset[dname]),
#        shade(hillshade, cmap = ["black", "white"], alpha=128)
#    )
#    return hv.Image(image)

def plot_image(dataset: xr.Dataset, xname: str, yname: str, dname: str, label="image"):
    hv_ds = hv.Dataset(dataset[dname])

    hv_image = hv_ds.to(hv.Image, kdims=[xname, yname], datatype=['xarray'], label=label)
    return hv_image

def plot_points(df, xname, yname, clim, cmap="jet"):
    return hv.Points(df, kdims=xname, label=yname).opts(color=yname, size=5, cmap=cmap, clim=tuple(clim), colorbar=True, alpha=0.9, clabel=yname, tools=['hover'], data_aspect=1, height=600, width=600)

def plot_images(dataset: xr.Dataset, xname: str, yname: str, data_names: list[str], cmap: str = "jet", clims=None, pts_data=None, pts_to_plot=None, contour=None):
    height = 600
    width = 900

    if clims is None:
        clims = [np.quantile(dataset[dname].data, [0.05, 0.95]) for dname in data_names]
    plots = {}
    for dname, clim, i in zip(data_names, clims, range(0, len(data_names))):
        layers = []
        hv_image = plot_image(dataset, xname, yname, dname, label=dname)
        hv_image.opts(
            clim=tuple(clim),
            cmap=cmap,
            colorbar=True,
            show_legend=True,
            backend='bokeh',
            tools=['hover'],
            xrotation=90,
            height=height,
            width=width,
            alpha=0.9,
            clabel=dname,
            data_aspect=1)
        layers.append(hv_image)

        if contour is not None:
            img = hv.Image(contour[dname], label="Data contour")
            cont = hv.operation.contours(img, levels=0)
            cont = cont.opts(
                height=height,
                width=width,
                data_aspect=1,
                line_width=1.5,
                backend='bokeh',
                show_legend=True,
                cmap="gray",
                clim=(0.4,0.6),
                tools=[],
            )

            layers.append(cont)
#        hv_shade = plot_hillshade(dataset, dname).opts(alpha=0.95, cmap="Greys")
#        hv_image = hv_shade * hv_image

        if pts_data is not None:
            hv_points = hv.Points(pts_data, kdims=[xname, yname], label="Data points").opts(
                color=pts_to_plot[i],
                size=1,
                cmap=cmap,
                clim=tuple(clim),
                colorbar=True,
                alpha=0.9,
                clabel=yname,
                tools=['hover'],
                data_aspect=1,
                height=height, width=width)

            hv_points = hv_points.opts(cmap=cmap, backend='bokeh', tools=['hover'], data_aspect=1, )
            layers.append(hv_points)
#            layers["Data points"] = hv_points

        plots[dname] = hv.Overlay(layers).opts(
            show_legend=True, legend_position="bottom_right", legend_opts={'click_policy': 'hide'})

    return hv.Layout(list(plots.values())).opts(tabs=True)

def plot_image_slider(dataset: xr.Dataset, xname: str, yname: str, data_names: list[str], plotname: str, slider_name: str ="samples", cmap: str = "jet", clim=None):
    if clim is None:
        vals = dataset[data_names[0]].data
        clim = np.quantile(vals, [0.05, 0.95])

    ds = upscaling_tools.utils.filters_to_xarray_dim(dataset, xname, yname, data_names, dimname=slider_name)

    hv_ds = hv.Dataset(ds)
    hv_image = hv_ds.to(hv.Image, kdims=[xname, yname], dynamic=False, datatype=['xarray']).opts(
        cmap=cmap,
        clim=tuple(clim),
        colorbar=True,
        backend='bokeh',
        tools=['hover'],
        xrotation=90,
        width=600,
        height=600,
        data_aspect=1)

    dmap_panel = pn.pane.HoloViews(hv_image, sizing_mode="scale_both", widget_location="bottom")
    return pn.panel(dmap_panel[0])

class LineData:
    def __init__(self, name, dataframe, xname, yname, yuppername=None, ylowername=None) -> None:
        self.name = name
        self.df = dataframe
        self.xname = xname
        self.yname = yname
        self.yuppername = yuppername
        self.ylowername = ylowername

def plot_lines(datasets: list[LineData], **kwargs):
    lines = []
    for data in datasets:
        line = hv.Curve(data.df, data.xname, (data.yname, data.yname), label=data.name)
        if (data.yuppername is not None) and (data.ylowername is not None):
            band = hv.Area(data.df, data.xname, vdims=[data.yuppername, data.ylowername], label=data.name) 
            hv.output(band.opts(backend='bokeh', tools=['hover'], alpha=0.2))
            lines.append(hv.Overlay([line, band], label=data.name))
        else:
            lines.append(line)
    overlay = hv.Overlay(lines)
    overlay.opts(legend_opts={"click_policy": "hide"}, xrotation=90, **kwargs)

    return pn.panel(overlay, width=700, height=500)

def plot_3d_coverage(dataframe: pd.DataFrame, xname: str, yname: str, upper: str, lower: str, measuredname: str, colorcat: str):
    hv.extension('plotly')
    surface_upper = hv.TriSurface(dataframe, kdims=[xname, yname, upper])
    surface_upper.opts(cmap='blues')
    surface_lower = hv.TriSurface(dataframe, kdims=[xname, yname, lower])
    surface_lower.opts(cmap='purples')
    scatter = hv.Scatter3D(dataframe, kdims=[xname, yname, measuredname])
    scatter.opts(color=colorcat, cmap=['red', 'blue'], size=2)
    return pn.panel(surface_upper * surface_lower * scatter, width=1200, height=800)

def plot_error_distribution(dataframe: pd.DataFrame, measuredname, predictedname, plotname="Error distribution"):
    hv.extension('bokeh')
    dataframe["absolute_error"] = dataframe[measuredname] - dataframe[predictedname]
    dataframe["relative_error"] = (dataframe[measuredname] - dataframe[predictedname]) / dataframe[measuredname]

    freq_abs, edges_abs = np.histogram(dataframe["absolute_error"], density=True, bins=20)
    freq_rel, edges_rel = np.histogram(dataframe["relative_error"], density=True, bins=20, range=(-2, 2))

    histograms = [
        hv.Histogram((edges_abs, freq_abs), label="Absolute errors").opts(xlabel="Error", ylabel="Density", height=700, width=500),
        hv.Histogram((edges_rel, freq_rel), label="Relative errors").opts(xlabel="Error", ylabel="Density", height=700, width=500)
    ]

    return pn.panel(
        hv.Layout(histograms).opts(tabs=True, shared_axes=False))

def plot_parity(dataframe: pd.DataFrame, measuredname, predictedname):
    """Parity scatter of measured against predicted.

    Both axes share one square range so the identity line sits at 45 degrees;
    a plot with independently auto-ranged axes makes a badly scaled model look
    like a good one. Non-finite pairs are dropped: a single NaN/inf collapses
    the Bokeh axis range and hides every real point.
    """
    finite = (
        np.isfinite(dataframe[measuredname].to_numpy(dtype=float))
        & np.isfinite(dataframe[predictedname].to_numpy(dtype=float))
    )
    dataframe = dataframe[finite]

    measured = dataframe[measuredname].to_numpy(dtype=float)
    predicted = dataframe[predictedname].to_numpy(dtype=float)

    lo = float(min(measured.min(), predicted.min()))
    hi = float(max(measured.max(), predicted.max()))
    pad = 0.05 * (hi - lo) if hi > lo else 1.0
    lims = (lo - pad, hi + pad)

    scatter = hv.Scatter(dataframe, kdims=[measuredname], vdims=[predictedname], label="parity").opts(
        height=700, width=700, alpha=0.4, size=3)

    xyline = hv.Curve(([lo, hi], [lo, hi]), label="measured = predicted").opts(color="red")

    # Linear regression.
    lreg = sklearn.linear_model.LinearRegression().fit(
        dataframe[[measuredname]], dataframe[predictedname])
    predy = lreg.predict(pd.DataFrame({measuredname: [lo, hi]})).flatten()
    regline = hv.Curve(([lo, hi], predy), label="linear regression line").opts(color="purple")

    overlay = hv.Overlay([scatter, xyline, regline])
    overlay.opts(title="Parity plot", xlim=lims, ylim=lims, data_aspect=1)

    return pn.panel(overlay)

def plot_coverage_ci(ps, cv):
    scatter = hv.Scatter(zip(ps, cv)).opts(height=700, width=700)
    line = hv.Curve([[0, 0], [1, 1]])
    overlay = scatter * line
    overlay.opts(title="Accuracy, Deutsch (1997)", xlabel="Width of CI around mean", ylabel="Coverage")
    return pn.panel(overlay)

def save_plot(fig, savepath, name):
    # os.path.join, not concatenation: callers pass a directory without a
    # trailing separator ("results/validation"), so the old form created an
    # empty results/validation/ and wrote results/validationparity.html
    # beside it -- and two savepaths sharing a prefix collided silently.
    os.makedirs(savepath, exist_ok=True)
    path = os.path.join(savepath, name + ".html")
    fig.save(path)
    return path
