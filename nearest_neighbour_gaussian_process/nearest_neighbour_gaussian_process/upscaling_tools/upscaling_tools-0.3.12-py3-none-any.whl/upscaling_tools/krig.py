import pykrige
import xarray as xr
import numpy as np

import upscaling_tools.utils as utils

def fit_kriging(df, mesh, xname, yname, dname, **kwargs):
    grid_points = utils.mesh_to_points(mesh) 
    xpts = grid_points[:,0]
    ypts = grid_points[:,0]

    xs = mesh[0][0,:]
    ys = mesh[1][:,0]

    krig = pykrige.uk.UniversalKriging(df[xname], df[yname], df[dname], **kwargs)
    z, ss = krig.execute("points", xpts, ypts)

    ds = xr.Dataset(
    {
        dname: ([xname, yname], np.reshape(z, (len(xs), len(ys)))),
        "variance": ([xname, yname], np.reshape(ss, (len(xs), len(ys)))),
    },
    coords={
        xname: ([xname], xs),
        yname: ([yname], ys),
    },
    )

    return ds

