import xrft
import numpy as np
import xarray as xr
import verde as vd
import harmonica as hm
import pandas as pd
import skimage as ski

import upscaling_tools.validation

def transform_dataset(dataset, xname, yname, dname, filterfunc, padn=5, mode='mean', **kwargs):
    grid = dataset[dname]
    pad_width = {
        xname: grid[xname].size // padn,
        yname: grid[yname].size // padn,
    }
    grid_padded = xrft.pad(grid, pad_width, mode=mode, constant_values=None)

    fgrid = filterfunc(grid_padded, **kwargs)
    return fgrid

def grid_data(df, spacing, xname, yname, dname, gridf=vd.Linear, **kwargs):
    gridder = hm.EquivalentSources(depth=1000, damping=1, block_size=500)
#    gridder = gridf()
    region = vd.get_region((df[xname], df[yname]))
    easting, northing, extra = vd.grid_coordinates(region, spacing=spacing, extra_coords=0)

    padx = (region[1] - region[0]) / easting.shape[0]
    pady = (region[3] - region[2]) / northing.shape[0]

    region = vd.pad_region(region, (2*padx, 2*pady))
    gridder = gridder.fit((df[xname], df[yname], np.zeros(len(df[yname]))), df[dname])

    easting, northing, extra = vd.grid_coordinates(region, spacing=spacing, extra_coords=0)

    # NN interpolation in the grid using the training datapoints
    ds = gridder.grid(
        (easting, northing, extra),
        dims=[yname, xname],
        data_names=dname,
    )

    ds = ds.drop_vars("upward")

    return ds

def apply_filter(dataset, xname, yname, dname, fname, filterfunc, new_coords=None, **kwargs):
    grid = dataset[dname]

    pad_width = {
        xname: grid[xname].size // 3,
        yname: grid[yname].size // 3,
    }
    grid_padded = xrft.pad(grid, pad_width, mode="mean", constant_values=None)

    fgrid = filterfunc(grid_padded, **kwargs)

    if new_coords is not None:
        # If the results should be stored in a new coordinate system.
        xname = new_coords+xname
        yname = new_coords+yname

        pad_width = {
            xname: grid[xname].size // 3,
            yname: grid[yname].size // 3,
        }

    unpadded_fgrid = xrft.unpad(fgrid, pad_width)
    dataset = dataset.assign({dname + "_" + fname: ((xname, yname), unpadded_fgrid.data)})
    return dataset

def apply_filters(dataset, xname, yname, dnames, fname, filterfunc, **kwargs):
    for dname in dnames:
        dataset = apply_filter(dataset, xname, yname, dname, fname, filterfunc=filterfunc, **kwargs)
    return dataset

def make_skeletons(dataset: xr.Dataset, xname: str, yname: str, dnames: list[str], **kwargs):
    for dname in dnames:
        image = dataset[dname].values.astype(float)
        std = image.std()
        if std > 0:
            image = (image - image.mean()) / std

    #    binary_image = ski.segmentation.morphological_chan_vese(image, num_iter=30)
        skeleton = ski.feature.canny(image, sigma=5, use_quantiles=True, low_threshold=0.2, high_threshold=0.7)
    #    dataset = dataset.assign({dname + "_binary": ((xname, yname), binary_image)})
        dataset = dataset.assign({dname + "_skeleton": (dataset[dname].dims, skeleton)})

    return dataset

def iso_spectral_density(ds, dname, **kwargs):
    fftn = xrft.isotropic_power_spectrum(ds[dname], **kwargs)
    return fftn

def cross_spectrum(ds1, dname1, ds2, dname2, xname, yname):
    crs = xrft.cross_spectrum(ds1[dname1], ds2[dname2],
                              dim=[xname, yname],
                              detrend='linear',
                              window=True,
                              density=False)
    return crs

def filters_to_xarray_dim(dataset: xr.Dataset, xname: str, yname: str, filters: list[str], dimname: str = "band"):
    data =  [dataset[f].data for f in filters]
    m = np.mean(data, axis=0)
    data = [m] + data
    arr = np.stack(data)

    #names = [f"mean over {len(filters)} samples"] + [str(l) for l  in list(range(0, len(filters)))]
    names = [-1] + list(range(0, len(filters)))
    ds = xr.Dataset(
        data_vars={
            'results': ([dimname, xname, yname], arr),
        },
        coords={
            xname: (xname, dataset[xname].data),
            yname: (yname, dataset[yname].data),
            dimname: (dimname, names)
        },
    )
    return ds

def compute_isotropic_density(ds, snames, spectra_kwargs):
    iso_ref = iso_spectral_density(ds, snames[0], **spectra_kwargs)
    dict_iso = {"freq_r" : iso_ref["freq_r"]}

    for sname in snames:
        iso_sample = iso_spectral_density(ds, sname, **spectra_kwargs)
        dict_iso[sname] = iso_sample.sel({"freq_r" : iso_ref["freq_r"]})

    df_iso = pd.DataFrame(dict_iso)
    df_iso["mean"] = df_iso[snames].mean(axis = 1)
    df_iso["variance"] = df_iso[snames].var(axis = 1)
    df_iso = upscaling_tools.validation.lower_higher_ci(df_iso, "mean", "variance")

    return df_iso

def make_region_mesh(df, spacing, xname, yname):
    train_region = vd.get_region((df[xname], df[yname]))
    spacing = (spacing, spacing)
    mesh = vd.grid_coordinates(
        region=train_region, spacing=spacing, meshgrid=True, adjust="region")
    return vd.make_xarray_grid(mesh, data=np.zeros_like(mesh[0]), data_names="dummy", dims=[yname, xname])

def distance_mask(df, grid, dims, dname, filters_to_plot, maxdist):
    xname, yname = dims

    mask = vd.distance_mask(
        (df[xname], df[yname]),
        grid=grid,
        maxdist=maxdist
    )
    mask = mask.notnull()
    mask = mask.assign({
        dname: ((yname, xname), mask[flt].notnull().values) for flt in filters_to_plot
    })
    mask = mask.drop_vars("spatial_ref")
    return mask
