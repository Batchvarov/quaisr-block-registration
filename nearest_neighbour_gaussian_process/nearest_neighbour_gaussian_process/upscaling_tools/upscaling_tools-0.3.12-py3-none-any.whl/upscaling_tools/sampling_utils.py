import torch
import numpy as np
import xarray as xr
import re

def infer_grid(ds, model, dname: str | list[str], dim: list[str], feature_extractor=None, input_scaler=None, output_scaler=None, inference_batch_size=256):
    ds_ = ds.stack(points=dim)
    grid_points = np.array(ds_.indexes["points"].values.tolist())
    if feature_extractor is not None:
        grid_points = feature_extractor(torch.tensor(grid_points))
    if input_scaler is not None:
        grid_points = input_scaler.transform(torch.tensor(grid_points))

    df = model.inference(
        torch.tensor(grid_points).to(dtype=model.train_inputs.dtype, device=model.train_inputs.device).contiguous(),
        output_scaler=output_scaler,
        batch_size=inference_batch_size)

    if type(dname) is str:
        ds_ = ds_.assign({f'GP_mean_{dname}': (ds_.dims, df[f'GP_mean'])})
        ds_ = ds_.assign({f'GP_variance_{dname}': (ds_.dims, df[f'GP_variance'])})
        ds_ = ds_.assign({f'GP_std_{dname}': (ds_.dims, df[f'GP_std'])})
    if type(dname) is list:
        for i, dn in enumerate(dname):
            ds_ = ds_.assign({f'GP_mean_{dn}': (ds_.dims, df[f'GP_mean_task_{i}'])})
            ds_ = ds_.assign({f'GP_variance_{dn}': (ds_.dims, df[f'GP_variance_task_{i}'])})
            ds_ = ds_.assign({f'GP_std_{dn}': (ds_.dims, df[f'GP_std_task_{i}'])})

    return ds_.drop_duplicates('points').unstack()

def batch_infer_grid(xrbatches, model, dname: str, dim: list[str], feature_extractor=None, output_scaler=None, **kwargs):
    dss_results = []

    for ds in xrbatches:
        ds_infer = infer_grid(ds, model, dname, dim, feature_extractor=feature_extractor, output_scaler=output_scaler, **kwargs)
        dss_results.append(ds_infer)

    combined_stacked = xr.concat(
        dss_results,
        dim='batches',
        join='outer'
    )
    return combined_stacked.mean(dim="batches")

def batch_sample_grid_seq(xrbatches, model, dname: str, dim: list[str], feature_extractor=None, output_scaler=None, **kwargs):
    dss_results = []

    for i, ds in enumerate(xrbatches):
        print(f"Sampling batch {i} out of {len(xrbatches)}")
        ds_infer = sample_grid(ds, model, dname, dim, feature_extractor=feature_extractor, output_scaler=output_scaler, **kwargs)
        dss_results.append(ds_infer)

    combined_stacked = xr.concat(
        dss_results,
        dim='batches',
        join='outer'
    )
    return combined_stacked.mean(dim="batches")

def sample(model, df, xname: str, yname: str, dname: str | list[str], nsamples: str):
    gp_dfs =  model.sample_gp(model, df[[xname, yname]].values.tolist(), nsamples)

    for i, gp_df in enumerate(gp_dfs):
        fname = "GP_sample_" + str(i) + f"_{dname}"
        prior_name = "GP_psample_" + str(i) + f"_{dname}"
        fname_logp = "GP_sample_logp_" + str(i) + f"_{dname}"
        df[fname] = gp_df["value"]
        df[fname_logp] = gp_df["logprob"]
        df[prior_name] = gp_df["prior_value"]

    return df


def sample_grid(ds, model, dname:str | list[str], dim: list[str], nsamples: int = 1, feature_extractor=None, input_scaler=None, **kwargs):
    # Use the existing mesh from the dataset.
    ds_ = ds.stack(points=dim)
    grid_points = np.array(ds_.indexes["points"].values.tolist())

    if feature_extractor is not None:
        grid_points = feature_extractor(torch.tensor(grid_points))
    if input_scaler is not None:
        grid_points = input_scaler.transform(torch.tensor(grid_points))

    sample_df =  model.sample_gp(
        torch.tensor(grid_points).to(dtype=model.train_inputs.dtype, device=model.train_inputs.device),
        nsamples,
        **kwargs
    )

    if type(dname) is str:
        for col in sample_df:
            fname = "GP_" + col + f"_{dname}"
            ds_ = ds_.assign({fname: (ds_.dims, sample_df[col])})
    if type(dname) is list:
        for i, dn in enumerate(dname):
            df_task = sample_df.filter(regex = rf'task_{i}', axis=1)
            for col in df_task:
                fname = re.sub(rf"task_{i}", dn, col)
                ds_ = ds_.assign({fname: (ds_.dims, sample_df[col])})

    return ds_.unstack()


def batch_sample_grid(ds, model, dname:str, dim: list[str], nsamples: int = 1, feature_extractor=None, input_scaler=None, **kwargs):
    batches = ds
    dss_ = [ds.stack(points=dim) for ds in batches]

    grid_points = []
    for ds_ in dss_:
        points = np.array(ds_.indexes["points"].values.tolist())
        grid_points.append(torch.tensor(points))

    xinput = torch.stack(grid_points).to(dtype=model.train_inputs.dtype, device=model.train_inputs.device)
    sample_df =  model.sample_gp(model, xinput, nsamples)

    dss_new = []
    for col in sample_df:
        fname = "GP_" + col + f"_{dname}"
        samples = sample_df[col].values.reshape(xinput.shape[:-1])

        for (sample, ds_) in zip(samples, dss_):
            ds_ = ds_.assign({fname: (ds_.dims, sample)})
            ds_ = ds_.unstack()
            dss_new.append(ds_)

    combined_stacked = xr.concat(
        dss_new,
        dim='batches',
        join='outer'
    )
    return combined_stacked.mean(dim="batches")


def batch_sample_grid_overlap(ds, model, dname:str, dim: list[str], batch_shape: list[int], nsamples: int = 1, sample_prior: bool = False, feature_extractor=None):
    # Get batch overlaps.
    # Sample overlaps.
    # Pass them in as new data prior to sampling.

    batches = ds
    dss_ = [ds.stack(points=dim) for ds in batches]
    dims = list(batches[0].dims)

    grid_points = []
    boundary_points = []

    for ds_ in dss_:
        points = np.array(ds_.indexes["points"].values.tolist())
        grid_points.append(torch.tensor(points))
        batch_mask = np.zeros(len(points), dtype=bool)

        for i, dim in enumerate(dims):
            dim_coords = points[:, i]
            batch_mask |= (dim_coords == dim_coords.min()) | (dim_coords == dim_coords.max())
        boundary_points.append(torch.tensor(points[batch_mask]))

    xinput_boundary = torch.stack(boundary_points)
    sample_df_boundary =  model.sample_gp(model, xinput_boundary, nsamples)
    return sample_df_boundary

def infer_and_sample(model, ds, dims, dname, input_scaler, output_scaler, nsamples=10, inference_batch_size=256, **kwargs):
    stacked = ds.stack(points=dims)

    points = np.column_stack([stacked[d].values for d in dims])
    transformed_points = input_scaler.transform(points)

    transform_names = [f"{d}_transform" for d in dims]
    coords_update = {
        name: ("points", transformed_points[:, i])
        for i, name in enumerate(transform_names)
    }
    stacked = stacked.assign_coords(coords_update)

    unstacked = stacked.unstack('points')

    grid_coords = {}
    for i, d in enumerate(dims):
        # To get the 1D slice, we index 0 on all other dimensions
        selectors = {other_d: 0 for other_d in dims if other_d != d}
        grid_coords[d] = (d, unstacked[transform_names[i]].isel(selectors).values)

    ds_grid = xr.Dataset(data_vars={}, coords=grid_coords)

    ds_infer = infer_grid(ds_grid, model, dim=dims, dname=dname, output_scaler=output_scaler, inference_batch_size=inference_batch_size)
    ds_infer = sample_grid(ds_infer, model, dname, dim=dims, nsamples=nsamples, output_scaler=output_scaler, batch_size=inference_batch_size, **kwargs)

    original_coords = {d: (d, ds[d].values) for d in dims}
    ds_infer = ds_infer.assign_coords(original_coords)

    return ds_infer
