from __future__ import annotations

import logging
from dataclasses import dataclass
from types import NoneType
from typing import Any
import torch
from torch import Size, Tensor

from gpytorch.models import ApproximateGP
from gpytorch.variational.nearest_neighbor_variational_strategy import (
    NNVariationalStrategy
)
from gpytorch.kernels.keops import MaternKernel as KeOpsMaternKernel
from gpytorch.kernels.keops import RBFKernel as KeOpsRBFKernel

from botorch.sampling.pathwise.features.generators import (
    GenKernelFeatureMap,
    _gen_kernel_feature_map_matern,
    _gen_kernel_feature_map_rbf,
)

GenKernelFeatureMap.register(KeOpsMaternKernel)(_gen_kernel_feature_map_matern)
GenKernelFeatureMap.register(KeOpsRBFKernel)(_gen_kernel_feature_map_rbf)

from botorch.sampling.pathwise.paths import GeneralizedLinearPath
from botorch.utils.transforms import is_ensemble
from botorch.models.transforms.input import InputTransform

from botorch.sampling.pathwise.features.maps import KernelEvaluationMap
from botorch.sampling.pathwise.prior_samplers import (
    TPathwisePriorSampler,
    draw_kernel_feature_paths,
)
from botorch.sampling.pathwise.posterior_samplers import (
    DrawMatheronPaths,
    MatheronPath,
)
from botorch.sampling.pathwise.update_strategies import (
    GaussianUpdate,
    TPathwiseUpdate,
    gaussian_update,
)

import linear_operator
from linear_operator.operators import (
    LinearOperator,
    ZeroLinearOperator,
)
from linear_operator.utils.linear_cg import linear_cg

import gpytorch

from upscaling_tools.kernels import (
    chunked_kernel_matmul,
    clamp_keops_chunk,
    keops_chunk_count,
    split_modulated,
)
from upscaling_tools.nngp import NNGPModel
from upscaling_tools.nngp_lin_op import NNGPCholeskyLinearOperator
from upscaling_tools.nngp_fft_prior import (
    DEFAULT_FFT_PEAK_BUDGET_BYTES,
    FFTSpectrum,
    GridFFTPriorSampler,
    GridSpec,
    build_fft_spectrum,
)

log = logging.getLogger(__name__)


@dataclass
class _UpdateOpts:
    kzz_jitter: float | None
    nngp_kernel: torch.nn.Module
    cg_tolerance: float | None
    max_cg_iter: int | None
    update_chunk_size: int
    matmul_chunk_size: int


def _kernel_param_fingerprint(module: torch.nn.Module) -> tuple:
    params = [p.data.sum() for p in module.parameters()]
    if not params:
        return ()
    return tuple(torch.stack(params).tolist())


def _auto_jitters(
    kernels: list[torch.nn.Module], Z: Tensor, factor: float = 1e-3
) -> list[float]:
    """Batch-compute per-kernel jitters with a single device->host sync."""
    with torch.no_grad():
        z0 = Z.reshape(-1, Z.shape[-1])[:1]
        vals = torch.stack([k(z0, z0).to_dense().reshape(()) for k in kernels])
        return [factor * v for v in vals.tolist()]


def _get_nngp_chol(
    model: ApproximateGP,
    variational_strategy: NNVariationalStrategy,
    Z: Tensor,
    kernel: torch.nn.Module,
    jitter: float,
    chunk_size: int,
) -> NNGPCholeskyLinearOperator:
    using_hierarchical = getattr(model, "_hierarchical_nn_idx", None) is not None
    cache_key = (Z.device, Z.dtype, _kernel_param_fingerprint(kernel), jitter, using_hierarchical)
    entry = getattr(model, "_nngp_chol_cache", None)
    if entry is not None and entry[0] == cache_key:
        return entry[1]

    if using_hierarchical:
        nn_idx = model._hierarchical_nn_idx.to(device=Z.device)
    else:
        nn_idx = variational_strategy.nn_xinduce_idx
        if nn_idx.ndim == 3:
            nn_idx = nn_idx.squeeze(0)
        nn_idx = nn_idx.to(device=Z.device)

    kernel_label = "full" if kernel is model.covar_module else type(kernel).__name__
    dag_label = "hierarchical" if using_hierarchical else "flat"
    log.debug("building NNGP Cholesky from %s kernel (%s DAG)", kernel_label, dag_label)

    chol = NNGPCholeskyLinearOperator.from_kernel(
        kernel, Z, nn_idx,
        k=getattr(model, "k", variational_strategy.k),
        jitter=jitter,
        chunk_size=chunk_size,
    )
    model._nngp_chol_cache = (cache_key, chol)
    return chol


#: Backwards-compatible alias. The clamp is shared with training, which applies
#: it to ``beta_features.checkpoint_kernel``, so it lives in ``kernels``.
_clamp_matmul_chunk = clamp_keops_chunk


@GaussianUpdate.register(ApproximateGP, NNVariationalStrategy)
def _gaussian_update_ApproximateGP_nngp(
    model: ApproximateGP,
    variational_strategy: NNVariationalStrategy,
    *,
    sample_values: Tensor,
    target_values: Tensor | None = None,
    noise_covariance: Tensor | LinearOperator | None = None,
    input_transform: InputTransform | None = None,
    update_chunk_size: int = 1000,
    **kwargs: Any,
) -> GeneralizedLinearPath:
    if not isinstance(noise_covariance, (NoneType, ZeroLinearOperator)):
        raise NotImplementedError(
            f"`noise_covariance` argument not yet supported for {type(model)}."
        )

    opts = _UpdateOpts(
        kzz_jitter=kwargs.get("kzz_jitter"),
        nngp_kernel=kwargs.get("nngp_kernel", model.covar_module),
        cg_tolerance=kwargs.get("cg_tolerance"),
        max_cg_iter=kwargs.get("max_cg_iter"),
        update_chunk_size=update_chunk_size,
        matmul_chunk_size=_clamp_matmul_chunk(kwargs.get("matmul_chunk_size") or 4096),
    )

    batch_shape = model.covar_module.batch_shape
    Z = variational_strategy.inducing_points

    if target_values is None:
        target_values = variational_strategy.variational_distribution.rsample(
            sample_values.shape[: sample_values.ndim - len(batch_shape) - 1],
        )

    errors = (target_values - sample_values).to(dtype=Z.dtype)  # (..., M)
    leading, M_size = errors.shape[:-1], errors.shape[-1]
    errors_2d = errors.reshape(-1, M_size).T.contiguous()  # (M, S_flat)

    # Resolve jitters.
    # A jitter of 1e-6 causes F values near zero, making K_nngp^{-1} have entries ~1e6
    # and the Nyström preconditioner numerically garbage. Derive from kernel scale instead.
    #
    # When using a component kernel, derive its own jitter from that kernel's scale.
    # Using kzz_jitter (full kernel) for a small-scale component makes all NNGP
    # conditional variances clamp to jitter, collapsing the NNGP to a scalar multiple
    # of the identity and defeating the local approximation.
    need_kzz = opts.kzz_jitter is None
    need_nngp = opts.nngp_kernel is not model.covar_module
    if need_kzz and need_nngp:
        opts.kzz_jitter, nngp_jitter = _auto_jitters(
            [model.covar_module, opts.nngp_kernel], Z
        )
        log.debug("auto kzz_jitter=%.4e", opts.kzz_jitter)
        log.debug("nngp_jitter=%.4e (component kernel)", nngp_jitter)
    elif need_kzz:
        (opts.kzz_jitter,) = _auto_jitters([model.covar_module], Z)
        log.debug("auto kzz_jitter=%.4e", opts.kzz_jitter)
        nngp_jitter = opts.kzz_jitter
    elif need_nngp:
        (nngp_jitter,) = _auto_jitters([opts.nngp_kernel], Z)
        log.debug("nngp_jitter=%.4e (component kernel)", nngp_jitter)
    else:
        nngp_jitter = opts.kzz_jitter

    nngp_chol = _get_nngp_chol(
        model, variational_strategy, Z, opts.nngp_kernel, nngp_jitter, opts.update_chunk_size,
    )
    iter_count = [0]

    def _matmul_counted(v):
        iter_count[0] += 1
        product = chunked_kernel_matmul(
            model.covar_module, Z, Z, v, opts.matmul_chunk_size,
        )
        return product + opts.kzz_jitter * v

    with torch.no_grad():
        x0 = nngp_chol.cholesky_solve(errors_2d)
        weight_2d = linear_cg(
            _matmul_counted,
            errors_2d,
            n_tridiag=0,
            max_tridiag_iter=0,
            tolerance=opts.cg_tolerance or gpytorch.settings.cg_tolerance.value(),
            max_iter=opts.max_cg_iter or gpytorch.settings.max_cg_iterations.value(),
            initial_guess=x0,
            preconditioner=nngp_chol.cholesky_solve,
        )
    log.debug("NNGP-PCG converged in %d iterations", iter_count[0])

    weight = weight_2d.T.reshape(*leading, M_size)  # (..., M)
    feature_map = KernelEvaluationMap(
        kernel=model.covar_module,
        points=Z,
        input_transform=input_transform,
    )
    return GeneralizedLinearPath(
        feature_map=feature_map,
        weight=weight,
        is_ensemble=is_ensemble(model),
    )


def _get_fft_spectrum(
    model: ApproximateGP,
    output_grid: GridSpec,
    padding_factor: int,
    device: torch.device,
    dtype: torch.dtype,
) -> FFTSpectrum:
    """Circulant spectrum for (covar_module, grid, padding), cached on the model.

    Same shape of cache as _get_nngp_chol / _get_kzz. The spectrum depends only on
    the kernel hyperparameters and the grid, so one build serves every sample
    batch of a run instead of one per batch.
    """
    kernel = model.covar_module
    cache_key = (
        _kernel_param_fingerprint(kernel),
        tuple(output_grid.mins.tolist()),
        tuple(output_grid.maxs.tolist()),
        tuple(output_grid.shape),
        int(padding_factor),
        device,
        dtype,
    )
    cache = getattr(model, "_fft_spectrum_cache", None)
    if not isinstance(cache, dict):
        # A dict, not one entry: a modulated kernel is drawn one group at a
        # time, so several spectra are live at once and a single slot would
        # rebuild the largest piece of work in the sampler on every group.
        cache = {}
        model._fft_spectrum_cache = cache
    if cache_key in cache:
        return cache[cache_key]

    spectrum = build_fft_spectrum(
        kernel, output_grid, padding_factor=padding_factor, device=device, dtype=dtype)
    cache[cache_key] = spectrum
    return spectrum


class SumOfPriorPaths:
    """Prior paths of a kernel whose components were drawn separately.

    A modulated component is drawn from its stationary part and multiplied by
    g(x) here. That product is a draw from g(x) k(x,x') g(x'): scaling a sample
    path pointwise by g scales its covariance by g(x) g(x').
    """

    def __init__(self, parts):
        self.parts = parts

    def __call__(self, x: Tensor) -> Tensor:
        total = None
        for path, amplitude in self.parts:
            values = path(x)
            if amplitude is not None:
                values = values * amplitude(x)
            total = values if total is None else total + values
        return total


class _swapped_covar_module:
    """Point the model at one component for the length of a prior draw.

    Both prior samplers read ``model.covar_module`` -- ``GridFFTPriorSampler``
    directly, and botorch's ``draw_kernel_feature_paths`` through its dispatch on
    the model -- so swapping the attribute is what lets a group be drawn without
    reimplementing either. Sampling runs under ``no_grad`` with no optimiser
    holding the parameter list, so the transient change is not observed.
    """

    def __init__(self, model, kernel):
        self.model = model
        self.kernel = kernel

    def __enter__(self):
        self.original = self.model.covar_module
        self.model.covar_module = self.kernel
        return self.model

    def __exit__(self, *exception):
        self.model.covar_module = self.original
        return False


def _draw_one_prior_path(
    model, sample_shape, prior_sampler, output_grid,
    fft_padding_factor, fft_peak_budget_bytes, chunk, kwargs,
):
    """One prior draw for whatever ``model.covar_module`` currently holds."""
    if output_grid is None:
        return prior_sampler(
            model=model,
            sample_shape=sample_shape,
            chunk_size=chunk,
            **{k: v for k, v in kwargs.items() if k not in ("chunk_size", "update_chunk_size")},
        )

    Z = getattr(model.variational_strategy, "inducing_points", None)
    device, dtype = (Z.device, Z.dtype) if Z is not None else (None, None)
    spectrum = _get_fft_spectrum(model, output_grid, fft_padding_factor, device, dtype)
    return GridFFTPriorSampler()(
        model=model,
        sample_shape=sample_shape,
        output_grid=output_grid,
        padding_factor=fft_padding_factor,
        fft_peak_budget_bytes=fft_peak_budget_bytes,
        spectrum=spectrum,
    )


def draw_prior_paths(
    model: NNGPModel,
    sample_shape: Size,
    *,
    prior_sampler: TPathwisePriorSampler = draw_kernel_feature_paths,
    **kwargs: Any,
):
    """Prior sample paths for the model: FFT-on-grid when given an output grid.

    Split out of the Matheron dispatch so a caller can draw the prior in small
    sample batches (the (S, *grid) buffer is the memory driver) while still doing
    a single posterior-update pass over the evaluation points.

    A kernel with a modulated component is drawn one group at a time and summed,
    because the FFT sampler embeds a covariance that depends on the lag alone.
    That costs one (S, *grid) buffer per group, so a modulated kernel raises the
    peak by the number of groups. The Matheron update is untouched: it evaluates
    the full modulated kernel, which is what the update term needs.
    """
    chunk = kwargs.get("update_chunk_size", 1000)
    output_grid: GridSpec | None = kwargs.pop("output_grid", None)
    fft_padding_factor: int = kwargs.pop("fft_padding_factor", 2)
    fft_peak_budget_bytes = kwargs.pop(
        "fft_peak_budget_bytes", DEFAULT_FFT_PEAK_BUDGET_BYTES
    )
    def draw():
        return _draw_one_prior_path(
            model, sample_shape, prior_sampler, output_grid,
            fft_padding_factor, fft_peak_budget_bytes, chunk, kwargs)

    stationary, modulated = split_modulated(model.covar_module)
    if not modulated:
        return draw()

    log.debug("drawing the prior in %d groups: %d modulated",
              len(modulated) + (stationary is not None), len(modulated))

    parts = []
    if stationary is not None:
        with _swapped_covar_module(model, stationary):
            parts.append((draw(), None))
    for component in modulated:
        with _swapped_covar_module(model, component.stationary_part()):
            parts.append((draw(), component.amplitude))
    return SumOfPriorPaths(parts)


def prior_values_at(prior_paths, points: Tensor, chunk: int) -> Tensor:
    """Evaluate prior paths at ``points`` in chunks -> (*sample_shape, N)."""
    return torch.cat(
        [prior_paths(points[..., start:start + chunk, :])
         for start in range(0, points.shape[-2], chunk)],
        dim=-1,
    )


def evaluate_update_path(
    update_paths: GeneralizedLinearPath,
    x: Tensor,
    matmul_chunk_size: int = 4096,
) -> Tensor:
    """Evaluate the Matheron update path at ``x`` with all samples in one pass.

    ``GeneralizedLinearPath.forward`` computes ``feat @ weight.unsqueeze(-1)``,
    which turns an (S, M) weight into a *batched* matmul and makes the KeOps
    reduction run once per sample. Reshaping the weight to a 2-D (M, S) instead
    gives a single reduction whose per-entry kernel evaluation is shared across
    all S columns -- the kernel evaluations, not the multiply-adds, are what this
    costs. Falls back to the generic path when the layout is not the plain one.

    ``x`` is split into balanced chunks of ``matmul_chunk_size`` rows rather than
    left to ``checkpoint_kernel``; see ``keops_chunk_count`` for why.
    """
    weight = update_paths.weight
    if (
        update_paths.bias_module is not None
        or update_paths.output_transform is not None
        or weight.ndim != 2
    ):
        return update_paths(x)

    w = weight.mT.contiguous()                  # (M, S)
    pieces = keops_chunk_count(x.shape[-2], matmul_chunk_size)
    with gpytorch.settings.lazily_evaluate_kernels(False):
        blocks = [
            update_paths.feature_map(sub) @ w   # (..., N_sub, M) @ (M, S)
            for sub in torch.tensor_split(x, pieces, dim=-2)
        ]
    return torch.cat(blocks, dim=-2).mT         # (S, N)


@DrawMatheronPaths.register(ApproximateGP, NNVariationalStrategy)
def _draw_matheron_paths_NNGPModel_fallback(
    model: NNGPModel,
    _: NNVariationalStrategy,
    *,
    sample_shape: Size,
    prior_sampler: TPathwisePriorSampler,
    update_strategy: TPathwiseUpdate,
    **kwargs: Any,
) -> MatheronPath:
    Z = model.variational_strategy.inducing_points
    chunk = kwargs.get("update_chunk_size", 1000)

    prior_paths = draw_prior_paths(
        model, sample_shape, prior_sampler=prior_sampler, **kwargs)
    for key in ("output_grid", "fft_padding_factor", "fft_peak_budget_bytes"):
        kwargs.pop(key, None)

    sample_values = prior_values_at(prior_paths, Z, chunk)
    update_paths = update_strategy(model=model, sample_values=sample_values, **kwargs)
    return MatheronPath(prior_paths=prior_paths, update_paths=update_paths)


@torch.no_grad()
def sample_pathwise_batched(
    model: NNGPModel,
    x: Tensor,
    n: int,
    *,
    batch_size: int = 4096,
    update_chunk_size: int = 1000,
    sample_batch_size: int | None = None,
    update_strategy: TPathwiseUpdate = gaussian_update,
    prior_sampler: TPathwisePriorSampler = draw_kernel_feature_paths,
    **kwargs: Any,
) -> Tensor:
    """Draw ``n`` pathwise posterior samples at ``x``, returned on the host.

    Two phases, so the prior stays memory-bounded while the expensive part runs
    once:

    1. Per sample batch, draw the prior, evaluate it at the inducing points and
       at every ``x`` (a grid interpolation or a random-feature product -- cheap),
       then release the draw. Only this phase holds an (S, *grid) buffer, so
       ``sample_batch_size`` still caps peak GPU memory.
    2. Once, for all ``n`` samples together: solve for the update weights with a
       single preconditioned CG over an (M, n) right-hand side, then add
       ``K(x, Z) @ W`` in one pass over ``x``.

    The old shape drew a full Matheron path per sample batch and evaluated it
    over the whole of ``x``, so the dominant term -- the kernel evaluations in
    ``K(x, Z)`` -- was repeated ``ceil(n / sample_batch_size)`` times.
    """
    model.eval()
    model.likelihood.eval()

    Z = model.variational_strategy.inducing_points
    N = x.shape[-2]
    group = int(sample_batch_size) if sample_batch_size else n
    group = max(1, min(group, n))

    out = torch.empty(n, N, dtype=Z.dtype, device="cpu")
    sample_values = []

    with linear_operator.settings.max_cg_iterations(500):
        # Phase 1: prior only, one sample batch at a time.
        for start in range(0, n, group):
            s = min(group, n - start)
            prior_paths = draw_prior_paths(
                model, Size([s]), prior_sampler=prior_sampler,
                update_chunk_size=update_chunk_size, **kwargs)

            sample_values.append(prior_values_at(prior_paths, Z, update_chunk_size))

            col = 0
            for chunk in x.split(batch_size, dim=-2):
                width = chunk.shape[-2]
                out[start:start + s, col:col + width] = prior_paths(chunk).cpu()
                col += width

            del prior_paths
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

        # Phase 2: one update solve and one pass over x for every sample.
        update_kwargs = {
            k: v for k, v in kwargs.items()
            if k not in ("output_grid", "fft_padding_factor", "fft_peak_budget_bytes")
        }
        update_paths = update_strategy(
            model=model,
            sample_values=torch.cat(sample_values, dim=0),
            update_chunk_size=update_chunk_size,
            **update_kwargs,
        )
        del sample_values

        matmul_chunk_size = kwargs.get("matmul_chunk_size") or 4096
        col = 0
        for chunk in x.split(batch_size, dim=-2):
            width = chunk.shape[-2]
            out[:, col:col + width] += evaluate_update_path(
                update_paths, chunk, matmul_chunk_size).cpu()
            col += width

    return out
