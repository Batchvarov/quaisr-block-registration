from gpytorch.variational import (
    MeanFieldVariationalDistribution,
)
from upscaling_tools.nngp_band_chol import (
    BandCholeskyVariationalDistribution,
    NNBandCholeskyVariationalStrategy,
)
import torch
import pandas as pd
import gpytorch
from linear_operator.utils.errors import NotPSDError


class NaNTrainingError(RuntimeError):
    """Training diverged to a NaN/non-PSD state.

    Signals the caller that the run is unrecoverable at the current
    hyperparameters and should be retried (e.g. with more likelihood noise).
    """

from gpytorch.models import ApproximateGP
from gpytorch.variational.nearest_neighbor_variational_strategy import (
    NNVariationalStrategy
)

import numpy as np
from tqdm import tqdm

import upscaling_tools.stream
import upscaling_tools.inducing
import upscaling_tools.features
from upscaling_tools.ordering import hierarchical_vecchia_dag, hilbert_sort_indices

class _PrecomputedNNMixin:
    """Take the sequential nearest-neighbour structure as given.

    ``NNVariationalStrategy._compute_nn`` builds ``nn_xinduce_idx`` with
    ``NNUtil.build_sequential_nn_idx``, a Python loop over the M-k inducing
    points that issues one single-row index search and one index insert per
    point -- on a GPU faiss index, that is M-k host<->device round trips, which
    dominates start-up at realistic inducing counts. The structure is a
    deterministic function of the inducing points, so a caller that already has
    it (from a checkpoint, or from a vectorised build) can hand it over.

    ``nn_util`` is still populated: it backs the k-NN search used at eval time,
    and that build is a single batched insert.
    """

    def __init__(self, *args, nn_xinduce_idx=None, **kwargs):
        self._precomputed_nn_xinduce_idx = nn_xinduce_idx
        super().__init__(*args, **kwargs)

    def _compute_nn(self):
        idx = getattr(self, "_precomputed_nn_xinduce_idx", None)
        if idx is None:
            return super()._compute_nn()
        with torch.no_grad():
            inducing_points_fl = self.inducing_points.data.float()
            self.nn_util.set_nn_idx(inducing_points_fl)
            expected = (self.M - self.k, self.k)
            if tuple(idx.shape[-2:]) != expected:
                raise ValueError(
                    f"precomputed nn_xinduce_idx has shape {tuple(idx.shape)}, "
                    f"expected (..., {expected[0]}, {expected[1]}) for M={self.M}, "
                    f"k={self.k}")
            self.nn_xinduce_idx = idx.to(device=self.inducing_points.device)
        return self


class PrecomputedNNVariationalStrategy(_PrecomputedNNMixin, NNVariationalStrategy):
    pass


class PrecomputedNNBandCholeskyVariationalStrategy(
        _PrecomputedNNMixin, NNBandCholeskyVariationalStrategy):
    pass


class NNGPModel(ApproximateGP):
    def __init__(self,
                 train_inputs,
                 train_outputs,
                 inducing_points,
                 likelihood,
                 k,
                 training_batch_size,
                 kernel,
                 mean: gpytorch.means.Mean,
                 batch_shape: torch.Size = torch.Size([]),
                 feature_extractor=None,
                 use_band_cholesky: bool = False,
                 nn_xinduce_idx=None,
                 ):
        if feature_extractor is None:
            feature_extractor = upscaling_tools.features.FeatureIdentity()
        self.k = k
        self.train_inputs = train_inputs
        self.train_outputs = train_outputs

        if use_band_cholesky:
            variational_distribution = BandCholeskyVariationalDistribution(
                inducing_points.size(-2),
                k=k,
                batch_shape=batch_shape,
            )
            variational_strategy = PrecomputedNNBandCholeskyVariationalStrategy(
                self,
                inducing_points,
                variational_distribution,
                k=k,
                training_batch_size=training_batch_size,
                nn_xinduce_idx=nn_xinduce_idx,
            )
        else:
            variational_distribution = MeanFieldVariationalDistribution(
                inducing_points.size(-2),
                batch_shape=batch_shape,
            )
            variational_strategy = PrecomputedNNVariationalStrategy(
                self,
                inducing_points,
                variational_distribution,
                k=k,
                training_batch_size=training_batch_size,
                nn_xinduce_idx=nn_xinduce_idx,
            )

        super(NNGPModel, self).__init__(variational_strategy)

        self.feature_extractor = feature_extractor
        self.mean_module = mean
        self.covar_module = kernel
        self.likelihood = likelihood

    def forward(self, x: torch.Tensor):
        projected_x = self.feature_extractor(x)
        mean_x = self.mean_module(projected_x)
        covar_x = self.covar_module(projected_x)
        return gpytorch.distributions.MultivariateNormal(mean_x, covar_x)

    def __call__(self, x: torch.Tensor, prior=False, **kwargs):
        if x is not None:
            if x.dim() == 1:
                x = x.unsqueeze(-1)
        return self.variational_strategy(x=x, prior=prior, **kwargs)

    def latent_posterior(self, x: torch.Tensor):
        # Make sure we're in the predictive posterior mode.
        self.eval()
        return self(x)

    def latent_prior(self, x: torch.Tensor):
        # Make sure we're not in the posterior mode.
        self.train()
        with gpytorch.settings.prior_mode(True):
            return self.forward(x)

    @torch.no_grad()
    def sample_from_nngp(self, x, n, **kwargs):
        self.eval()
        self.likelihood.eval()
        with gpytorch.settings.fast_pred_var():
            posterior = self.likelihood(self(x))
            samples = posterior.sample(torch.Size([n, ]))
            return samples, np.zeros(n)

    @torch.no_grad()
    def sample_prior_path(self, x, n):
        prior = self.latent_prior(x)
        samples = prior.sample(torch.Size([n, ]))
        return samples, np.zeros(n)

    @torch.no_grad()
    def sample_pathwise(self, x, n, batch_size=4096, update_chunk_size=1000,
                        sample_batch_size=None, **kwargs):
        """Draw ``n`` pathwise posterior samples at ``x``, returned on the CPU.

        ``sample_batch_size`` bounds peak GPU memory: the prior draw (for the FFT
        prior, an ``(S, *grid.shape)`` buffer) is the only term that scales with
        the number of samples held at once, and it is released before the update
        pass. It no longer multiplies the kernel work -- the posterior update is
        solved once for all ``n`` samples and applied in a single pass over ``x``.
        See ``upscaling_tools.nngp_sampling.sample_pathwise_batched``.
        """
        # Imported here, not at module scope: nngp_sampling imports this module
        # to register its dispatch rules.
        from upscaling_tools.nngp_sampling import sample_pathwise_batched

        return sample_pathwise_batched(
            self, x, n,
            batch_size=batch_size,
            update_chunk_size=update_chunk_size,
            sample_batch_size=sample_batch_size,
            **kwargs,
        )

    @torch.no_grad()
    def inference(self, xs, output_scaler=None, batch_size=8192):
        # Plain tensor slicing, not DataLoader(TensorDataset(...)): with
        # auto-collation the loader indexes the tensor one ROW at a time and
        # re-stacks each batch, which costs ~1 us per point on the host and a
        # separate device slice per point for a CUDA tensor. At grid scale that
        # overhead alone runs into minutes; .split() is a view per batch.
        self.eval()
        self.likelihood.eval()

        if xs.dim() == 1:
            # __call__ would do this anyway; do it first so split(dim=-2) works.
            xs = xs.unsqueeze(-1)

        means, variances = [], []
        for xbatch in xs.split(batch_size, dim=-2):
            preds = self.likelihood(self(xbatch))
            means.append(preds.mean.cpu())
            variances.append(preds.variance.cpu())

        y_mean = torch.cat(means)
        y_var = torch.cat(variances)

        if output_scaler is not None:
            y_mean = output_scaler.inverse_transform(y_mean.unsqueeze(-1))
            y_var = y_var * np.square(output_scaler.scale_)

        df = pd.DataFrame({
            'GP_mean': y_mean.flatten(),
            'GP_variance': y_var.flatten(),
            'GP_std': torch.sqrt(y_var.flatten()),
        })

        return df

    def sample_gp(self, xs, n_samples, sample_prior: bool = False, output_scaler=None, **kwargs):
        if not sample_prior:
            # sample_pathwise already returns host tensors.
            f_samples = self.sample_pathwise(xs, n_samples, **kwargs)
        else:
            f_samples, _ = self.sample_prior_path(xs, n_samples)
            f_samples = f_samples.cpu()

        f_samples = f_samples.numpy()
        if output_scaler is not None:
            # Apply the scaler's affine inverse in place and in the sample dtype.
            # StandardScaler.inverse_transform runs the array through
            # check_array, which promotes an (n_samples, N) float32 block to
            # float64 -- a second, doubled copy of the whole sample set.
            scale = getattr(output_scaler, "scale_", None)
            mean = getattr(output_scaler, "mean_", None)
            if scale is not None:
                f_samples *= np.asarray(scale, dtype=f_samples.dtype).reshape(-1)[0]
            if mean is not None:
                f_samples += np.asarray(mean, dtype=f_samples.dtype).reshape(-1)[0]

        df_samples = pd.DataFrame({
                f"sample_{i}": f_samples[i] for i in range(0, n_samples)
        })

        return df_samples

def construct_model(X, y, kernel, likelihood, parameters,
                    batch_shape=torch.Size([]),
                    inducing_points_allocator = None,
                    mean_module=None,
                    mll=gpytorch.mlls.VariationalELBO,
                    sort_inducing_points: bool = True,
                    use_hierarchical_vecchia: bool = False,
                    n_vecchia_levels: int = 3,
                    k_cross_ratio: float = 0.5,
                    k_l0_fraction: float = 0.5,
                    use_band_cholesky: bool = False,
                    topology: dict | None = None,
                    **kwargs):
    """Build an NNGP model, optionally reusing a saved topology.

    ``topology`` short-circuits everything that is a deterministic function of
    the training inputs -- the inducing-point allocation, the Hilbert sort, the
    hierarchical Vecchia DAG and the sequential nearest-neighbour build. Pass the
    dict written alongside a trained model's state (see ``model_topology``) to
    skip that work when rebuilding a model for inference; the shapes are then
    guaranteed to match the saved ``state_dict`` because they came from it.
    Recognised keys, all optional: ``inducing_points``, ``order``,
    ``hierarchical_nn_idx``, ``nn_xinduce_idx``, ``inducing_are_data``.
    """
    topology = topology or {}
    if inducing_points_allocator is None:
        inducing_points_allocator = upscaling_tools.inducing.DatapointsAsInducing()
    if mean_module is None:
        mean_module = gpytorch.means.ConstantMean()
    device = torch.device('cpu')
    dtype = torch.float32

    if torch.cuda.is_available():
        device = torch.device("cuda")

#    MPS doesn't work at the moment as some of the functionality in pytorch is not implemented for Metal.
#    if torch.mps.is_available():
#        device = torch.device("mps")
#        dtype = torch.float32

    torch.set_default_dtype(dtype)
    k = parameters['k']
    training_batch_size = parameters['training_batch_size']

    X = X.detach().clone()
    y = y.detach().clone()

    saved_inducing = topology.get("inducing_points")
    reuse_topology = saved_inducing is not None
    if reuse_topology:
        inducing_points = torch.as_tensor(saved_inducing)
    else:
        inducing_points = inducing_points_allocator.initialise(X)

    # Whether the allocator returned the training points themselves, in order.
    # Never infer this from a count: GridCountInducing derives its grid shape as
    # n_north = round(sqrt(ninducing*h/w)), n_east = round(ninducing/n_north),
    # whose product can overshoot ninducing, so the masked grid can land on
    # exactly len(X) points without being the data. The old
    # `len(inducing_points) == len(X)` test then permuted X/y by an
    # inducing-derived order and sent training down the inducing-indexed branch,
    # silently pairing every minibatch target with an unrelated training output.
    inducing_are_data = topology.get(
        "inducing_are_data",
        getattr(inducing_points_allocator, "returns_data_points", False))

    order = None
    hier_nn_idx = None
    if reuse_topology:
        # The saved inducing points are already in final order, so the sort and
        # the DAG build are skipped; `order` is still applied to X/y below when
        # the inducing set IS the data, to keep the shared index meaningful.
        order = topology.get("order")
        if order is not None:
            order = torch.as_tensor(order)
        hier_nn_idx = topology.get("hierarchical_nn_idx")
        if hier_nn_idx is not None:
            hier_nn_idx = torch.as_tensor(hier_nn_idx)
        if order is not None and inducing_are_data:
            X = X[order]
            y = y[order]
    elif use_hierarchical_vecchia:
        if inducing_points.shape[0] < 2 * k:
            import warnings
            warnings.warn(
                f"Too few inducing points ({inducing_points.shape[0]}) for hierarchical Vecchia "
                f"(need >= 2*k={2*k}). Falling back to Hilbert sort."
            )
            sort_inducing_points = True
        else:
            order, hier_nn_idx = hierarchical_vecchia_dag(
                inducing_points, k=k, n_levels=n_vecchia_levels,
                k_cross_ratio=k_cross_ratio, k_l0_fraction=k_l0_fraction,
            )
    if not reuse_topology:
        if order is None and sort_inducing_points:
            order = hilbert_sort_indices(inducing_points)

        if order is not None:
            inducing_points = inducing_points[order]
            if inducing_are_data:
                # Keep the data in step with the inducing points so the shared
                # index stays meaningful.
                X = X[order]
                y = y[order]

    # The variational strategy's edges ARE the NNGP prior: GPyTorch reads
    # nn_xinduce_idx only in _stochastic_kl_helper, to build KL[q(u)||p(u)].
    # A fresh hierarchical run has no saved topology, so the DAG built above is
    # the only source of those edges; without handing it over the strategy
    # rebuilds a purely local sequential k-NN index and the hierarchy is lost.
    nn_xinduce_idx = topology.get("nn_xinduce_idx")
    if nn_xinduce_idx is None:
        nn_xinduce_idx = hier_nn_idx

    model = NNGPModel(
        train_inputs=X.to(dtype=dtype, device=device),
        train_outputs=y.to(dtype=dtype, device=device),
        mean=mean_module,
        inducing_points=inducing_points.to(dtype=dtype, device=device),
        likelihood=likelihood,
        k=k,
        training_batch_size=training_batch_size,
        kernel=kernel,
        batch_shape=batch_shape,
        use_band_cholesky=use_band_cholesky,
        nn_xinduce_idx=nn_xinduce_idx,
        **kwargs)

    model.to(dtype=dtype).to(device=device)
    likelihood.to(dtype=dtype).to(device=device)

    # Recorded on the model so training (and any other consumer) can tell
    # whether the inducing index is also the data index without re-deriving it
    # from the allocator or, worse, from a count. Plain attribute: not a buffer,
    # so it never enters the state dict.
    model.inducing_are_training_data = inducing_are_data

    if hier_nn_idx is not None:
        # Point at the strategy's own tensor when it carries the same edges.
        # _compute_nn moved the DAG onto the inducing-point device, so this
        # keeps one copy instead of a host original plus a device copy, and it
        # lets model_topology() recognise the two as one and serialise them once.
        strategy_idx = model.variational_strategy.nn_xinduce_idx
        same_edges = nn_xinduce_idx is hier_nn_idx and tuple(
            strategy_idx.shape[-2:]) == tuple(hier_nn_idx.shape[-2:])
        model._hierarchical_nn_idx = strategy_idx if same_edges else hier_nn_idx

    # Kept so model_topology() can hand the same permutation back on a rebuild:
    # when the inducing set IS the data, X/y were permuted by it and the shared
    # inducing/data index only stays meaningful if that is reproduced.
    if order is not None:
        model._inducing_order = order

    print('Initialised a GP model.')
    model.train()
    likelihood.train()
    mll = mll(likelihood, model, num_data=y.size(0))

    return model, mll, device, dtype


def model_topology(model) -> dict:
    """Everything about a trained model's structure that is expensive to rebuild.

    Save this next to the state dict and hand it back to ``construct_model`` as
    ``topology=`` when reconstructing the model for inference. Without it the
    rebuild repeats the inducing-point allocation (a KD-tree over every training
    point), the Hilbert sort, the hierarchical Vecchia DAG and -- the expensive
    one -- the M-k step sequential nearest-neighbour build, all to arrive at
    values that ``load_state_dict`` then overwrites or that were already known.

    Tensors are detached onto the host so the file loads on a CPU-only box.
    """
    strategy = model.variational_strategy
    nn_xinduce_idx = strategy.nn_xinduce_idx.detach().cpu()
    topology = {
        "inducing_points": strategy.inducing_points.detach().cpu(),
        "nn_xinduce_idx": nn_xinduce_idx,
        "inducing_are_data": bool(
            getattr(model, "inducing_are_training_data", False)),
    }
    hier = getattr(model, "_hierarchical_nn_idx", None)
    if hier is not None:
        # On a hierarchical run the strategy was handed this very tensor, so the
        # two keys hold the same edges. Share one host copy: on CUDA, detaching
        # each separately would write the (M-k, k) index into the checkpoint
        # twice -- ~128 MB of duplicate int64 at M=500k, k=32.
        if hier is strategy.nn_xinduce_idx:
            topology["hierarchical_nn_idx"] = nn_xinduce_idx
        else:
            topology["hierarchical_nn_idx"] = hier.detach().cpu()
    order = getattr(model, "_inducing_order", None)
    if order is not None:
        topology["order"] = order.detach().cpu()
    return topology


def nngp_training(
        X,
        y,
        kernel,
        likelihood,
        parameters,
        loss_stream=upscaling_tools.stream.StreamList(),
        time_left_stream=upscaling_tools.stream.StreamList(),
        **kwargs):

    model, mll, device, dtype = construct_model(
        X, y, kernel, likelihood, parameters, **kwargs)

    learning_rate = parameters['learning_rate']
    training_epochs = parameters['training_epochs']
    milestones = parameters['milestones']

    print('Initialised an optimizer.')
    optimizer = torch.optim.Adam([
        {'params': model.covar_module.parameters()},
        {'params': model.mean_module.parameters()},
        {'params': model.likelihood.parameters()},
        {'params': model.variational_parameters()},
        {'params': model.feature_extractor.parameters(), 'lr': 1e-2}
    ], lr=learning_rate)

    scheduler = torch.optim.lr_scheduler.MultiStepLR(
        optimizer, milestones=milestones, gamma=0.1)

    losses = []

    epochs_iter = tqdm(range(training_epochs), desc="Epoch")

    N = model.train_inputs.size(0)
    M_ind = model.variational_strategy.inducing_points.size(-2)
    batch_size = parameters['training_batch_size']

    # The x=None branch below indexes train_outputs with indices produced over
    # the INDUCING points, so it is only correct when the inducing set IS the
    # training set, in order. construct_model records that; fall back to the old
    # count test only for a model built some other way.
    inducing_are_data = getattr(model, 'inducing_are_training_data', None)
    if inducing_are_data is None:
        inducing_are_data = M_ind == N
    data_minibatch = not inducing_are_data

    if not data_minibatch:
        Z = model.variational_strategy.inducing_points
        if Z.dim() == model.train_inputs.dim():
            assert Z.shape == model.train_inputs.shape and torch.equal(
                Z, model.train_inputs), (
                "inducing points are not the training inputs, but training took "
                "the inducing-indexed branch -- every minibatch target would be "
                "paired with an unrelated training output")

    params = [p for group in optimizer.param_groups for p in group['params']]

    # Consecutive non-finite losses tolerated before the run is declared dead
    # and NaNTrainingError is raised (so the caller can retry with more noise).
    nan_patience = parameters.get('nan_patience', 25)
    nan_streak = 0

    def _optim_step(loss):
        nonlocal nan_streak
        loss_item = loss.item()
        losses.append(loss_item)
        # A non-finite loss would backprop NaN/inf grads.
        if not np.isfinite(loss_item):
            optimizer.zero_grad(set_to_none=True)
            nan_streak += 1
            if nan_streak >= nan_patience:
                raise NaNTrainingError(
                    f"Non-finite loss for {nan_streak} consecutive steps")
            return
        nan_streak = 0
        loss.backward()
        grad_norm = torch.nn.utils.clip_grad_norm_(params, max_norm=1.0)
        if not torch.isfinite(grad_norm):
            optimizer.zero_grad(set_to_none=True)
            return
        optimizer.step()

    try:
        for epoch in epochs_iter:
            if data_minibatch:
                perm = torch.randperm(N, device=model.train_inputs.device)
                for start in range(0, N, batch_size):
                    idx = perm[start:start + batch_size]
                    x_batch = model.train_inputs[idx].to(device=device, dtype=dtype)
                    y_batch = model.train_outputs[..., idx].to(device=device, dtype=dtype)
                    optimizer.zero_grad()
                    output = model(x=x_batch)
                    _optim_step(-mll(output, y_batch).sum())
            else:
                num_batches = model.variational_strategy._total_training_batches
                for _ in range(num_batches):
                    optimizer.zero_grad()
                    output = model(x=None)
                    current_training_indices = model.variational_strategy.current_training_indices
                    y_batch = model.train_outputs[..., current_training_indices].to(
                        device=device, dtype=dtype)
                    _optim_step(-mll(output, y_batch).sum())
            scheduler.step()
            loss_stream.write_list(losses)

            rate = epochs_iter.format_dict["rate"]
            time_left = (epochs_iter.total - epochs_iter.n) / rate if rate is not None else 1000
            time_total = epochs_iter.total / rate if rate is not None else 1000
            time_left_stream.write_list([int(time_left), int(time_total)])

            if not losses:
                raise RuntimeError(
                    f"Training produced no optimisation steps (N={N}, "
                    f"batch_size={batch_size}, data_minibatch={data_minibatch}) "
                    "-- nothing to optimise")
            epochs_iter.set_description("Loss %f" % losses[-1])
    except NotPSDError as e:
        # Hard linalg failure (variational KL Cholesky) -- same underlying cause
        # as a NaN loss. Surface it as a retryable signal.
        raise NaNTrainingError(f"Non-PSD covariance during training: {e}") from e

    return model, losses

def construct_likelihood(options):
    noise = options.get('noise', 1e-4) if isinstance(options, dict) else 1e-4
    noise = max(float(noise), 1e-8)
    # Upper bound sits strictly above the requested noise. Interval's inverse
    # transform is log((v - lower) / (upper - v)), so setting the value exactly
    # at the bound stores raw_noise = +inf -- which is then written into the
    # saved state dict. requires_grad_(False) below is what keeps the noise
    # fixed; the headroom only removes the singularity in the transform.
    likelihood = gpytorch.likelihoods.GaussianLikelihood(
        noise_constraint=gpytorch.constraints.Interval(noise * 1e-4, noise * (1 + 1e-3)))
    likelihood.noise = noise
    likelihood.noise_covar.raw_noise.requires_grad_(False)

    return likelihood
